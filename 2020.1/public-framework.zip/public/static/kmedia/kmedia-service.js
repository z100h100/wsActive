/**
 * 功能描述：配置表
 *
**/
window.Kservice = {
  websocketUrl: 'wss://kfront.kedacom.com:444/236wsServer/',
  // stunService: '47.100.238.254:3478'
}
