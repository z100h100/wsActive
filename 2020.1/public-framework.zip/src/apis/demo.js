import { fetch } from '@/utils/http'

export default {
  getDemoList: params => fetch('get', '/demo/list', params),
  getformByAPI: params => fetch('get', '/demo/formByAPI', params),
  getformDataByAPI: params => fetch('get', '/demo/formDataByAPI', params),
  // 右侧通讯录-获取项目成员
  getProjectPersonListApi: params => fetch('get', '/demo/projectMember', params),
  // 右侧通讯录-获取普通人员列表
  getPersonListApi: params => fetch('get', '/demo/getUserNotProject', params),
  // 右侧通讯录列表数据
  getRightDialogDemoList: params => fetch('get', '/demo/getRightDialogDemoList', params),
  gettriggerHistoryDetail: params => fetch('get', '/demo/triggerHistoryDetail', params),
  getLog: params => fetch('get', '/demo/log', params),
  getTreeData: params => fetch('get', '/demo/treeData', params),
  getEchartsInList: params => fetch('get', '/demo/echartsInList', params)
}
