<template>
  <div id="cm-resize-frame">
    <textarea ref="mycode" class="codesql" v-model="outForm.activeConfig"></textarea>
  </div>
</template>
<script>
import { mapActions } from 'vuex'
import 'codemirror/theme/ambiance.css'
import 'codemirror/lib/codemirror.css'
import 'codemirror/addon/hint/show-hint.css'
import showHint from './show-hint.js'
// setTips, getTips,
import { serveHint, setTips } from './serve-hint.js'
let CodeMirror = require('codemirror/lib/codemirror')
require('codemirror/addon/edit/matchbrackets')
require('codemirror/addon/selection/active-line')
require('codemirror/mode/sql/sql')
showHint(CodeMirror)
serveHint(CodeMirror)
export default {
  props: {
    outForm: {},
    outTips: {
      type: Array,
      default: () => {
        return []
      }
    },
    // 是否只读
    readOnlyFlag: {
      type: Boolean,
      default: () => {
        return false
      }
    }
  },
  data() {
    return {
      editor: null,
      originTips: [],
      hasSet: false,
      fields: [
        'url',
        'clientId',
        'serviceName',
        'clientSecret',
        'password',
        'username',
        'port',
        'nodeIp',
        'nodePort'
      ]
    }
  },
  mounted() {
    this.resetCM()
  },
  methods: {
    ...mapActions(['getPlaceholders']),
    reset() {
      this.hasSet = false
    },
    resetCM() {
      this.editor && this.editor.toTextArea()
      this.editor = CodeMirror.fromTextArea(this.$refs.mycode, {
        lineNumbers: true,
        mode: 'text/x-mariadb',
        theme: 'default',
        lineWrapping: true
      })
      this.$nextTick(() => {
        this.initEditorEvent()
        this.initEditorResizeEvent()
        this.initTips()
      })
    },
    initTips() {
      // this.getPlaceholders().then(res => {
      //   const { originTips } = this
      //   const selfTips = []
      //   if (res.data && res.data.code === '0') {
      //     this.fields.forEach(field => {
      //       selfTips.push(`self.${field}`)
      //     })
      //     this.originTips = [...this.originTips, ...res.data.result, ...selfTips]
      //     setTips([originTips, ...res.data.result, ...selfTips])
      //   }
      // })
    },
    initEditorResizeEvent() {
      const resizeFrame = document.querySelector('#cm-resize-frame')
      const editorResize = () => {
        this.editor.setSize(resizeFrame.clientWidth + 2, resizeFrame.clientHeight - 8)
      }
      editorResize()
      if (window.ResizeObserver) {
        new ResizeObserver(editorResize).observe(resizeFrame)
      } else if (window.MutationObserver) {
        new MutationObserver(editorResize).observe(resizeFrame, { attributes: true })
      }
    },
    initEditorEvent() {
      let timeout
      const { editor, readOnlyFlag } = this
      if (readOnlyFlag) {
        editor.setOption('readOnly', true)
      }
      editor.on('inputRead', cm => {
        if (timeout) clearTimeout(timeout)
        timeout = setTimeout(function() {
          CodeMirror.showHint(cm, CodeMirror.hint.serveHint, { completeSingle: false })
        }, 150)
      })
      editor.on('keyup', (cm, event) => {
        this.$nextTick(() => {
          var keyCode = event.keyCode || event.which
          if (keyCode == 8 || keyCode == 46) {
            if (timeout) clearTimeout(timeout)
            timeout = setTimeout(function() {
              CodeMirror.showHint(cm, CodeMirror.hint.serveHint, { completeSingle: false })
            }, 150)
          }
        })
      })
      editor.on('change', () => {
        const value = editor.getValue()
        this.$emit('update:config', value)
      })
    },
    generateTips(outTips) {
      const { originTips } = this
      let tips = []
      if (!this.$utils.isEmpty(outTips)) {
        outTips.forEach(module => {
          if (!this.$utils.isEmpty(module.dependencies)) {
            module.dependencies.forEach(dependence => {
              this.fields.forEach(field => {
                if (dependence.alias) {
                  tips.push(`self.${dependence.alias}.${field}`)
                }
              })
            })
          }
        })
        this.originTips = [...originTips, ...tips]
        setTips([...originTips, ...tips])
      }
    }
  },
  watch: {
    outForm: {
      handler: function(val, oldval) {
        if (!this.$utils.isEmpty(val.outTips)) {
          this.generateTips(val.outTips)
        }
        if (val.activeConfig && !this.hasSet) {
          this.editor.setValue(val.activeConfig)
          this.editor.refresh()
          this.hasSet = true
          this.resetCM()
        }
      },
      deep: true
    }
  }
}
</script>
<style lang="scss">
.CodeMirror {
  background-color: #fdfdfd;
  line-height: 2em;
}
.CodeMirror-scroll {
  background-color: #fafbfc !important;
}
.CodeMirror-vscrollbar {
  background-color: #fafbfc !important;
}
.CodeMirror-gutters {
  background-color: #fafbfc;
  border-right: 0;
}
.CodeMirror-line {
  padding-left: 15px !important;
}
#cm-resize-frame {
  position: relative;
  overflow: hidden;
  resize: vertical;
  height: 300px;
  border: 0 !important;
  width: 100%;
  background-color: #fafbfc;
}
</style>
