/* eslint-disable */
var Pos
var tips = [
  'self.redis.prot',
  'self.redis.url',
  'self.red.url',
  'self.redis.url.search',
  'serve.name',
  'serve.nut',
  'serve.location.href',
  'serve.location.help'
]

export const setTips = function(newTips) {
  tips = newTips
}

export const getTips = function() {
  return tips
}
function cleanName(name) {
  // Get rid name from identifierQuote and preceding dot(.)
  if (name.charAt(0) == '.') {
    name = name.substr(1)
  }
  return name
}
function nameCompletion(cur, token, editor) {
  var nameParts = []
  var start = token.start
  var cont = true
  while (cont) {
    cont = token.string.charAt(0) == '.'
    // console.log(Pos(cur.line, token.start), 'Pos(cur.line, token.start)')
    start = token.start
    nameParts.unshift(cleanName(token.string))
    token = editor.getTokenAt(Pos(cur.line, token.start))
    if (token.string == '.') {
      cont = true
      token = editor.getTokenAt(Pos(cur.line, token.start))
    }
  }
  // console.log(cur, 'cur')

  // Try to complete table names
  var string = nameParts.join('.')
  return string
}

function unique(array) {
  var res = array.filter(function(item, index, array) {
    return array.indexOf(item) === index
  })
  return res.sort()
}

function getSuggestion(search, token) {
  var suggestion = {}
  var start, end
  var tipsArray = []
  suggestion.tips = tips.forEach(function(value) {
    if (value.indexOf(search) === 0) {
      var keyArray = search.split('.')
      var tip = ''
      if (keyArray.length === 1) {
        start = token.start
        tipsArray.push(value.split('.')[0])
      } else {
        start = token.start + 1
        tipsArray.push(value.split('.')[keyArray.length - 1])
      }
    }
  })
  suggestion.tips = unique(tipsArray)
  suggestion.start = start
  suggestion.end = token.end
  return suggestion
}

export const serveHint = function(CodeMirror) {
  var search = ''
  var suggestion = {}
  Pos = CodeMirror.Pos
  CodeMirror.registerHelper('hint', 'serveHint', function(editor, options) {
    var cur = editor.getCursor(),
      token = editor.getTokenAt(cur)
    var start = token.start,
      end = token.end
    var tokenString = token.string
    if (tokenString.charAt(0) == '.') {
      search = nameCompletion(cur, token, editor)
    } else {
      search = tokenString
    }
    console.log(search, 'search')
    suggestion = getSuggestion(search, token)
    console.log(suggestion)
    return {
      list: suggestion.tips,
      from: CodeMirror.Pos(cur.line, suggestion.start),
      to: CodeMirror.Pos(cur.line, suggestion.end)
    }
  })
}
