<template>
  <div
    class="DeptPersonTree"
    :id="deptTreeNoInput"
    @mouseleave="deptTreeMouseLeave"
    @mouseover="deptTreeMouseEnter"
  >
    <div
      @click="inputClick"
      @mouseleave="inputMouseLeave"
      :class="{ 'input-wrap': judge(multiple) }"
    >
      <div class="item-wrap">
        <!--        <div class="item" v-if="judge(multiple)" v-for="(name, i) in names" :key="i">-->
        <!--          <span>{{ name.name }}</span>-->
        <!--          <i-->
        <!--            class="el-tag__close el-icon-close"-->
        <!--            @click.stop="delNamesItem(i)"-->
        <!--          ></i>-->
        <!--        </div>-->
        <el-tag
          class="item"
          v-if="judge(multiple)"
          v-for="(v, i) in names"
          type="info"
          closable
          :key="i"
          :disable-transitions="true"
          @close="delNamesItem(i)"
        >
          <span class="el-select__tags-text">{{ v.name }}</span>
        </el-tag>
        <el-input
          :id="dept"
          class="dept"
          :class="{ single: !judge(multiple) }"
          :disabled="judge(disabled)"
          :readonly="!judge(filter)"
          v-model="departmentSelected[prop.name]"
          :placeholder="names.length ? '' : placeholder"
          @blur="inputBlur"
          @focus="inputFocus"
          @keyup.native="filterData(departmentSelected)"
          :size="size"
        >
          <i
            slot="suffix"
            class="el-select__caret el-input__icon el-icon-circle-close"
            @click="clearInput($event)"
            v-show="showClose && !judge(multiple)"
          ></i>
          <i
            slot="suffix"
            class="el-icon-caret-bottom"
            :class="{ arrowup: !arrowUp, arrowdown: arrowUp }"
            v-show="showArrow && !judge(multiple)"
          ></i>
        </el-input>
      </div>
      <i
        class="el-icon-caret-bottom"
        v-show="judge(multiple)"
        :class="{ arrowup: !arrowUp, arrowdown: arrowUp }"
      ></i>
    </div>
    <!--<div class="opticy"></div>-->
    <el-collapse-transition>
      <div
        class="options"
        v-show="!arrowUp"
        id="options"
        v-loading="loading"
        element-loading-spinner="el-icon-loading"
      >
        <div class="arrow"></div>
        <el-tree
          :key="expandAll"
          class="deptTree"
          :data="data"
          :node-key="nodeKey"
          :default-expand-all="expandAll"
          :props="defaultProps"
          :highlight-current="true"
          :auto-expand-parent="true"
          :expand-on-click-node="true"
          :current-node-key="
            Array.isArray(departmentSelected[prop.code])
              ? departmentSelected[prop.code][0] || ''
              : departmentSelected[prop.code]
          "
          @node-click="handleHideTree"
          :filter-node-method="handleFilterNode"
          ref="deptTree"
        >
          <div
            :class="{ 'tree-slot': isInNames(data.code) }"
            class="common-tree-slot"
            @mouseenter="treeItemHover(data[choseNode.key] === choseNode.value, $event)"
            @mouseleave="treeItemLeave(data[choseNode.key] === choseNode.value, $event)"
            :canChose="data[choseNode.key] === choseNode.value ? 1 : 0"
            slot-scope="{ node, data }"
          >
            <span>{{ data.name }}</span>
            <!--            <span v-if="isInNames(data.code)">√</span>-->
            <i v-if="isInNames(data.code)" class="el-icon-check"></i>
          </div>
        </el-tree>
      </div>
    </el-collapse-transition>
    <div class="showMsg" v-if="showMsg">{{ rule.message }}</div>
  </div>
</template>
<script>
/**
 *  data 数据源
 *  placeholder 输入框提示
 *  size 输入框大小 默认small
 *  prop 数据源绑定的值
 *  hover 下拉框打开关闭的方式
 *  filter 是否可以输入进行筛选
 *  clearable 是否可以清空
 *  rule 验证是否必填 requie true 为必填  message 必填时候没填的提示 验证的时候需调用 validate 方法 返回布尔值 resetFields 为重置下拉框样式
 *  启用远程搜索，需要将filterable和remote设置为true，同时传入一个remote-method
 *  nodeKey 数据的 标识  默认 id
 *  choseNode 可以选择的节点 传一个对象 语言无法说明 驸列子  prop = {key: 'a', value: 'b'}, node[prop.key] === prop.value  这个节点可以被选择
 *  multiple 是否可以多选
 * */
/**
 *  事件 change  focus  blur
 * */
export default {
  name: 'DeptPersonTree',
  model: {
    prop: 'defaultValue',
    event: 'input'
  },
  props: {
    data: { type: Array, default: () => [] },
    placeholder: { type: String, default: '请选择' },
    size: { type: String, default: 'small' },
    clearable: { type: [String, Boolean], default: false },
    hover: { default: false },
    filter: { type: [String, Boolean], default: false },
    disabled: { type: [String, Boolean], default: false },
    defaultValue: {},
    remote: { type: [String, Boolean], default: false },
    remoteMethod: { type: Function },
    nodeKey: { default: 'id' },
    multiple: { default: false },
    choseNode: {
      type: Object,
      default: () => {
        return {
          key: 'orgType',
          value: 'PERSON'
        }
      }
    },
    rule: {
      type: Object,
      default: () => {
        return {
          require: false,
          message: ''
        }
      }
    },
    prop: {
      type: Object,
      default: () => {
        return {
          name: 'name',
          code: 'code',
          children: 'children'
        }
      }
    }
  },
  watch: {
    departmentSelected: {
      handler(val) {
        if (this.clickChoseTree) {
          this.clickChoseTree = false
          return
        }
        this.filterData(val)
      },
      deep: true
    },
    defaultValue() {
      if (this.clickChoseTree) {
        this.clickChoseTree = false
        return
      }
      this.handleModel()
    },
    data() {
      this.loading = false
    }
  },
  computed: {
    // 显示×号
    showClose() {
      return (
        this.judge(this.clearable) && this.mouseEnter && this.departmentSelected[this.prop.name]
      )
    },
    // 显示箭头
    showArrow() {
      return (
        (!this.judge(this.clearable) ||
          !this.mouseEnter ||
          !this.departmentSelected[this.prop.name]) &&
        !this.judge(this.remote)
      )
    }
  },
  data() {
    return {
      // 选择框绑定的值
      departmentSelected: {
        [this.prop.name]: '',
        [this.prop.code]: ''
      },
      names: [], // 存放选中的选项 多选 和 渲染样式用
      // 树形图配置
      defaultProps: {
        label: this.prop.name,
        children: this.prop.children
      },
      arrowUp: true, // 箭头是否向上 true 不显示下拉框 false 显示下拉框
      mouseEnter: false, // 是否显示清空按钮
      showMsg: false, // 是否显示提示信息
      starCode: true, // 是否开始输入  防止多次触发keyup事件
      deptTreeNoInput: 'deptTreeInput' + (Math.random() + Math.random()), // 随机生成组件id
      dept: 'dept' + (Math.random() + Math.random()), // 随机生成组件id
      loading: false, // 远程加载loading动画
      timer: null, // 输入防抖定时器
      timerNum: 100, // 防抖时间
      expandAll: false, // 是否展开
      clickChoseTree: true // 是否点击树来选择选项 是的话不需要触发 v-model watch 的回绑方法 无需做搜索 并关闭下拉框
    }
  },
  mounted() {
    this.init()
  },
  beforeDestroy() {
    document.removeEventListener('click', this.documentEvent)
  },
  methods: {
    // 初始化函数
    init() {
      this.arrowUp = true
      this.mouseEnter = false
      this.showMsg = false
      this.loading = false
      this.starCode = true
      this.names = []
      this.addDocumentEvent()
      this.handleAnycModel()
    },
    treeItemHover(status, e) {
      if (status) {
        e.target.parentElement.style.backgroundColor = '#f2f4f9'
      }
    },
    treeItemLeave(status, e) {
      console.log(status)
      console.log(e)
      if (status) {
        e.target.parentElement.style.backgroundColor = '#fff'
      }
    },
    // 兼容外部异步获取数据 data 数据为空时候 会1s 请求一次 连续请求十次
    handleAnycModel() {
      let num = 0
      let func = () => {
        if (num > 10) return
        if (this.data.length) {
          this.handleModel(true)
        } else {
          setTimeout(() => {
            num = num + 1
            func()
          }, 1000)
        }
      }
      func()
    },
    // 搜索的时候过滤数据
    filterData(val) {
      // 远程搜索就不做本地数据过滤
      if (this.judge(this.remote)) {
        this.remoteSearch()
        if (!this.starCode) return
        if (this.judge(this.filter)) this.showOption()
        // 的时候把code置空
        this.departmentSelected[this.prop.code] = null
        this.starCode = false
      } else {
        this.showOption()
        this.$refs.deptTree.filter(val[this.prop.name])
      }
    },
    // 判断prop传过来的值 转为布尔值
    judge(param) {
      return param || param === ''
    },
    // 处理v-model回绑
    handleModel() {
      let name = this.prop.name
      let code = this.prop.code
      if (this.judge(this.multiple)) {
        this.names = []
        if (Array.isArray(this.defaultValue)) {
          let key = this.choseNode.key
          let value = this.choseNode.value
          this.defaultValue.forEach(val => {
            let obj = this.deepQuery(this.data, code, val)
            if (obj && obj[key] === value) {
              this.names.push({
                [code]: val,
                [name]: obj[name]
              })
            }
          })
        }
      } else {
        this.departmentSelected[code] = this.defaultValue
        let obj = this.deepQuery(this.data, code, this.defaultValue)
        if (obj) {
          this.departmentSelected[name] = obj[name]
        } else {
          this.departmentSelected[name] = ''
        }
      }
    },
    // 树形图 查找某一项
    deepQuery(tree, key, id) {
      let stark = []
      stark = stark.concat(tree)
      while (stark.length) {
        let temp = stark.shift()
        if (temp.children) {
          stark = temp.children.concat(stark)
        }
        if (id === temp[key]) {
          return temp
        }
      }
    },
    // 选择框点击事件 改变箭头方向
    inputClick() {
      if (this.judge(this.remote)) return
      if (this.judge(this.disabled)) return
      if (this.judge(this.hover)) return
      if (this.arrowUp) {
        this.showOption()
      } else {
        if (!this.arrowUp) this.hideOption()
      }
    },
    // 选择框鼠标移入事件
    inputMouseEnter() {
      if (this.judge(this.disabled)) return
      this.mouseEnter = true
      if (this.judge(this.remote)) return
      if (this.judge(this.hover)) this.showOption()
    },
    // 选择框鼠标移出事件
    inputMouseLeave() {
      this.mouseEnter = false
    },
    // 选择框清空事件
    clearInput(e) {
      e.stopPropagation()
      this.departmentSelected = {
        [this.prop.name]: '',
        [this.prop.code]: ''
      }
      if (!this.judge(this.multiple)) this.names = []
      this.hideOption()
      this.triggerModel()
      this.validate()
    },
    // 树形图选择某一选项事件
    handleHideTree(data, node) {
      this.clickChoseTree = true
      let key = this.choseNode.key
      let value = this.choseNode.value
      if (data[key] !== value) return
      let name = this.prop.name
      let code = this.prop.code
      if (this.judge(this.multiple)) {
        let index = this.names.findIndex(v => v[code] === data[code])
        if (index > -1) {
          this.names.splice(index, 1)
        } else {
          this.names.push({
            [name]: data[name],
            [code]: data[code]
          })
        }
        this.$nextTick(() => {
          this.adjustStyle()
        }) // 多选换行后加个边距
      } else {
        this.departmentSelected = {
          [name]: data[name],
          [code]: data[code]
        }
        this.names = []
        this.names.push({
          [name]: data[name],
          [code]: data[code]
        })
        this.hideOption()
      }
      this.triggerModel()
      this.validate()
    },
    // 多选的时候删除某一项
    delNamesItem(index) {
      this.names.splice(index, 1)
      this.$nextTick(() => {
        this.adjustStyle()
      }) // 多选换行后加个边距
    },
    // 是否为选中的选项 渲染样式
    isInNames(code) {
      return this.names.some(v => v[this.prop.code] === code)
    },
    // 下拉框输入框搜索事件
    handleFilterNode(value, data) {
      if (!value) return true
      return data[this.defaultProps.label].indexOf(value) !== -1
    },
    // 组件的鼠标移出事件 隐藏下拉选项
    deptTreeMouseLeave() {
      if (this.judge(this.hover)) this.hideOption()
    },
    //  组件移入事件
    deptTreeMouseEnter(e) {
      if (e.target.id === this.dept) this.inputMouseEnter()
    },
    // 窗口增加点击事件
    addDocumentEvent() {
      if (this.judge(this.hover)) return
      document.addEventListener('click', this.documentEvent)
    },
    // 点击除组件外的地方 隐藏下拉框
    documentEvent(e) {
      if (
        e.target.id !== this.deptTreeNoInput &&
        !document.getElementById(this.deptTreeNoInput).contains(e.target)
      ) {
        this.hideOption()
        // 如果没有选择 清空输入框 隐藏下拉框  远程搜索的时候不清空
        if (this.departmentSelected[this.prop.code] === null && !this.judge(this.remote))
          this.departmentSelected[this.prop.name] = ''
      }
    },
    // 远程搜索
    remoteSearch() {
      if (this.judge(this.remote) && typeof this.remoteMethod === 'function') {
        this.expandAll = true
        if (this.timer) clearTimeout(this.timer)
        this.timer = setTimeout(() => {
          this.loading = true
          this.remoteMethod(this.departmentSelected[this.prop.name])
        }, this.timerNum)
      }
    },
    // 触发 v-model 同步数据
    triggerModel() {
      if (this.judge(this.multiple)) {
        let codes = this.names.map(v => v[this.prop.code])
        this.$emit('input', codes)
        this.$emit('change', codes)
      } else {
        this.$emit('input', this.departmentSelected[this.prop.code])
        this.$emit('change', this.departmentSelected[this.prop.code])
      }
    },
    // 输入框失去焦点事件
    inputBlur() {
      this.starCode = true
      if (this.timer) clearTimeout(this.timer)
      this.validate()
      this.$emit('blur')
      this.handleWrapBlur()
    },
    // 输入框获得焦点事件
    inputFocus() {
      this.$emit('focus')
      this.handleWrapFocus()
      if (!this.judge(this.remote)) return
      this.showOption()
      if (this.departmentSelected[this.prop.name]) {
        this.expandAll = true
        if (typeof this.remoteMethod === 'function') {
          // 一打开就搜索
          // this.remoteSearch()
        } else {
          this.filterData(this.departmentSelected[this.prop.name])
        }
      }
    },
    handleWrapFocus() {
      let el = this.$el.getElementsByClassName('input-wrap')[0]
      console.log(el)
      if (el) {
        el.style.borderColor = '#11B2FF'
        el.style.boxShadow = '0px 0px 0px 2px rgba(17, 178, 255, 0.2)'
      }
    },
    handleWrapBlur() {
      let el = this.$el.getElementsByClassName('input-wrap')[0]
      if (el) {
        el.style.borderColor = '#DCDFE6'
        el.style.boxShadow = 'none'
      }
    },
    // 打开下拉框
    showOption() {
      this.arrowUp = false
      this.expandAll = false // 默认不展开树形图
      this.$nextTick(() => {
        this.scrollToSelect()
      })
    },
    // 计算选中项的高度 并把滚动条滚到此处
    scrollToSelect() {
      let el = document.getElementById(this.deptTreeNoInput)
      // let current = el.getElementsByClassName('is-current')[0]
      let current = el.getElementsByClassName('tree-slot')[0]
      let deptTree = el.getElementsByClassName('deptTree')[0]
      if (current) deptTree.scrollTop = this.getOffsetTop(current) - 400
    },
    // 多选换行后加边距
    adjustStyle() {
      let el = document.getElementById(this.deptTreeNoInput)
      let wrap = el.getElementsByClassName('input-wrap')[0]
      let height = parseFloat(window.getComputedStyle(wrap).height)
      let items = wrap.getElementsByClassName('item')
      let len = items.length
      if (height > 40) {
        for (let i = 0; i < len; i++) {
          items[i].style.marginTop = '5px'
        }
      } else {
        for (let i = 0; i < len; i++) {
          items[i].style.marginTop = '0px'
        }
      }
    },
    // 获取相对某元素的偏移量
    getOffsetTop(el, id) {
      return el.offsetParent && el.parentNode.id !== id
        ? el.offsetTop + this.getOffsetTop(el.offsetParent, id)
        : el.offsetTop
    },
    // 关闭下拉框
    hideOption() {
      this.arrowUp = true
      this.triggerModel()
    },
    // 下拉框验证
    validate() {
      let bool = false
      let dept = document.getElementById(this.dept)
      let suc = '1px solid #dcdfe6'
      let fail = '1px solid red'
      if (this.rule.require && !this.departmentSelected[this.prop.name]) {
        this.showMsg = true
        bool = false
        dept.style.border = fail
      } else {
        this.showMsg = false
        bool = true
        dept.style.border = suc
      }
      return bool
    },
    // 验证样式恢复
    resetFields() {
      let dept = document.getElementById(this.dept)
      let suc = '1px solid #dcdfe6'
      this.showMsg = false
      dept.style.border = suc
    }
  }
}
</script>

<style scoped lang="scss">
.DeptPersonTree {
  position: relative;
  .input-wrap {
    display: flex;
    justify-content: space-between;
    border: 1px solid #dcdfe6;
    /*height: 36px;*/
    align-items: center;
    padding-right: 5px;
    &:hover {
      border-color: #11b2ff !important;
    }
    .item-wrap {
      display: flex;
      flex-wrap: wrap;
      padding: 0 5px;
      align-items: center;
      .item {
        /*height: 22px;*/
        /*line-height: 20px;*/
        /*margin: 0px 5px 0 0;*/
      }
      .dept {
        max-width: 80px;
        display: flex;
        align-items: center;
        .el-input__inner {
          padding: 0px;
        }
      }
    }
    .el-icon-caret-bottom {
      align-self: center;
      color: #3d424d;
      margin-right: 5px;
    }
    .arrowup {
      transform: rotate(-180deg);
      transition: transform 0.3s linear;
    }
    .arrowdown {
      transform: rotate(0deg);
      transition: transform 0.3s linear;
    }
  }
  .dept {
    cursor: pointer;
    .el-input__suffix {
      display: flex;
      align-items: center;
      i {
        color: #3d424d;
        font-size: 15px;
        margin-right: 5px;
      }
      .el-icon-circle-close {
        margin-right: 1px;
      }
      .arrowup {
        transform: rotate(-180deg);
        transition: transform 0.3s linear;
      }
      .arrowdown {
        transform: rotate(0deg);
        transition: transform 0.3s linear;
      }
    }
  }
  .opticy {
    height: 12px;
    width: 100%;
    /*background: red;*/
  }
  .options {
    z-index: 1000;
    position: absolute;
    top: 50px;
    min-width: 100%;
    padding-top: 20px;
    padding-bottom: 20px;
    background-color: #fff;
    box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.1);
    border: 1px solid #e4e7ed;
    border-radius: 4px;
    .arrow {
      position: absolute;
      left: 30px;
      top: -7px;
      height: 12px;
      width: 12px;
      background: #ffffff;
      transform: rotate(45deg);
      border-top: 1px solid #d1d1d1;
      border-left: 1px solid #d1d1d1;
      z-index: 20;
    }
    .dept-search {
      padding: 0 20px;
      margin-bottom: 5px;
      box-sizing: border-box;
    }
    .deptTree {
      overflow-y: scroll;
      /*overflow-x: scroll;*/
      max-height: 300px;
      min-width: 200px;
      /*<!--margin-right: -9px;-->*/
      padding-right: 8px;
      .common-tree-slot {
        font-family: PingFangSC-Medium;
        font-size: 14px;
        color: #3d424d;
        letter-spacing: 0;
        .el-icon-check {
          font-size: 12px;
          &:before {
            /*position: absolute;*/
            /*right: 20px;*/
            /*font-family: 'element-icons';*/
            /*content: "\E6DA";*/
            /*font-size: 12px;*/
            /*font-weight: bold;*/
            /*-webkit-font-smoothing: antialiased*/
          }
        }
      }
      .tree-slot {
        box-sizing: border-box;
        padding: 0 10px 0 0;
        height: 26px;
        width: 100%;
        background: #f2f4f9;
        color: #11b2ff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        i {
          transform: scale(1.3);
          font-weight: normal;
        }
      }
    }
    ::-webkit-scrollbar {
      display: none;
    }
  }
  .showMsg {
    position: absolute;
    color: #f56c6c;
    line-height: 1;
    font-size: 12px;
    padding-top: 4px;
    top: 100%;
    left: 0;
  }
}
</style>

<style lang="scss">
.DeptPersonTree {
  .input-wrap {
    .dept {
      height: 34px;
      input {
        border: none !important;
        height: 32px !important;
        padding: 0 0 0 10px;
        &:focus {
          box-shadow: none;
        }
      }
    }
  }
  .el-loading-spinner i {
    color: #ccc;
  }
  .dept {
    input {
      cursor: pointer;
      height: 36px;
    }
  }
  .single {
    .el-input__inner {
      &:hover {
        border-color: #11b2ff !important;
      }
      &:focus {
        border-color: #11b2ff !important;
        box-shadow: 0px 0px 0px 2px rgba(17, 178, 255, 0.2);
      }
    }
  }
  .options {
    // 展开收起icon
    .el-tree-node__expand-icon {
      transition: transform linear 0.2s;
      &:before {
        content: '';
        display: flex;
        height: 14px;
        width: 14px;
        background: url('../../assets/images/tree-unfold.png') no-repeat;
      }
    }
    .expanded {
      transform: rotate(0deg);
      &:before {
        background: url('../../assets/images/tree-fold.png') no-repeat;
      }
    }
    .is-leaf {
      &:before {
        background: none;
        width: 3px;
      }
    }
    .el-tree-node {
      position: relative;
      padding-left: 10px;
      margin: 5px 0px;
    }
    .el-tree-node__children {
      padding-left: 10px;
    }
    .el-tree-node :last-child:before {
      height: 38px;
    }
    .el-tree > .el-tree-node:before {
      border-left: none;
    }
    .el-tree > .el-tree-node:after {
      border-top: none;
    }
    .el-tree-node:before,
    .el-tree-node:after {
      content: '';
      left: -1px;
      position: absolute;
      right: auto;
      border-width: 1px;
    }
    .tree :first-child .el-tree-node:before {
      border-left: none;
    }
    .el-tree-node:before {
      border-left: 1px dashed #dcdfe6;
      /*border-left: 1px dashed green;*/
      bottom: 0px;
      height: 108%;
      top: -25px;
      width: 1px;
    }
    .el-tree-node:after {
      border-top: 1px dashed #dcdfe6;
      /*border-top: 1px dashed red;*/
      height: 20px;
      top: 12px;
      width: 15px;
    }
    .el-tree-node__content {
      padding-left: 0px !important;
    }
    .el-tree-node__content > .el-tree-node__expand-icon {
      padding: 3px;
    }
    .el-tree--highlight-current .el-tree-node.is-current > .el-tree-node__content {
      background: #ffffff;
    }
    .el-tree-node__content:hover {
      background: #ffffff;
    }
  }
}
</style>
