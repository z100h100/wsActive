<template>
  <div class="mask" v-show="visiable" @click="closeLayer">
    <div @click.stop v-loading="loading" :class="visiable ? 'layerRight left' : 'layerRight right'">
      <p class="dialogTitle">
        {{ title }}
        <span>
          <i class="el-icon-close" @click="closeLayer"></i>
        </span>
      </p>
      <div class="detail_content">
        <slot name="content">
          detail
        </slot>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'detail',
  data() {
    return {
      loading: false
    }
  },
  props: {
    show: {
      type: Boolean
    },
    title: {
      type: String,
      default: () => {
        return 'title'
      }
    }
  },
  computed: {
    visiable() {
      return this.show
    }
  },
  filters: {},
  mounted() {},
  methods: {
    closeLayer() {
      this.$emit('closeLayer')
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/common.scss';
.mask {
  height: 100%;
  overflow: hidden;
  position: fixed;
  top: 0px;
  right: 0px;
  width: 100%;
  background: rgba(0, 0, 0, 0.3);
  z-index: 3333;
  .dialogTitle {
    padding: 20px;
    margin: 0;
    font-size: 16px;
    color: #25282f;
    border-bottom: 1px solid #e9ecf4;
    font-weight: 600;

    /deep/ .el-icon-close {
      float: right;
      cursor: pointer;
      color: #999999;
      margin-top: 5px;
      font-weight: bold;
    }
    :hover {
      color: #00c1de;
    }
  }
  .detail_content {
    padding: 20px;
    height: calc(100vh - 45px);
    overflow-y: scroll;
    div {
      p {
        padding: 10px;
        margin: 0;
      }
    }
    .title {
      p {
        font-size: 14px;
        &:last-child {
          font-size: 12px;
        }
      }
    }
  }
  // 动作
  .layerRight {
    position: absolute;
    top: 0;
    width: 478px;
    right: 0;
    height: 100vh;
    background: #fff;
  }
  .left {
    -webkit-animation: mymoveLeft 0.3s; /*Safari and Chrome*/
  }
  .right {
    -webkit-animation: mymoveright 0.3s; /*Safari and Chrome*/
  }
  @-webkit-keyframes mymoveLeft {
    from {
      right: -478px;
    }
    to {
      right: 0px;
    }
  }
  @-webkit-keyframes mymoveright {
    from {
      right: 0px;
    }
    to {
      right: -478pxpx;
    }
  }
}
</style>
