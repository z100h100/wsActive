/** * @author * @date 2019/5/17 */
<template>
  <div>
    <el-dialog
      class="no-padding"
      title="环境配置"
      :visible.sync="dialogListVisible"
      width="40%"
      :before-close="closeAddStore"
    >
      <el-form size="small" label-width="130px" ref="envForm" :model="envConfigForm">
        <el-tabs v-model="tabs">
          <!-- 基础信息 -->
          <el-tab-pane label="基础配置" name="基础配置" class="tab-pane-style">
            <el-table
              :data="envConfigForm.basic"
              width="100%"
              max-height="300"
              highlight-current-row
            >
              <el-table-column property="label" label="变量">
                <template slot-scope="scope">
                  {{ scope.row.key }}
                </template>
              </el-table-column>
              <el-table-column property="value" label="值">
                <template slot-scope="scope">
                  {{ scope.row.value }}
                </template>
              </el-table-column>
              <el-table-column property="value" width="100" :label="$t('common.operateLabel')">
                <template slot-scope="scope">
                  <a
                    href="javascript:;"
                    class="tableActionStyle"
                    @click="deleteItem(scope.row, 'envVariables')"
                    >删除</a
                  >
                </template>
              </el-table-column>
            </el-table>
          </el-tab-pane>

          <!-- 环境变量 -->
          <el-tab-pane label="环境变量" name="环境变量" class="tab-pane-style">
            <el-table :data="envConfigForm.envVariables" width="100%" highlight-current-row>
              <el-table-column property="key" label="变量">
                <template slot-scope="scope">
                  {{ scope.row.key }}
                </template>
              </el-table-column>
              <el-table-column property="value" label="值">
                <template slot-scope="scope">
                  {{ scope.row.value }}
                </template>
              </el-table-column>
              <el-table-column property="value" width="140" :label="$t('common.operateLabel')">
                <template slot-scope="scope">
                  <a
                    v-show="!scope.row.isNew"
                    href="javascript:;"
                    class="tableActionStyle"
                    @click="editItem(scope.row, 'envVariables')"
                    >编辑</a
                  >
                  <a
                    v-show="scope.row.isNew"
                    href="javascript:;"
                    class="tableActionStyle"
                    @click="sureItem(scope.row)"
                    >确认</a
                  >
                  <a
                    href="javascript:;"
                    class="tableActionStyle"
                    @click="deleteItem(scope.row, 'envVariables')"
                    >设为禁用</a
                  >
                </template>
              </el-table-column>
            </el-table>
            <div class="add-row-div-style">
              <el-button
                class="addRowBtn dashed"
                icon="el-icon-plus"
                size="mini"
                @click="addNewItem('envVariables')"
                >添加环境变量</el-button
              >
            </div>
          </el-tab-pane>

          <!-- ip别名 -->
          <el-tab-pane label="IP别名" name="IP别名" class="tab-pane-style">
            <el-table
              :data="envConfigForm.ipAlias"
              width="100%"
              max-height="300"
              highlight-current-row
            >
              <el-table-column property="key" label="变量">
                <template slot-scope="scope">
                  {{ scope.row.key }}
                </template>
              </el-table-column>
              <el-table-column property="value" label="值">
                <template slot-scope="scope">
                  {{ scope.row.value }}
                </template>
              </el-table-column>
              <el-table-column property="value" width="100" :label="$t('common.operateLabel')">
                <template slot-scope="scope">
                  <a
                    href="javascript:;"
                    class="tableActionStyle"
                    @click="deleteItem(scope.row, 'envVariables')"
                    >删除</a
                  >
                </template>
              </el-table-column>
            </el-table>
            <div class="add-row-div-style">
              <el-button
                class="addRowBtn dashed"
                icon="el-icon-plus"
                size="mini"
                @click="addNewItem('ipAlias')"
                >添加环境变量</el-button
              >
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeAddStore">取消</el-button>
        <el-button type="primary" @click="sbumitStore">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'index',
  data() {
    return {
      dialogListVisible: false,
      envConfigForm: {
        basic: [{ key: '1', value: '1' }, { key: '2', value: '2' }],
        envVariables: [{ isNew: false, key: '1', value: '1' }],
        ipAlias: [{ key: '11', value: '11' }]
      },
      tabs: '基础配置',
      storeForm: {
        label: '',
        label2: '',
        active: true,
        num: '',
        id: '',
        name: ''
      },
      storeRules: {
        num: [{ required: true, message: '请输入活动名称', trigger: 'blur' }],
        name: [{ required: true, message: '请输入设备名称', trigger: 'blur' }],
        label: [{ required: true, message: '请输入标签', trigger: 'blur' }],
        id: [{ required: true, message: '请输入ID', trigger: 'blur' }]
      },
      options: [
        {
          value: '选项1',
          label: '黄金糕'
        },
        {
          value: '选项2',
          label: '双皮奶'
        },
        {
          value: '选项3',
          label: '蚵仔煎'
        },
        {
          value: '选项4',
          label: '龙须面'
        },
        {
          value: '选项5',
          label: '北京烤鸭'
        }
      ]
    }
  },
  methods: {
    openDialogListMethod() {
      this.dialogListVisible = true
    },
    addNewItem(type) {
      this.envConfigForm[type].push({ isNew: true, label: '', value: '' })
    },
    editItem(val) {
      val.isNew = true
    },
    sureItem(val) {
      val.isNew = false
    },
    deleteItem() {},
    closeAddStore() {
      this.$refs.envForm.resetFields()
      this.dialogListVisible = false
    },
    sbumitStore() {
      this.closeAddStore()
    }
  }
}
</script>

<style lang="scss" scoped>
.add-row-div-style {
  text-align: center;
  border-bottom: 1px solid #e8edf1;
  width: 100%;
  padding: 6px 0;
  background: #f7f8fc;
}
/deep/ .el-tabs__item {
  min-width: 130px;
  text-align: center;
  font-size: 15px;
  line-height: 40px;
}
.no-padding {
  /deep/ {
    .el-dialog__body {
      padding-top: 5px;
    }
  }
}
/deep/ .el-table__header {
  tr th:first-child .cell {
    padding-left: 30px;
  }
}
/deep/ .el-table__row {
  td:first-child .cell {
    padding-left: 30px;
  }
}
.addRowBtn {
  background: #f2f4f9;
  border: 1px solid #c3c7ce;
  &:hover,
  &:focus {
    background: #e8f9ff;
    border: 1px solid #76d3ff;
  }
}
</style>
