<template>
  <div>
    <transition @leave="leaveMethod" @before-enter="beforeEnterMethod" @enter="enterMethod">
      <div v-loading="pageLoad" v-show="personShow" class="person-management-style">
        <div class="person-title-style">
          <div class="title-span-style">
            <span
              >{{ projectName
              }}<span style="margin-left: 10px;">({{ personManagementList.length }})</span></span
            >
            <i class="el-icon-close close-icon-style" @click="closePerson"></i>
          </div>
        </div>
        <div style="padding: 20px 20px 10px;">
          <el-input
            size="small"
            clearable
            @keyup.enter.native="getProjectPersonListMethod"
            @input="resetPersonMethod"
            v-model="personSearchFrom.f_like_name_or_code"
            placeholder="搜索成员"
            :suffix-icon="searchIcon"
          ></el-input>
        </div>
        <div v-if="showAddButton" class="person-value-div-style">
          <div
            v-if="getResourceAuthMethod(resources, ['RELEASEOPERATIONADDUSER'])"
            class="person-add-style"
            @click="openAddPersonDialog"
          >
            <i class="el-icon-plus"></i>
          </div>
          <span class="person-add-span-style">添加项目成员</span>
        </div>
        <div v-if="imageShow" class="img-style">
          <div>
            <img style="margin-left: 40px;height: 42px;width: 42px;" :src="imgNoData" />
            <span style="display: block">没有符合条件的成员</span>
          </div>
        </div>
        <div class="person-info-div-style">
          <el-table
            ref="userTable"
            highlight-current-row
            class="person-value"
            @row-click="setCurrent"
            :data="personManagementList"
            style="width: 100%"
          >
            <el-table-column align="right" width="60">
              <template slot-scope="scope">
                <div
                  :class="{
                    'person-value-style': true,
                    'person-one-value-style':
                      scope.row.role == 'RELEASEAXAPTA' || scope.row.role == 'RELEASEADMIN'
                  }"
                >
                  <span>{{ scope.row.name ? scope.row.name.substring(0, 1) : '' }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column>
              <template slot-scope="scope">
                <div class="person-value-font-style">
                  <span>{{ scope.row.name }}-{{ scope.row.code }}</span>
                  <span>{{ getRoleName(scope.row.role) }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column width="80">
              <template slot-scope="scope">
                <div class="operation-div-style">
                  <span style="width: 25px;display: inline-block">
                    <el-popover placement="bottom" trigger="click">
                      <el-radio-group
                        class="userRole"
                        :disabled="editLoad"
                        @change="editPerson"
                        v-model="roleData.role"
                      >
                        <el-radio label="RELEASEPUBLICUSER">普通人员</el-radio>
                        <el-radio v-if="getRoleValue(role) > 1" label="RELEASEBRICKCARRIER"
                          >开发人员</el-radio
                        >
                        <el-radio v-if="getRoleValue(role) > 2" label="RELEASEAXAPTA"
                          >项目负责人</el-radio
                        >
                      </el-radio-group>
                      <i
                        v-show="
                          scope.row.origin != 0 &&
                            getRoleValue(role) > getRoleValue(scope.row.role) &&
                            getResourceAuthMethod(resources, ['RELEASEOPERATIONADDROLE'])
                        "
                        slot="reference"
                        class=" el-icon-edit operation-icon-style"
                        @click="personEditMethod(scope.row)"
                      ></i>
                    </el-popover>
                  </span>
                  <span style="width: 25px;display: inline-block"
                    ><i
                      v-show="
                        scope.row.origin != 0 &&
                          getRoleValue(role) > getRoleValue(scope.row.role) &&
                          getRoleValue(role) > 1 &&
                          getResourceAuthMethod(resources, ['RELEASEOPERATIONDELETEUSER'])
                      "
                      class="el-icon-close operation-icon-style"
                      @click="personDeleteMethod(scope.row.name, scope.row.userName)"
                    ></i
                  ></span>
                </div>
              </template>
            </el-table-column>
          </el-table>
          <div v-show="commonPersonList.length > 0" class="other-add-div-style">
            我们在公司中找到如下成员:
          </div>
          <div
            v-show="commonPersonList.length > 0"
            class="person-value-div-style1"
            v-for="item in commonPersonList"
            :key="item.id"
          >
            <div class="person-value-style1">
              <div
                :class="{
                  'person-value-style': true,
                  'person-one-value-style': item.type == '项目经理'
                }"
              >
                <span>{{ item.name ? item.name.substring(0, 1) : '' }}</span>
              </div>
              <div class="person-value-font-style" style="margin-left: 12px">
                <span>{{ item.name }}-{{ item.code }}</span>
              </div>
            </div>
            <div class="operation-div-style">
              <el-button
                @click="joinProjectPerson(item)"
                class="grayBtn"
                :disabled="joinLoad && item.id == joinId"
                size="small"
                >加入项目</el-button
              >
            </div>
          </div>
        </div>
        <div class="link-auth-style">
          <span
            >更多信息，请至
            <a @click="linkAuthMethod" class="tableActionStyle">统一权限</a>
            设置
          </span>
        </div>
      </div>
    </transition>
    <el-dialog
      class="terminal-dialog addUser"
      title="添加项目成员"
      :visible.sync="personVisible"
      @close="closePersonMethod"
      width="500px"
    >
      <div class="dialog-edit-form-wrapper">
        <el-form :model="personAddForm" :rules="personValidate" ref="personAddForm">
          <el-form-item prop="personData">
            <el-select
              size="small"
              class="dialog-select-style"
              v-model="personAddForm.personData"
              multiple
              filterable
              remote
              :reserve-keyword="false"
              :remote-method="getSelectPersonList"
              value-key="id"
              :loading="selectLoading"
              @change="selectChange"
              ref="remotepeople"
              placeholder="请输入项目成员名称"
            >
              <el-option
                v-for="item in selectPersonList"
                :key="item.id"
                :label="item.name + '-' + item.deptName"
                :value="item"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer ">
        <span style="margin-right: 100px;"
          >没找到相应人员？请先进入
          <a @click="linkAuthMethod" class="tableActionStyle">统一权限</a>
          添加吧
        </span>
        <el-button @click="addProjectPerson()" :disabled="saveLoad" type="primary"
          >添加成员</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import imgNoData from '@/assets/images/imgNoData.png'
export default {
  name: 'index',
  data() {
    return {
      role: '',
      resources: [],
      showAddButton: true,
      imageShow: false,
      imgNoData,
      projectName: '',
      personShow: false,
      personVisible: false,
      selectLoading: false,
      saveLoad: false,
      joinLoad: false,
      joinId: '',
      pageLoad: false,
      editLoad: false,
      roleData: {
        role: ''
      },
      // 项目人员
      personSearchFrom: {
        f_eq_projectMark: '',
        f_like_name_or_code: '',
        paging: false
      },
      // 普通人员
      commonPersonSearchFrom: {
        projectMark: '',
        name: ''
      },
      personAddForm: {
        personData: []
      },
      // 项目列表
      personManagementList: [],
      // 普通人员列表
      commonPersonList: [],
      // 人员添加下拉数据
      selectPersonList: [],
      searchIcon: 'el-icon-search',
      currentRow: {}
    }
  },

  methods: {
    ...mapActions([
      'getProjectPersonListApi',
      'getPersonListApi',
      'deleteProjectPersonApi',
      'setProjectPersonApi',
      'setAllProjectPersonApi',
      'editProjectPersonApi',
      'refreshRole'
    ]),
    // 设置高亮
    setHighlight() {
      let currentRowIndex
      this.personManagementList.forEach((item, index) => {
        if (item.id == this.currentRow) {
          currentRowIndex = index
        }
      })
      this.$refs.userTable.setCurrentRow(this.personManagementList[currentRowIndex])
    },
    setCurrent(row) {
      this.currentRow = row.id
    },
    // 判断权限
    getResourceAuthMethod(resource, auth) {
      if (resource) {
        let count = 0
        auth.map(item => {
          if (resource.indexOf(item) > -1) {
            count++
          }
        })
        return count > 0
      } else {
        return false
      }
    },
    // 判断删除
    getRoleValue(role) {
      if (role == 'RELEASEPUBLICUSER') {
        return 0
      } else if (role == 'RELEASEBRICKCARRIER') {
        return 1
      } else if (role == 'RELEASEAXAPTA') {
        return 2
      } else if (role == 'RELEASESUPERADMIN') {
        return 3
      } else if (role == 'RELEASEADMIN') {
        return 4
      } else {
        return -1 // 无角色
      }
    },
    // 获取角色名称
    getRoleName(id) {
      if (id == 'RELEASEPUBLICUSER') {
        return '普通人员'
      } else if (id == 'RELEASEBRICKCARRIER') {
        return '开发人员'
      } else if (id == 'RELEASEAXAPTA') {
        return '项目负责人'
      } else if (id == 'RELEASESUPERADMIN') {
        return '超级管理员'
      } else if (id == 'RELEASEADMIN') {
        return '项目拥有者'
      }
    },
    selectChange() {
      this.$nextTick(function() {
        this.$refs.remotepeople.blur()
      })
    },
    // 列表添加项目成员
    joinProjectPerson(item) {
      if (item) {
        let objectTemp = {
          projectMark: this.personSearchFrom.f_eq_projectMark || '',
          userEmail: item.email || '',
          status: '0',
          code: item.code || '',
          name: item.name || '',
          userName: item.username || ''
        }
        this.joinId = item.id
        this.joinLoad = true
        let params = Object.assign(objectTemp)
        this.saveProjectPerson(params)
      }
    },
    // dialog添加项目成员方法
    addProjectPerson() {
      this.$refs['personAddForm'].validate(val => {
        if (val) {
          let val = this.personAddForm.personData
          let objectTemp = {
            projectMark: this.personSearchFrom.f_eq_projectMark || '',
            userEmail: '',
            code: '',
            name: '',
            userName: ''
          }
          let paramsArray = []
          val.map(item => {
            objectTemp = {
              projectMark: this.personSearchFrom.f_eq_projectMark || '',
              userEmail: '',
              code: '',
              name: '',
              userName: ''
            }
            Object.assign(objectTemp, {
              userName: item.username,
              userEmail: item.email,
              code: item.code,
              name: item.name
            })
            paramsArray.push(objectTemp)
          })
          this.saveLoad = true
          let params = Object.assign(paramsArray)
          this.saveAllProjectPerson(params)
        }
      })
    },
    // 批量添加项目成员
    saveAllProjectPerson(params) {
      this.setAllProjectPersonApi(params)
        .then(res => {
          this.saveLoad = false
          if (res && res.code == '0' && res.status == 200) {
            this.$message({
              type: 'success',
              message: '保存成功'
            })
            this.personVisible = false
            this.saveLoad = false
            this.getProjectPersonListMethod()
          } else {
            this.$message({
              type: 'error',
              message: res.message || '保存失败'
            })
          }
        })
        .catch(() => {
          this.saveLoad = false
        })
    },
    // 添加项目成员方法
    saveProjectPerson(params) {
      this.setProjectPersonApi(params)
        .then(res => {
          this.joinLoad = false
          this.joinId = ''
          if (res && res.code == '0' && res.status == 200) {
            this.$message({
              type: 'success',
              message: '保存成功'
            })
            this.personVisible = false
            this.joinLoad = false
            this.joinId = ''
            this.getProjectPersonListMethod()
          } else {
            this.$message({
              type: 'error',
              message: res.message || '保存失败'
            })
          }
        })
        .catch(() => {
          this.joinLoad = false
          this.joinId = ''
        })
    },
    // 下拉人员数据查询
    getSelectPersonList(query) {
      if (query) {
        this.selectLoading = true
        let params = Object.assign({
          projectMark: this.personSearchFrom.f_eq_projectMark,
          name: query,
          paging: true,
          pageNo: 0,
          pageSize: 200
        })
        this.getPersonListApi(params)
          .then(res => {
            this.selectLoading = false
            if (res && res.result) {
              if (query) {
                this.selectPersonList = res.result
              } else {
                this.selectPersonList = []
              }
            } else {
              this.selectPersonList = []
            }
          })
          .catch(() => {
            this.selectLoading = false
          })
      } else {
        this.selectPersonList = []
      }
    },
    // 人员编辑
    personEditMethod(row) {
      Object.assign(this.roleData, row)
    },
    editPerson(val) {
      /* let params = Object.assign({
									role: val,
									userName: this.roleData.userName,
									projectMark: this.personSearchFrom.f_eq_projectMark
							})
							this.editLoad = true
							this.editProjectPersonApi(params).then(res => {
									this.editLoad = false
									if (res && res.code == '0' && res.status == 200) {
											this.$message({
													type: 'success',
													message: '保存成功'
											})
											this.getProjectPersonListMethod()
									} else {
											this.$message({
													type: 'error',
													message: res.message || '保存失败'
											})
									}
							}).catch((err) => {
									this.editLoad = false
									this.$message({
											type: 'error',
											message: err.message || '保存失败'
									})
							}) */
    },
    // 跳转统一权限
    linkAuthMethod() {
      /* let authUrl = ''
							if (window.ajaxAuthUrl.indexOf('http') !== -1) {
									authUrl = window.ajaxAuthUrl
							} else {
									authUrl = window.location.origin + window.ajaxAuthUrl
							}
							authUrl += '/#/view/basicPage'
							window.open(authUrl) */
    },
    // 打开初始化方法
    openPageMethod(mark, role, name, resources) {
      this.projectName = name
      this.personShow = true
      this.role = role
      this.resources = resources
      this.personSearchFrom.f_eq_projectMark = mark
      this.personSearchFrom.f_like_name_or_code = ''
      this.getProjectPersonListMethod()
      document.getElementsByTagName('body')[0].classList.add('noScroll')
    },
    // 获取默认状态
    resetPersonMethod(val) {
      if (!val) {
        this.getProjectPersonListMethod()
        this.searchIcon = 'el-icon-search'
      } else {
        this.searchIcon = ''
      }
    },
    // 获取项目人员信息
    getProjectPersonListMethod() {
      let params = Object.assign(this.personSearchFrom)
      this.pageLoad = true
      this.getProjectPersonListApi(params)
        .then(res => {
          this.pageLoad = false
          if (res && res.result) {
            this.personManagementList = res.result.data
            if (this.personSearchFrom.f_like_name_or_code) {
              this.getPersonListMethod(
                this.personSearchFrom.f_eq_projectMark,
                this.personSearchFrom.f_like_name_or_code
              )
              this.showAddButton = false
              if (this.personManagementList.length == 0) {
                this.imageShow = true
              } else {
                this.imageShow = false
              }
            } else {
              this.commonPersonList = []
              this.showAddButton = true
              if (this.personManagementList.length == 0) {
                this.imageShow = true
              } else {
                this.imageShow = false
              }
            }
          } else {
            this.personManagementList = []
            this.commonPersonList = []
            this.showAddButton = true
            if (this.personManagementList.length == 0) {
              this.imageShow = true
            } else {
              this.imageShow = false
            }
          }
          this.setHighlight()
        })
        .catch(() => {
          this.pageLoad = false
        })
    },
    // 获取人员信息
    getPersonListMethod(mark, userName) {
      this.pageLoad = true
      let params = Object.assign({
        projectMark: mark,
        name: userName,
        paging: true,
        pageNo: 0,
        pageSize: 200
      })
      this.getPersonListApi(params)
        .then(res => {
          this.pageLoad = false
          if (res && res.result) {
            this.commonPersonList = res.result
          } else {
            this.commonPersonList = []
          }
        })
        .catch(() => {
          this.pageLoad = false
        })
    },
    // 人员删除
    personDeleteMethod(name, username) {
      this.$confirm(`是否确认要删除${name}的相关权限？`, '确认删除?', {
        confirmButtonText: '是',
        cancelButtonText: '否',
        type: 'warning'
      })
        .then(val => {
          if (val) {
            let params = Object.assign({
              projectMark: this.personSearchFrom.f_eq_projectMark,
              userName: username
            })
            this.deleteProjectPersonApi(params).then(res => {
              if (res && res.code == '0' && res.status == 200) {
                this.$message({
                  type: 'success',
                  message: '删除成功'
                })
                this.getProjectPersonListMethod()
              } else {
                this.$message({
                  type: 'error',
                  message: res.message || '删除失败'
                })
              }
            })
          }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '操作已取消！'
          })
        })
    },
    leaveMethod(el, done) {
      $(el).animate(
        {
          width: '0',
          opacity: 1
        },
        {
          duration: 500,
          complete: done
        }
      )
    },
    beforeEnterMethod(el) {
      $(el).css({
        width: '0',
        opacity: 1
      })
    },
    enterMethod(el, done) {
      $(el).animate(
        {
          width: '386px',
          opacity: 1
        },
        {
          duration: 500,
          complete: done
        }
      )
    },
    // 关闭人员管理
    closePerson() {
      this.personShow = false
      this.joinLoad = false
      this.showAddButton = true
      this.imageShow = false
      Object.assign(this.personSearchFrom, {
        f_eq_projectMark: '',
        f_like_name_or_code: '',
        paging: false
      })
      // 项目列表
      this.personManagementList = []
      // 普通人员列表
      this.commonPersonList = []
      document.getElementsByTagName('body')[0].classList.remove('noScroll')
    },
    // 打开新增人员弹窗
    openAddPersonDialog() {
      this.personVisible = true
    },
    // 新增人员弹窗关闭事件
    closePersonMethod() {
      this.selectPersonList = []
      this.saveLoad = false
      this.$refs['personAddForm'].resetFields()
    }
  },
  computed: {
    personValidate() {
      return {
        personData: [{ required: true, message: '项目成员不可为空', trigger: 'change' }]
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
.img-style {
  display: flex;
  justify-content: center;
  margin-top: 36px;
}
.person-management-style {
  position: fixed;
  height: 100%;
  width: 386px;
  float: right;
  right: 0;
  background: #ffffff;
  border-radius: 2px;
  z-index: 999;
  margin-top: -70px;
  display: flex;
  flex-direction: column;
  box-shadow: -4px 0px 8px 0px rgba(0, 0, 0, 0.1);
  ::-webkit-scrollbar {
    /*display: none;*/
  }
}
/*标题div样式*/
.person-title-style {
  height: 60px;
  border-bottom: solid 1px #ebeef5;
  padding: 0 20px;
}
/*标题样式*/
.title-span-style {
  display: flex;
  flex-wrap: nowrap;
  justify-content: space-between;
  padding-top: 19px;
  & span {
    font-size: 16px;
    color: #3d4652;
    letter-spacing: 0;
    font-weight: 600;
  }
  & i {
    color: #999999;
    font-size: 16px;
    &:hover {
      cursor: pointer;
    }
  }
}
.title-info-div-style {
  & span {
    font-size: 12px;
    color: #7e828c;
    letter-spacing: 0;
  }
  span:nth-child(2) {
    margin-right: 20px;
  }
  & i {
    margin-right: 5px;
  }
}
/*人员内容div样式*/
.person-info-div-style {
  flex: 1;
  /*margin: 0 20px 10px 20px;*/
  overflow-y: auto;
}
.person-add-span-style {
  margin-left: 20px;
  line-height: 40px;
  font-size: 14px;
  color: #6c747e;
}
.person-value-div-style {
  height: 50px;
  margin: 0 0 0 0;
  padding: 10px 20px 0;
  display: flex;
  flex-wrap: nowrap;
  justify-content: left;
  /*&:hover {
					background: #1f2d3d;
			}*/
}
/*未添加人员信息div样式*/
.other-add-div-style {
  font-size: 12px;
  color: #606266;
  letter-spacing: 0;
  padding-left: 20px;
  padding-top: 40px;
}
.person-value-div-style1 {
  height: 60px;
  padding: 10px 20px;
  display: flex;
  flex-wrap: nowrap;
  justify-content: space-between;
  &:hover {
    background: #ecf5ff;
    .operation-div-style {
      display: block;
    }
  }
}
/*底部样式*/
.link-auth-style {
  height: 42px;
  width: 100%;
  border-top: solid 1px #ebeef5;
  background: #ffffff;
  line-height: 40px;
  padding-left: 15px;
  color: #909399;
}
.person-value-style1 {
  display: flex;
  flex-wrap: nowrap;
  justify-content: left;
}
/*人员添加样式*/
.person-add-style {
  border: 1px solid #dcdfe6;
  height: 40px;
  width: 40px;
  line-height: 45px;
  text-align: center;
  border-radius: 2px;
  & i {
    color: #989ea8;
    border-radius: 1px;
    font-size: 18px;
    font-weight: 600;
  }
  &:hover {
    cursor: pointer;
  }
}
/*人员信息样式*/
.person-value-style {
  height: 40px;
  width: 40px;
  background: #98c4ea;
  border-radius: 2px;
  line-height: 40px;
  text-align: center;
  float: right;
  & span {
    font-size: 18px;
    color: #ffffff;
    letter-spacing: 0;
    font-weight: bold;
  }
}
.person-one-value-style {
  background: #eabf98;
}
/*人员信息字体样式*/
.person-value-font-style {
  display: flex;
  flex-direction: column;
  justify-content: center;
  /*margin-left: 20px;*/
  & span:nth-child(1) {
    font-size: 14px;
    color: #49505c;
    font-weight: 600;
    letter-spacing: 0;
    display: block;
  }
  & span:nth-child(2) {
    font-size: 12px;
    color: #7e828c;
    letter-spacing: 0;
    display: block;
  }
}
.operation-div-style {
  line-height: 40px;
  right: 10px;
  /*display: none;*/
  & i {
    margin-left: 10px;
  }
}
/*操作按键样式*/
.operation-icon-style {
  color: $primary-color;
  &:hover {
    cursor: pointer;
  }
}
.dialog-select-style {
  width: 380px;
  margin: auto;
}
/deep/ .el-form-item__error {
  left: 60px;
}
.dialog-edit-form-wrapper {
  max-height: 400px;
  overflow-y: auto;
  margin-top: 24px;
  /deep/ .el-form-item {
    margin-bottom: 24px;
  }
}
/*操作标签样式*/

.el-icon-edit,
.el-icon-close {
  font-size: 14px;
  font-weight: bold;
}
.addUser {
  /deep/ .dialog-footer .el-button {
    margin-right: 10px;
  }
  /deep/ .el-form-item__content {
    text-align: center;
  }
}
.userRole {
  background: #fff;
  .el-radio {
    display: block;
    line-height: 30px;
    margin-left: 0 !important;
  }
}
.person-value {
  margin-top: 9px;
  &:before {
    height: 0;
  }
  /deep/ {
    .el-table__header-wrapper {
      display: none;
    }
    td {
      border: 0;
      padding: 7px 0;
    }
    .cell {
      padding: 0px 0 0 12px;
    }
    .el-table__empty-block {
      display: none;
    }
  }
}
/deep/ {
  .el-table__body tr.current-row > td,
  .el-table--enable-row-hover .el-table__body tr:hover > td {
    .operation-div-style {
      display: block;
    }
  }
}
.operation-div-style {
  display: none;
}
/deep/ {
  .el-table__body-wrapper::-webkit-scrollbar {
    display: none;
  }
}
/deep/ .el-input__suffix {
  color: #909399;
}
</style>
