<template>
  <div class="grafanaDatePicker" :class="{ 'is-disabled': disabled }">
    <el-input
      class="timepicker-nav-btn"
      :class="{ active: isShow }"
      :suffix-icon="iconClass"
      :size="size"
      disabled
      v-model="choseValue.label"
      v-on:click.native="timepickerSwitch"
    >
    </el-input>
    <div class="timepicker-dropdown">
      <el-collapse-transition>
        <div v-show="isShow" class="timepicker-panel">
          <div class="timepicker-main">
            <div class="title">自定义范围</div>
            <div class="startTime">
              <span class="demonstration">开始时间：</span>
              <el-date-picker
                popper-class="defaultTimeSelectpicker"
                v-model="startTime"
                type="datetime"
                :picker-options="selefPickerOptions_start"
                :size="size"
                prefix-icon="el-icon-date"
                :value-format="valueFormat"
                :format="format"
                :clearable="false"
                :editable="editable"
                :placeholder="startPlaceholder"
                @change="userDefine"
              >
              </el-date-picker>
            </div>
            <div class="endTime">
              <span class="demonstration">结束时间：</span>
              <el-date-picker
                popper-class="defaultTimeSelectpicker"
                v-model="endTime"
                type="datetime"
                :picker-options="selefPickerOptions_end"
                prefix-icon="el-icon-date"
                :size="size"
                :clearable="false"
                :value-format="valueFormat"
                :format="format"
                :editable="editable"
                :placeholder="endPlaceholder"
                @change="userDefine"
              >
              </el-date-picker>
            </div>
            <div v-if="hasRefresh" class="refreshTime">
              <el-button :size="size" class="refreshTimerWrap" type="primary" @click="setPicker"
                >确定</el-button
              >
              <el-checkbox
                :disabled="defaultQuick == 'false'"
                @change="changeRefreshType"
                v-model="refreshTimer"
                false-label="off"
                true-label="60"
                >每分钟自动刷新</el-checkbox
              >
              <!--<span class="demonstration">刷新间隔：</span>
              <div class="refreshpanel">
                <el-select v-if="hasRefresh" class="refreshTimerWrap" popper-class="refreshTimerSelect" v-model="refreshTimer" :size="size" placeholder="请选择">
                  <el-option
                    v-for="(item, index) in refreshTimerArray"
                    :key="index"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
                <el-button :size="size" type="primary" @click="setPicker">确定</el-button>
              </div>-->
            </div>
            <div v-else class="refreshTime" style="margin-top: 15px">
              <el-button :size="size" type="primary" @click="setPicker">确定</el-button>
            </div>
          </div>
          <div class="timepicker-sidebar">
            <div class="title">快捷选择</div>
            <el-radio-group v-model="shortcutValue" @change="pickerChange">
              <el-radio-button
                v-for="(item, index) in pickerOptions"
                :key="index"
                :label="item.value"
                >{{ item.label }}</el-radio-button
              >
            </el-radio-group>
          </div>
        </div>
      </el-collapse-transition>
    </div>
  </div>
</template>

<script>
export default {
  name: 'grafanaDatePicker',
  data() {
    return {
      iconClass: 'el-icon-caret-bottom',
      choseValue: {
        label: '',
        value: ''
      }, // 选中的时间
      minOfMs: 60000, // 一分钟毫秒数
      isShow: false, // 下拉是否显示
      startTime: '',
      endTime: '',
      shortcutValue: '', // 快捷选择选中的项
      refreshTimer: '', // 刷新时间段
      userDefined: false, // 自定义时间
      selefPickerOptions_start: this.beginDate(),
      selefPickerOptions_end: this.processDate(),
      defaultQuick: 'false', // 是否为快捷选择
      hasTimer: false,
      interval: null // 定时器
    }
  },
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    value: {},
    // 旧时间
    lastDate: {},
    // 开始时间选择器占位符
    startPlaceholder: {
      type: String,
      default: '选择日期时间'
    },
    // 结束时间选择器占位符
    endPlaceholder: {
      type: String,
      default: '选择日期时间'
    },
    // 输入框是否可输入
    editable: {
      type: Boolean,
      default: false
    },
    // 输入框显示时间格式
    format: {
      type: String,
      default: 'yyyy-MM-dd HH:mm:ss'
    },
    // 输入框尺寸
    size: {
      type: String,
      default: 'small'
    },
    // 返回时间格式
    valueFormat: {
      type: String,
      // default: 'yyyy-MM-dd HH:mm:ss'
      default: 'timestamp'
    },
    // 默认选中值
    defaultValue: {
      type: [String, Number]
    },
    // 快捷选择数组 [{label: '过去5分钟前', value: '5'}]
    pickerOptions: {
      type: Array,
      default: () => [
        { label: '最近半小时', value: '30' },
        { label: '最近1小时', value: '60' },
        { label: '最近一天', value: '1440' },
        { label: '最近一周', value: '10080' }
      ]
    },
    // 是否显示刷新组件
    hasRefresh: {
      type: [Boolean, String],
      default: true
    },
    // 刷新时间数据列表
    refreshTimerArray: {
      type: Array,
      default: () => [
        { label: 'off', value: 'off' },
        { label: '10s', value: '10' },
        { label: '30s', value: '30' },
        { label: '60s', value: '60' },
        { label: '90s', value: '90' }
      ]
    },
    // 默认刷新时间
    defaultRefreshTimer: {
      type: String,
      default: 'off'
    },
    // 是否为快捷选择
    quick: {
      type: String,
      default: 'true'
    },
    timer: {
      type: String,
      default: 'off'
    }
  },
  watch: {
    // value: {
    //   handler (val, oldval) {
    //     console.log('111111', val)
    //     // this.hasValue = true
    //   },
    //   deep: true
    // },
    lastDate: {
      handler(val, oldval) {
        this.assign()
      },
      deep: true
    },
    defaultValue: val => {
      // console.log(val)
    }
  },
  mounted() {
    this.defaultQuick = this.quick
    // console.log('timer', this.timer)
    this.refreshTimer = this.timer
    // console.log('this.refreshTimer=', this.refreshTimer)
    // console.log('this.lastDate =', this.lastDate)
    if (!this.lastDate.dateRange.length) {
      this.init()
    } else {
      this.assign()
    }
    // this.refreshTimer
  },
  methods: {
    init() {
      // console.log('init')
      this.refreshTimer = this.refreshTimer || this.defaultRefreshTimer
      this.shortcutValue = this.defaultValue + '' // 转为字符串 以便radiogroup 反选
      // this.getPickerTime()
      this.getPickerLabel(this.defaultValue)
      this.setParam()
    },
    // 开始时间边界选项
    beginDate() {
      let self = this
      return {
        disabledDate(time) {
          let sevenTimes = 8 * 24 * 3600 * 1000
          let seven = self.endTime - sevenTimes
          if (self.endTime != '') {
            return (
              time.getTime() > Date.now() || time.getTime() > self.endTime || time.getTime() < seven
            )
          } else {
            return time.getTime() > Date.now()
          }
        }
      }
    },
    // 结束时间边界选项
    processDate() {
      let self = this
      return {
        disabledDate(time) {
          let sevenTimes = 7 * 24 * 3600 * 1000
          let seven = self.startTime + sevenTimes
          let diff = time - self.startTime
          let dayMs = 86400000
          if (diff < dayMs) {
            // 如果时间差小于一天 给计算用的开始时间减去一天 用于显示结束时间选中当天
            return time.getTime() < self.startTime - dayMs || time.getTime() > Date.now()
          } else {
            return (
              time.getTime() < self.startTime ||
              time.getTime() > Date.now() ||
              time.getTime() > seven
            )
          }
        }
      }
    },
    // 赋值方法
    assign() {
      // console.log('v-moddle', this.lastDate)
      // console.log('this.quick', this.quick)
      // console.log('this.lastDate=', this.lastDate)
      // console.log('this.quick=', this.quick)
      this.startTime = this.lastDate.dateRange[0]
      this.endTime = this.lastDate.dateRange[1]
      // this.quick = this.lastDate.quick
      // 如果是快捷选择添加
      if (this.quick == 'true') {
        this.shortcutValue = (this.endTime - this.startTime) / this.minOfMs + '' // 转为字符串 以便radiogroup 反选
      } else {
        this.shortcutValue = ''
      }
      this.getPickerLabel()
      // if (this.quick == 'true') {
      //   this.getPickerTime()
      //   this.setParam()
      // } else {
      //   this.setParam()
      // }
      this.setParam()
    },
    // 设置显示或隐藏
    timepickerSwitch() {
      if (this.disabled) {
        return false
      }
      this.isShow = !this.isShow
      if (!this.isShow) {
        this.iconClass = 'el-icon-caret-bottom'
      } else {
        this.iconClass = 'el-icon-caret-top'
      }
    },
    // 快捷选择有变化时
    pickerChange(value) {
      this.timepickerSwitch()

      // this.lastDate.quick = true
      // console.log('quick=', this.quick)
      this.userDefined = false
      this.defaultQuick = 'true'
      this.getPickerLabel()
      this.getPickerTime()
      // this.setPicker()
    },
    // 根据选择的值获取lable
    getPickerLabel() {
      // let hasShortcut = false // 是否选中快捷列表中
      // console.log('this.quick=', this.quick)
      // console.log('this.quick == true=', this.quick == 'true')
      // console.log('this.shortcutValue=', this.shortcutValue)
      if (this.quick == 'true' || this.defaultQuick == 'true') {
        this.pickerOptions.map(item => {
          if (item.value == this.shortcutValue) {
            this.choseValue.label = item.label
            this.choseValue.value = item.value
          }
        })
      } else if (this.quick != 'true') {
        // console.log('else       getPickerLabel () {\n')
        this.userDefine()
        this.userDefinedSetLabel()
      }
    },
    // 获取快捷选择的时间段
    getPickerTime() {
      let dateRange = this.handleTime(this.shortcutValue)
      let param = {
        dateRange: dateRange,
        timer: this.refreshTimer,
        type: this.shortcutValue,
        quick: 'true',
        step: this.getStep(this.startTime, this.endTime)
      }
      // console.log('param=', param)
      this.emitEventChange(param)
    },
    // 获取时间 不触发
    getPickerTimeNoemit() {
      let dateRange = this.handleTime(this.shortcutValue)
      let param = {
        dateRange: dateRange,
        timer: this.refreshTimer,
        type: this.shortcutValue,
        step: this.getStep(this.startTime, this.endTime)
      }
      return param
    },
    // 自定义时间
    userDefine() {
      // this.quick = 'false'
      this.refreshTimer = '' // 自定义时间不可刷新
      this.shortcutValue = '' // 自定义时间 快捷选中时间为空
      this.defaultQuick = 'false' // 快捷选择状态为false
      this.userDefined = true // 自定义选择状态为 true
    },
    // 设置timepicker-nav-btn 展示内容
    setPicker() {
      // 如果是自定义时间段 设置timepicker-nav-btn 为具体时间段
      if (this.userDefined) {
        this.userDefinedSetLabel()
      }
      this.timepickerSwitch()
      this.setParam()
    },
    // 获取时间跨度（MONTH,DAY,HOUR）
    getStep(start, end) {
      let startTime
      let endTime
      if (this.valueFormat != 'timestamp') {
        startTime = start.getTime()
        endTime = end.getTime()
      } else {
        startTime = start
        endTime = end
      }
      let stepTime = endTime - startTime

      let step = ''
      if (stepTime <= 12 * 3600000) {
        step = 'MINUTE'
      } else if (12 * 3600000 < stepTime && stepTime <= 24 * 3600000) {
        step = 'HOUR'
      } else if (24 * 3600000 < stepTime && stepTime <= 24 * 30 * 3600000) {
        step = 'DAY'
      } else {
        step = 'MONTH'
      }
      return step
    },
    // 重构时间跨度 （）
    getNewStep(start, end) {
      let startTime
      let endTime
      if (this.valueFormat != 'timestamp') {
        startTime = start.getTime()
        endTime = end.getTime()
      } else {
        startTime = start
        endTime = end
      }
      let step = ''
      let hourOfMs = 3600000
      let stepTime = endTime - startTime
      if (stepTime <= 1 * hourOfMs) {
        step = 'anHouer'
      } else if (1 * hourOfMs < stepTime && stepTime <= 3 * hourOfMs) {
        step = 'threeHouer'
      } else if (3 * hourOfMs < stepTime && stepTime < 6 * hourOfMs) {
        step = 'sixHouer'
      } else if (6 * hourOfMs < stepTime && stepTime < 12 * hourOfMs) {
        step = 'twelveHouer'
      } else if (12 * hourOfMs < stepTime && stepTime < 24 * hourOfMs) {
        step = 'oneday'
      } else if (24 * hourOfMs < stepTime && stepTime < 24 * 3 * hourOfMs) {
        step = 'threeDay'
      } else {
        step = 'other'
      }
      return step
    },
    // 把** 之前转换为时间范围
    handleTime(num) {
      // console.log('num=', num)
      num = parseFloat(num)
      let start, end
      let nowStamp = new Date().getTime()
      let pastStamp = nowStamp - num * this.minOfMs
      if (this.valueFormat === 'timestamp') {
        end = nowStamp
        start = pastStamp
      } else {
        end = this.formatTime(this.valueFormat, nowStamp)
        start = this.formatTime(this.valueFormat, pastStamp)
      }
      // 如果用户自定义时间段后 不触发时间更新
      if (!this.userDefined) {
        this.startTime = start
        this.endTime = end
      }
      // console.log([start, end])
      return [start, end]
    },
    // 格式化时间戳
    formatTime(fmt, time) {
      // console.log('new Date(time)==', new Date())
      time = time ? new Date(Number(time)) : new Date()
      // console.log('time==', time)
      var o = {
        'M+': time.getMonth() + 1, // 月份
        'd+': time.getDate(), // 日
        'H+': time.getHours(), // 小时
        'm+': time.getMinutes(), // 分
        's+': time.getSeconds(), // 秒
        'q+': Math.floor((time.getMonth() + 3) / 3), // 季度
        S: time.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (time.getFullYear() + '').substr(4 - RegExp.$1.length))
      }
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) {
          fmt = fmt.replace(
            RegExp.$1,
            RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
          )
        }
      }
      return fmt
    },
    userDefinedSetLabel() {
      // console.log('userDefinedSetLabel')
      this.choseValue.label =
        this.formatTime(this.format, this.startTime) +
        ' ~ ' +
        this.formatTime(this.format, this.endTime)
      this.choseValue.value = [this.startTime, this.endTime]
      // console.log('this.choseValue.value=', this.choseValue.value)
      this.shortcutValue = ''
    },
    // 自定义时间 设置返回的数据格式
    setParam() {
      // let dateRange = this.handleTime()
      let dateRange
      // if (this.quick) {
      //   this.userDefined = !this.quick
      // }
      if (this.userDefined) {
        dateRange = this.choseValue.value
      } else {
        dateRange = this.handleTime(this.shortcutValue)
      }
      let param = {
        dateRange: dateRange,
        timer: this.refreshTimer,
        quick: this.defaultQuick,
        type: this.shortcutValue,
        step: this.getStep(this.startTime, this.endTime)
        // step: this.getNewStep(this.startTime, this.endTime)
      }
      // console.log('setParam=', param)
      // console.log('this.refreshTimer=', this.refreshTimer)
      this.emitEventChange(param)
      if (this.refreshTimer && this.refreshTimer != 'off') {
        this.seIinterval(param)
      }
    },
    setIintervalParam(param) {
      let dateRange = this.handleTime(this.shortcutValue)
      let IntervalParam = {
        dateRange: dateRange,
        timer: this.refreshTimer,
        quick: param.quick,
        type: param.type,
        step: param.step
        // step: this.getNewStep(this.startTime, this.endTime)
      }
      // console.log('setIintervalParam param =', param)
      // console.log('IntervalParam =', IntervalParam)
      this.emitEventChange(IntervalParam)
    },
    seIinterval(param) {
      clearInterval(this.interval)
      this.setIintervalParam(param)
      this.interval = setTimeout(() => {
        // console.log('interval param=', param)
        this.seIinterval(param)
      }, this.refreshTimer * 1000)
    },
    changeRefreshType(val) {
      // console.log(val)
      if (val == 'off') {
        clearInterval(this.interval)
      }
      this.setPicker()
    },
    // 触发change
    emitEventChange(param) {
      this.$emit('change', param)
    },
    emitEventInput(param) {
      this.$emit('change', param)
      this.$emit('input', param)
    }
  },
  destroyed() {
    clearInterval(this.interval)
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/common.scss';
$bgcolor: #0c344a;
$inputbgcolor: #011e34;
$pickerbgcolor: #0b3044;
$pickerbordercolor: #10425c;
$focusColor: $primary-color;
$btnfocusColor: #008997;
$inputColorlight: #019193;
$inputColor: #006f7b;
$colorTextPrimary: #7d97a3; // 标题
/*$colorTextRegular:  #7D97A3; //主要内容*/
$colorTextSecondary: rgba(94, 102, 104, 0.64);
/*$colorTextPlaceholder: #c0c4cc; //占位符、info
  $colorTextSubPrimary: #89a0bf;
  $colorTextSubRegular: #787a80;*/
.grafanaDatePicker {
  position: relative;

  .timepicker-nav-btn {
    /deep/ {
      i {
        float: right;
      }
      span {
        margin: 0;
      }
      .el-input__inner {
        cursor: pointer;
        background: #f2f4f9;
        border: 1px solid #f2f4f9;
        color: $base-font-color;
      }
      .el-input__icon {
        font-size: 14px;
        color: $base-font-color;
        cursor: pointer;
      }
    }
    &:hover,
    &:focus {
      /deep/.el-input__inner {
        background-color: $primary-plain;
        border-color: $primary-plain !important;
        color: $primary-color;
      }
      /deep/ .el-input__icon {
        color: $primary-color;
      }
    }
  }
  .timepicker-nav-btn.active {
    /deep/ {
      .el-input__inner {
        background: $white-bg;
        border: 1px solid rgba(27, 216, 247, 0.5);
        //color: $inputColorlight;
      }
      .el-input__icon {
        //color: $focusColor;
      }
    }
  }
  .timepicker-dropdown {
    position: absolute;
    right: 0;
    background: #fff;
    margin-top: 10px;
    box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.1);
    z-index: 2;
  }
  .timepicker-panel {
    padding: 20px;
    display: flex;
  }
  .startTime,
  .endTime {
    /deep/ .el-input__inner,
    .el-input {
      width: 278px;
    }
  }
  .timepicker-main {
    /deep/ {
      .el-input__inner {
        // color: $colorTextPrimary;
        //background:$pickerbgcolor;
        //border: 1px solid $pickerbordercolor;
        padding-left: 10px;
      }
      .el-input__prefix {
        left: calc(100% - 30px);
        //color: #979797;
        //color: $colorTextPrimary;
      }
      .el-button {
        // background: $btnfocusColor;
        //border-color: $btnfocusColor;
      }
    }
    .endTime {
      margin: 10px 0 10px 0;
    }
  }
  .timepicker-sidebar {
    min-width: 100px;
    margin-left: 50px;
  }
  .el-radio-button {
    /deep/ {
      .el-radio-button__inner {
        background: transparent;
        border: 0;
        box-shadow: none;
        color: $colorTextSecondary;
        padding: 8px 0;
      }
    }
  }
  .el-radio-button.is-active {
    /deep/ {
      .el-radio-button__inner {
        color: $focusColor;
      }
    }
  }
  .title {
    font-size: 14px;
    color: $base-font-color;
    font-weight: 700;
    margin-bottom: 10px;
    text-align: left;
  }
  .demonstration {
    font-size: 12px;
    min-height: 16px;
    color: $colorTextSecondary;
  }
  .refreshTime {
    .refreshpanel {
      display: flex;
    }
    .refreshTimerWrap {
      flex-grow: 1;
      margin-right: 15px;
    }
    .el-button {
      /*margin-left: 15px;*/
    }
    /deep/ {
      .el-select__caret {
        color: $colorTextPrimary;
      }
      .el-icon-arrow-up {
        &:before {
          /*content: "\E78F";*/
          content: '\E60C';
        }
      }
    }
  }
  /deep/ {
    .el-button {
      border-radius: 2px;
    }
    .el-input__inner {
      border-radius: 2px;
    }
  }
}
.is-disabled {
  .timepicker-nav-btn {
    /deep/.el-input__inner {
      background-color: #f5f7fa;
      border-color: #e4e7ed;
      color: #c0c4cc;
      cursor: not-allowed;
    }
    /deep/ .el-input__icon {
      color: #c0c4cc;
    }
    &:hover,
    &:focus {
      /deep/.el-input__inner {
        background-color: #f5f7fa;
        border-color: #e4e7ed !important;
        color: #c0c4cc;
        cursor: not-allowed;
      }
      /deep/ .el-input__icon {
        color: #c0c4cc;
      }
    }
  }
}
</style>
<style lang="scss">
.defaultTimeSelectpicker {
  z-index: 999999 !important;
}
</style>
<style lang="scss">
@import '~@/styles/common.scss';
.defaultTimeSelectpicker {
  // background:$bgcolor;
  /*border-color:$pickerbordercolor;*/
  width: 278px;
  box-shadow: none;
  .popper__arrow {
    display: none;
  }
  .el-picker-panel__content {
    width: 250px;
  }
  .el-date-table td {
    /*color: #779da8;*/
    width: 25px;
  }
  td .cell {
    /*color: #779da8;*/
  }
  td .cell:hover {
    /*<!--color: $focusColor ;-->*/
  }
  .el-date-table th {
    padding: 5px 0;
    /*<!--border-color:$pickerbgcolor;-->
      <!--color: #57737B;-->*/
  }
  .el-time-spinner__item {
    /*color: #779da8;*/
  }
  td.disabled div,
  td.disabled .cell {
    /*background-color: #0f3c52;*/
    /*color: rgba(138, 168, 177, 0.14);*/
    &:hover {
      /*color: rgba(138, 168, 177, 0.14);*/
    }
  }
  .el-date-table td.next-month span,
  td.prev-month {
    /*color: rgba(119, 157, 168, 0.3);*/
  }
  .el-date-table td.current:not(.disabled) span {
    background: $primary-color;
    /*color: #fff;*/
  }
  .el-date-table td.available:hover,
  .el-date-table td.today span,
  td.current.today .cell {
    /*<!--color: $focusColor;-->*/
  }

  .el-date-picker__header-label {
    color: #fff;
  }
  .el-picker-panel__icon-btn {
    /*color: #81bac4;*/
  }
  .el-picker-panel__footer,
  .el-date-picker__time-header {
    /*background:$bgcolor;
      border-color: $pickerbgcolor;*/
  }
  .el-input__inner {
    /*color: $colorTextPrimary;
      background:$pickerbgcolor;
      border: 1px solid $pickerbordercolor;
      border-radius: 2px;*/
  }
  .el-picker-panel__footer {
    /*border-color: $pickerbgcolor;
      background:$bgcolor;*/
    > :nth-child(1) {
      /*color: $btnfocusColor;*/
      color: $primary-color;
    }
    > :nth-child(2) {
      background: $primary-color;
      color: #fff;
      border-color: $primary-color;
      border-radius: 2px;
    }
    .is-disabled {
      /* color: #295467;
         background: #0f3c52;*/
      &:hover {
        /*color: #295467;*/
        /*background: #0f3c52;*/
      }
    }
  }
  .el-time-panel {
    /*background:$bgcolor;
      border-color:$bgcolor;*/
  }
  .el-time-panel__footer {
    /*<!--border-color:$pickerbgcolor;-->*/
    .el-time-panel__btn {
      /*color: $colorTextPrimary;*/
    }
    .el-time-panel__btn.confirm {
      /*color: $focusColor;*/
    }
  }
  .el-time-panel__content::after,
  .el-time-panel__content::before {
    /*border-color:$pickerbgcolor;*/
  }
  .el-time-spinner__item.active:not(.disabled) {
    /*color: $focusColor;*/
  }
  .el-time-spinner__item:hover:not(.disabled):not(.active) {
    background: transparent;
  }
  .el-picker-panel__content {
    margin: 5px 15px 10px;
  }
  .el-date-picker__header {
    margin: 10px 10px 0;
  }
}
/*.refreshTimerSelect{
    background:$bgcolor;
    border-color:$pickerbordercolor;
    color: $colorTextSecondary;
    box-shadow:none;
    .popper__arrow{
      display: none;
    }
    .el-select-dropdown__wrap {
      margin-bottom: -10px !important;
    }
    .el-select-dropdown__item.hover, .el-select-dropdown__item:hover {
      background: $inputColor;
      color: #fff;
    }
    .el-select-dropdown__item {
      color: $colorTextSecondary;
    }
    .el-select .el-input .el-select__caret.is-reverse{
      color: $colorTextPrimary;
    }
    .el-select{
    }
  }*/
</style>
