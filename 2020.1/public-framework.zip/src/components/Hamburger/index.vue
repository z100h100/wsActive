<template>
  <div>
    <div @click="toggleClick" class="hamburger" :class="{ 'is-active': isActive }">
      <i class="iconfont  icon-menu-zk"></i>
    </div>
  </div>
</template>

<script>
export default {
  name: 'hamburger',
  props: {
    isActive: {
      type: Boolean,
      default: false
    },
    toggleClick: {
      type: Function,
      default: null
    }
  }
}
</script>

<style scoped rel="stylesheet/scss" lang="scss">
.hamburger {
  /*display: inline-block;*/
  cursor: pointer;
  /*width: 22px;*/
  /*height: 22px;*/
  width: 100%;
  height: 100%;
  display: flex;
  justify-items: center;
  align-items: center;
  /*margin-top: 4px;*/
  /*margin-right: 15px;*/
  /*background: url('../../assets/images/menu-ss.png') no-repeat center top;*/
  transition: 0.38s;
  transform-origin: 50% 50%;
  i {
    font-size: 15px;
    color: #b1b5c1;
  }
}
.hamburger.is-active {
  transform: rotate(90deg);
}
</style>
