<template>
  <div>
    <div class="advancedSearch clearfix">
      <el-form :inline="true" :model="ordinarySearch" size="small">
        <!-- ordinary-area start -->
        <el-form-item :class="{ short: isShort }">
          <el-input
            :placeholder="typePlaceholder"
            v-model="ordinarySearch.searchinput"
            class="input-with-select"
            @focus="inputFocus"
            @blur="inputBlur"
          >
            <el-select
              ref="select"
              v-model="ordinarySearch.searchType"
              slot="prepend"
              icon-class="caret-bottom"
              suffix-icon="el-icon-caret-bottom"
              @change="searchTypeChange"
              placeholder="请选择"
            >
              <el-option
                v-for="(v, i) in searchTypeOptions"
                :label="v.label"
                :value="v.value"
                :key="i"
              ></el-option>
            </el-select>
            <el-button
              @click="handleSearchClick"
              slot="append"
              icon="iconfont icon-ic-search"
            ></el-button>
          </el-input>
        </el-form-item>
        <el-form-item class="tag">
          <el-dropdown>
            <el-button type="info">
              {{ $t('demo.tag') }}<i class="el-icon-caret-bottom el-icon--right"></i
            ></el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>{{ $t('demo.tag') }}1</el-dropdown-item>
              <el-dropdown-item>{{ $t('demo.tag') }}2</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </el-form-item>
        <!-- ordinary-area end -->
        <slot name="ordinaryForm-area"></slot>
        <el-form-item>
          <span @click="switchAdvanced" class="switchAdvanced">
            <a v-if="!advancedIsShow" :class="{ 'top-grade': !advancedIsShow }">{{
              $t('demo.advancedSearch')
            }}</a>
            <a v-if="advancedIsShow" :class="{ common: advancedIsShow }">{{
              $t('demo.commonSearch')
            }}</a>
          </span>
        </el-form-item>
        <el-form-item class="operation">
          <slot name="ordinaryOper-area"></slot>
        </el-form-item>
      </el-form>
      <!-- serach-tag start -->
      <div class="searchTags" v-show="this.searchTags.length">
        <div class="tltle"><i class="iconfont icon-filter"> </i>检索项：</div>
        <el-tag
          v-for="(v, i) in searchTags"
          type="info"
          closable
          :key="i"
          :disable-transitions="true"
          @close="closeTags(i)"
        >
          {{ v.label + '：' + v.content }}
        </el-tag>
        <a class="clearTags" @click="clearSearchTags"> 清除 </a>
      </div>
      <!-- serach-tag end -->
    </div>

    <el-collapse-transition>
      <div v-show="advancedIsShow">
        <SearchPanel :searchCriteria="advancedSearch">
          <template slot="form-area">
            <slot name="form-area"></slot>
          </template>
          <template slot="oper-area">
            <slot name="oper-area"></slot>
          </template>
        </SearchPanel>
      </div>
    </el-collapse-transition>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { SearchPanel } from './'

export default {
  components: {
    SearchPanel
  },
  name: 'AdvancedSearch',
  props: {
    // 普通搜索
    // ordinarySearch: {},
    // 高级搜索
    advancedSearch: {},
    // 获取列表方法
    getList: {
      type: Function
    },
    // 高级搜索下拉选项
    searchTypeOptions: {
      // 1. label: 展示文本
      // 2. value: 值
      // 3. type: input(默认) / select
      // 4. options: select 时可供选择项
      // 5. placeholder：
      type: Array
    },
    // 删除
    delSearchTags: {}
  },
  data() {
    return {
      isShort: false,
      advancedIsShow: false,
      // 普通搜索
      typePlaceholder: '',
      searchTags: [],
      ordinarySearch: {
        searchType: 'id',
        searchinput: ''
      }
    }
  },
  computed: {
    ...mapState({
      // searchTags: state => {
      //   return state.demo.searchTags
      // }
    })
  },
  mounted() {
    this.computedWidth()
    window.addEventListener('resize', this.computedWidth)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.computedWidth)
  },
  methods: {
    computedWidth() {
      if (this.$el.clientWidth < 1300) {
        this.isShort = true
      } else {
        this.isShort = false
      }
    },
    inputFocus() {
      let el = this.$el.getElementsByClassName('input-with-select')[0]
      el.style.borderColor = '#11B2FF'
      el.style.boxShadow = '0px 0px 0px 2px rgba(17, 178, 255, 0.2)'
    },
    inputBlur() {
      let el = this.$el.getElementsByClassName('input-with-select')[0]
      el.style.borderColor = '#DCDFE6'
      el.style.boxShadow = 'none'
    },
    switchAdvanced() {
      this.advancedIsShow = !this.advancedIsShow
    },
    updateSearchTags(tags) {
      const { searchTags } = this
      tags.forEach(tag => {
        const tagIndex = searchTags.findIndex(item => item.value === tag.value)
        if (tagIndex === -1 && tag.content) {
          this.searchTags.push(tag)
        } else {
          if (tag.content) {
            this.searchTags[tagIndex].content = tag.content
          } else {
            tagIndex !== -1 && this.searchTags.splice(tagIndex, 1)
          }
        }
      })
    },
    clearSearchTags() {
      const { searchTags } = this
      this.delSearchTags(searchTags)
      this.searchTags = []
    },
    closeTags(index) {
      const { searchTags } = this
      this.delSearchTags([searchTags[index]])
      this.searchTags.splice(index, 1)
    },
    handleSearchClick() {
      const { ordinarySearch } = this
      this.getList(ordinarySearch)
      console.log(this.$el.clientWidth)
      console.log(this.$el.offsetWidth)
    },
    // 高级搜索下拉选项 change
    searchTypeChange(val) {
      const { searchTypeOptions } = this
      const option = searchTypeOptions.find(item => {
        return item.value === val
      })
      this.typePlaceholder = option ? option.placeholder : '请选择属性项进行搜索'
      this.ordinarySearch.searchinput = ''
    }
  }
}
</script>

<style scoped lang="scss">
/deep/ .search-panel .form-panel {
  padding: 5px 20px 5px 20px;
  margin-bottom: 0;
}
</style>
