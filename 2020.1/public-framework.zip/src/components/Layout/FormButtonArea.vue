<template>
  <div :class="{ 'oper-area-wrap': true, 'oper-area-wrap-collapse': isCollapse }">
    <div class="oper-area">
      <slot></slot>
    </div>
  </div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  name: 'FormButtonArea',
  computed: {
    ...mapGetters(['sidebar']),
    isCollapse() {
      return !this.sidebar.opened
    }
  }
}
</script>
<style lang="scss" scoped>
.oper-area-wrap {
  position: fixed;
  bottom: 0;
  right: 10px;
  z-index: 0;
  width: calc(100% - 260px);
  background-color: #eceef3;
}
.oper-area {
  display: flex;
  justify-content: flex-end;
  background-color: #fff;
  padding: 12px;
  border-top: solid 1px #edeff4;
  z-index: 10;
  margin-bottom: 10px;
}
.oper-area-wrap-collapse {
  width: calc(100% - 80px);
}
</style>
