<template>
  <el-row :span="24" class="mainContainer">
    <header class="mainContainer__header" v-if="showHead">
      <slot name="header"></slot>
    </header>
    <main class="mainContainer__body">
      <slot name="main"></slot>
    </main>
    <footer class="mainContainer__paging" v-if="showPagination">
      <slot name="pagination"></slot>
    </footer>
  </el-row>
</template>

<script>
export default {
  name: 'ListPanel',
  props: {
    showPagination: {
      type: Boolean,
      default: () => {
        return true
      }
    },
    showHead: {
      type: Boolean,
      default: () => {
        return false
      }
    }
  }
}
</script>

<!--<style scoped lang="scss">-->
<style scoped lang="scss">
@import '~@/styles/common';
.mainContainer {
  background: #fff;
  @include e(header) {
    display: flex;
    flex-flow: row nowrap;
    justify-content: space-between;
    padding: 10px 22px;
    align-items: center;
    // border-bottom: 1px solid $border-color;
    height: 53px;
  }

  /deep/ .header__title {
    font-size: $header-font-size;
    color: $header-font-color;
    letter-spacing: 0;
    text-align: left;
    font-weight: 700;
  }
  /deep/ .header__button {
    // 覆盖按钮样式
    height: 32px;
    line-height: 32px;
    padding: 0 15px;
    span {
      font-family: PingFangSC-Medium;
      font-size: 13px;
      color: #494f5c;
      letter-spacing: 0;
      margin-left: 5px;
    }
  }

  @include e(body) {
    padding: 0 20px;
    /*.list {
      padding: 0 30px;
      &.el-table::before {
        height: 0 !important;
      }
      &.el-table th {
        background: red !important;
      }
    }*/
  }

  @include e(paging) {
    text-align: right;
    padding: 30px 40px 50px 0;
  }
}
</style>

<style lang="scss">
.mainContainer {
  .mainContainer__body {
    form {
      padding-bottom: 20px;
    }
    /*.list {
      &.el-table th {
        !*background: red !important;*!
        !*background: #F2F4F9 !important;*!
        background-color: #f2f4f9;
      }
      .el-input__inner {
        height: 32px;
        line-height: 32px;
        font-family: PingFangSC-Medium;
        font-size: 13px;
        color: #000000;
        letter-spacing: 0;
      }
    }*/
  }
}
</style>
