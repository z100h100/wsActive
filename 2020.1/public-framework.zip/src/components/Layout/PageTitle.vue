<template>
  <div class="page-tit" :class="{ 'no-bg': !hasBg }">
    <div class="left" v-if="showLeft == true">
      <i class="left-arrow el-icon-arrow-left" @click="goBack" />
      <span class="split-tag">|</span>
      <slot name="left-area"></slot>
    </div>
    <div class="left disabled" v-else>
      <i class="left-arrow el-icon-arrow-left" />
      <span class="split-tag">|</span>
      <slot name="left-area"></slot>
    </div>

    <div class="right">
      <slot name="right-area"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'index',
  data() {
    return {}
  },
  props: {
    hasBg: {
      type: [Boolean],
      default: true
    },
    showLeft: {
      type: [Boolean, String],
      default: true
    }
  },
  watch: {
    showLeft: val => {
      // console.log('showLeft=', val)
    },
    hasBg: val => {
      // console.log('hasBg=', val)
    }
  },
  mounted() {},
  methods: {
    goBack() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';

.page-tit {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  border-bottom: solid 1px $sub-border-color;
  height: 50px;
  background-color: #fff;
  .left.disabled {
    .left-arrow {
      cursor: not-allowed;
      color: #eeeff3 !important;
    }
  }

  .left-arrow {
    position: absolute;
    top: 16px;
    color: $base-font-color;
    font-size: 18px;
    cursor: pointer;
  }

  .split-tag {
    display: inline-block;
    margin: 0 13px 0 26px;
    font-size: 18px;
    color: #eeeff3;
  }

  .page-tit-txt {
    font-size: 18px;
    color: $main-font-color;
  }

  .right {
    display: flex;

    .el-button,
    .grafanaDatePicker,
    .el-select {
      margin-left: 10px;
    }
  }

  .page-tit-selection {
    /deep/ {
      .el-input__inner {
        border-color: #f5fcff;
        background: #f5fcff;
        color: $primary-color;
        font-size: 14px;
        font-weight: bold;

        &:focus {
          border-color: #f5fcff;
        }
      }
      .el-select__caret {
        color: $primary-color !important;
      }
      .el-icon-arrow-up {
        &:before {
          content: '\E60C';
        }
      }
    }
  }

  &.no-bg {
    background: transparent;
    padding: 0;

    .left {
      /deep/ * {
        background: transparent;
        border: 0;
      }
    }

    .right {
      /deep/ * {
        /*background: #fff;*/
        /*border-color: #fff;*/
      }

      .el-button {
        background: #fff;
        margin-right: 10px;
        border-color: #fff;
      }

      /deep/ .timepicker-nav-btn {
        /deep/ {
          .el-input__inner {
            border: 1px solid $white-bg;
          }
        }
      }
    }

    .split-tag {
      color: #cfd1d7;
    }
  }
}
</style>
