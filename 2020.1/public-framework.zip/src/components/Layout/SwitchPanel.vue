<template>
  <div class="con">
    <div class="left" :class="{ isClose: !isOpenRight, isSwitch: this.switch }">
      <transition
        @before-enter="beforeEnterMethod"
        @enter="enterMethod"
        @leave="leaveMethod"
        v-bind:css="false"
      >
        <div class="content" v-if="showLeft">
          <slot name="left-form-area"></slot>
          <slot name="left-area"></slot>
        </div>
      </transition>
      <div v-if="this.switch" class="toggle" @click="toggle"></div>
    </div>
    <div :class="{ right: true, isOpenRight: isOpenRight }" class="right-area">
      <slot name="right-area"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SwitchPanel',
  props: {
    switch: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      showLeft: true,
      isOpenRight: true
    }
  },
  methods: {
    toggle() {
      console.log('toggle')
      this.showLeft = !this.showLeft
      this.isOpenRight = !this.isOpenRight
      console.log('this.showLeft=', this.showLeft)
    },
    leaveMethod(el, done) {
      $(el).animate(
        {
          width: '0',
          opacity: 0
        },
        {
          duration: 200,
          complete: done
        }
      )
    },
    beforeEnterMethod(el) {
      $(el).css({
        width: '0',
        opacity: 0,
        transformOrigin: 'left'
      })
    },
    enterMethod(el, done) {
      $(el).animate(
        {
          width: '292px',
          opacity: 1
        },
        {
          duration: 200,
          complete: done
        }
      )
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
.con {
  display: flex;
  background-color: #fff;
  padding: 20px 0 20px 20px;
  .left {
    height: calc(100vh - 110px);
    border: 1px solid #e9ecf4;
    position: relative;
    z-index: 9;
    background-color: #fff;
    width: 300px;
    box-sizing: border-box;
    /deep/ {
      .el-table {
        padding: 0 10px;
        &:before {
          height: 0px;
        }
        th.is-leaf,
        td {
          border-bottom-style: dashed;
        }
      }
      th {
        border-top: 0;
        background: #fff;
        height: 46px;
      }
      tr {
        .tableActionStyle {
          display: none;
          font-size: 14px;
        }
        &:hover {
          .tableActionStyle {
            display: inline-block;
          }
          td {
            color: #11b2ff;
          }
        }
      }
      .current-row {
        .tableActionStyle {
          display: inline-block;
        }
      }

      .leftSearch {
        display: flex;
        justify-content: space-between;
        overflow: hidden;
        padding: 10px;
        background-color: $base-bg-color;
        width: 100%;
        .el-form-item {
          margin-bottom: 0;
          width: 100%;
        }
      }
    }
    .content {
      width: 100%;
    }
    .toggle {
      cursor: pointer;
      width: 14px;
      height: 64px;
      position: absolute;
      right: -14px;
      top: 50%;
      margin-top: -32px;
      background: url(../../assets/images/btn-left-ss-defualt.png) no-repeat;
      &:hover {
        background: url(../../assets/images/btn-left-ss-hover.png) no-repeat;
      }
    }
  }
  .isSwitch {
    border: 1px solid #e8edf1;
    /*margin: 20px 5px 20px 19px;*/
  }
  .isClose.isSwitch {
    border: 0;
    margin: 0;
    width: 0px;
    .toggle {
      background: url(../../assets/images/btn-left-zk-defualt.png) no-repeat;
      &:hover {
        background: url(../../assets/images/btn-left-zk-hover.png) no-repeat;
      }
    }
  }
  .right {
    flex-grow: 1;
  }
  .isOpenRight {
    width: calc(100% - 267px);
  }
}
</style>
<style lang="scss">
.right-area {
  overflow: auto;
  height: calc(100vh - 110px);
  .advancedSearch {
    padding: 0px 20px 0px 20px;
  }
}
</style>
