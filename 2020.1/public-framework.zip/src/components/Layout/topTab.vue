<template>
  <div class="topTitle">
    <div>
      <el-tabs v-model="activeName">
        <el-tab-pane label="工单总览" name="first"></el-tab-pane>
        <el-tab-pane label="工单类型报表" name="second"></el-tab-pane>
        <el-tab-pane label="人员报表" name="third"></el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
export default {
  name: 'AdvancedSearch',
  props: {
    ordinarySearch: {}, // 普通搜索
    advancedSearch: {} // 高级搜索
  },
  data() {
    return {
      activeName: 'first'
    }
  },
  methods: {}
}
</script>

<style scoped lang="scss">
.topTitle {
  background: #fff;
  padding: 0px;
  border-bottom: 1px #edf0f4 solid;
  div {
    padding: 0 20px;
  }
}
</style>
