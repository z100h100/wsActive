<template>
  <div class="table-popover" @mouseenter="cellHover" @mouseleave="cellLeave">
    <el-popover
      :width="this.width || cellWidth"
      @after-leave="afterLeave"
      :popper-class="popoverClass"
      ref="topTip"
      v-if="langContent"
      :placement="this.placement"
      trigger="hover"
    >
      <div>{{ content }}</div>
      <div
        :class="{ 'row-limit': line == 1, 'rows-limit': line != 1 }"
        :style="{ lineClamp: line }"
        slot="reference"
      >
        {{ content }}
      </div>
    </el-popover>
    <div
      :class="{ 'row-limit': line == 1, 'rows-limit': line != 1 }"
      :style="{ lineClamp: line }"
      v-else
    >
      {{ content || '-' }}
    </div>
  </div>
</template>

<script>
export default {
  name: 'index',
  data() {
    return {
      cellWidth: '200',
      langContent: false,
      popoverClass: ''
    }
  },
  props: {
    line: {
      type: [Number, String],
      default: 1
    },
    content: {
      type: String
    },
    width: {
      type: [Number, String]
    },
    placement: {
      type: String,
      default: 'top-start'
    }
  },
  methods: {
    // 鼠标悬浮计算容器和内容的宽来确定是否显示悬浮框
    cellHover(e) {
      let el = e.target
      let range = document.createRange()
      range.setStart(el, 0)
      range.setEnd(el, el.childNodes.length)
      let rangeWidth = range.getBoundingClientRect().width
      let rangeHeight = range.getBoundingClientRect().height
      let cellWidth = el.offsetWidth
      let cellHeight = el.offsetHeight
      this.cellWidth = cellWidth
      if (this.line == '1') {
        this.popoverClass = 'table-popover'
        if (rangeWidth > cellWidth) {
          this.langContent = true
        }
      } else {
        if (rangeHeight > cellHeight) {
          this.langContent = true
        }
      }
    },
    // 鼠标离开清空
    cellLeave() {
      // this.langContent = false
    },
    afterLeave() {
      this.langContent = false
    }
  }
}
</script>

<style lang="scss" scoped>
.table-popover {
  width: 100%;
}

.row-limit {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.rows-limit {
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
}
</style>
<style lang="scss">
.el-popover.el-popper {
  /*max-height: 300px;*/
  /*overflow-y: auto;*/
}
.table-popover {
  /deep/ .popper__arrow {
    left: 50% !important;
  }
}
</style>
