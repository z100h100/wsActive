const relativeOptions = [
  {
    text: '1分钟',
    queryTimeType: 1,
    type: 'now',
    gap: 60
  },
  {
    text: '5分钟',
    type: 'now',
    queryTimeType: 23,
    gap: 300
  },
  {
    text: '15分钟',
    type: 'now',
    queryTimeType: 2,
    gap: 900
  },
  {
    text: '1小时',
    queryTimeType: 3,
    type: 'now',
    gap: 3600
  },
  {
    text: '4小时',
    queryTimeType: 4,
    type: 'now',
    gap: 14400
  },
  {
    text: '1天',
    queryTimeType: 5,
    type: 'now',
    gap: 86400
  },
  {
    text: '今天',
    queryTimeType: 22,
    type: 'now',
    gap: 'today'
  },
  {
    text: '1周',
    queryTimeType: 6,
    type: 'now',
    gap: 604800
  },
  {
    text: '30天',
    queryTimeType: 7,
    type: 'now',
    gap: 2592e3
  },
  {
    text: '本月',
    queryTimeType: 25,
    type: 'now',
    gap: 'thismonth'
  }
]
const wholeOptions = [
  {
    text: '1分钟',
    queryTimeType: 8,
    type: 'absolute',
    gap: 60
  },
  {
    text: '15分钟',
    type: 'absolute',
    queryTimeType: 9,
    gap: 900
  },
  {
    text: '1小时',
    queryTimeType: 10,
    type: 'absolute',
    gap: 3600
  },
  {
    text: '4小时',
    queryTimeType: 11,
    type: 'absolute',
    gap: 14400
  },
  {
    text: '1天',
    queryTimeType: 12,
    type: 'absolute',
    gap: 86400
  },
  {
    text: '1周',
    queryTimeType: 13,
    type: 'absolute',
    gap: 604800
  },
  {
    text: '30天',
    queryTimeType: 14,
    type: 'absolute',
    gap: 2592e3
  },
  {
    text: '今天',
    queryTimeType: 15,
    type: 'absolute',
    gap: 'today'
  },
  {
    text: '昨天',
    queryTimeType: 16,
    type: 'absolute',
    gap: 'yesterday'
  },
  {
    text: '前天',
    queryTimeType: 17,
    type: 'absolute',
    gap: 'daybeforeyesterday'
  },
  {
    text: '本周',
    queryTimeType: 18,
    type: 'absolute',
    gap: 'week'
  },
  {
    text: '上周',
    queryTimeType: 19,
    type: 'absolute',
    gap: 'previousweek'
  },
  {
    text: '本月',
    queryTimeType: 20,
    type: 'absolute',
    gap: 'thismonth'
  },
  {
    text: '本季度',
    queryTimeType: 21,
    type: 'absolute',
    gap: 'thisquarter'
  },
  {
    text: '本年度',
    queryTimeType: 24,
    type: 'absolute',
    gap: 'thisyear'
  }
]

const isNumber = value => {
  return typeof value === 'number' && !isNaN(value)
}

function r(e) {
  var t = new Date(e)
  return {
    Y: t.getFullYear(),
    M: t.getMonth() + 1 < 10 ? '0' + String(t.getMonth() + 1) : t.getMonth() + 1,
    D: t.getDate() < 10 ? '0' + String(t.getDate()) : t.getDate(),
    h: t.getHours() < 10 ? '0' + String(t.getHours()) : t.getHours(),
    m: t.getMinutes() < 10 ? '0' + String(t.getMinutes()) : t.getMinutes(),
    s: t.getSeconds() < 10 ? '0' + String(t.getSeconds()) : t.getSeconds(),
    d: t.getDay() === 0 ? 7 : t.getDay()
  }
}
function o(e) {
  if (!/^(\d{4})-(\d{1,2})-(\d{1,2}) (\d{1,2}):(\d{1,2}):(\d{1,2})$/.test(e)) return NaN
  var t = e.split(' ')
  var n = t[0].split('-')
  var r = t[1].split(':')
  return new Date(n[0], parseInt(n[1], 10) - 1, n[2], r[0], r[1], r[2]).valueOf() / 1e3
}

const formatDate = date => {
  const e = r(date)
  return e.Y + '-' + e.M + '-' + e.D + ' ' + e.h + ':' + e.m + ':' + e.s
}

/*eslint-disable*/
const getDuration = function(e, t) {
  var n = void 0
  var a = void 0
  if (e === 'now')
    if (((a = Date.parse(new Date()) / 1e3), t === 'today'))
      n = Math.floor(new Date().setHours(0, 0, 0, 0) / 1e3)
    else if (t === 'thismonth') {
      var i = r(Date.parse(new Date()))
      n = o(i.Y + '-' + i.M + '-01 00:00:00')
    } else n = a - t
  else {
    var s = r(Date.parse(new Date()))
    var c = new Date(s.Y, s.M, 0).getDate()
    if (isNumber(t)) {
      n =
        (a =
          t < 3600
            ? o(s.Y + '-' + s.M + '-' + s.D + ' ' + s.h + ':' + s.m + ':59') - 59
            : t <= 86400
            ? o(s.Y + '-' + s.M + '-' + s.D + ' ' + s.h + ':59:59') - 3599
            : o(s.Y + '-' + s.M + '-' + s.D + ' 23:59:59') - 86399) - t
    } else {
      switch (t) {
        case 'today':
          n = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00')
          a = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00') + 86400
          break
        case 'yesterday':
          n = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00') - 8640
          a = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00')
          break
        case 'daybeforeyesterday':
          n = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00') - 172800
          a = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00') - 86400
          break
        case 'week':
          n = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00') - 86400 * (s.d - 1)
          a = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00') + 86400 * (8 - s.d)
          break
        case 'previousweek':
          n = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00') - 86400 * (s.d + 6)
          a = o(s.Y + '-' + s.M + '-' + s.D + ' 00:00:00') - 86400 * (s.d - 1)
          break
        case 'thismonth':
          n = o(s.Y + '-' + s.M + '-01 00:00:00')
          a = o(s.Y + '-' + s.M + '-' + c + ' 23:59:59')
          break
        case 'thisquarter':
          if (s.M >= 1 && s.M <= 3) {
            n = o(s.Y + '-01-01 00:00:00')
            a = o(s.Y + '-04-01 00:00:00')
          } else if (s.M >= 4 && s.M <= 6) {
            n = o(s.Y + '-04-01 00:00:00')
            a = o(s.Y + '-07-01 00:00:00')
          } else if (s.M >= 7 && s.M <= 9) {
            n = o(s.Y + '-10-01 00:00:00')
            a = o(s.Y + '-09-30 23:59:59')
          } else if (s.M >= 10 && s.M <= 12) {
            n = o(s.Y + '-10-01 00:00:00')
            a = o(s.Y + 1 + '-01-01 00:00:00')
          }
          break
        case 'thisyear':
          n = o(s.Y + '-01-01 00:00:00')
          a = o(s.Y + 1 + '-01-01 00:00:00')
      }
    }
  }
  return {
    startTime: n,
    endTime: a
  }
}

export { relativeOptions, wholeOptions, formatDate, getDuration }
