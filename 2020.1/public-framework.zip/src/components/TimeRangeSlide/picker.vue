<template>
  <div>
    <div :class="{ 'slide-panel-container': true, 'show-panel': isShow }">
      <div class="slide-panel-mask"></div>
      <div class="slide-panels">
        <div :class="{ 'slide-panel': true, active: isShow, hidden: !isShow }">
          <div class="slide-panel-content">
            <div class="panel-header">
              <h5>时间</h5>
              <a class="panel-close">
                <i class="el-icon-close" @click="handleClose" style="font-size:20px"></i>
              </a>
            </div>
            <div class="panel-body">
              <div class="panel-body-content">
                <p class="curr-val">
                  {{
                    date
                      ? date
                      : selectedValue && selectedValue.startTime
                      ? `${selectedValue.startTime}~${selectedValue.endTime}`
                      : '—'
                  }}
                </p>
                <div :class="{ 'select-sec': true, 'sec-content-expand': isNowCollapse }">
                  <div class="sec-header" @click="isNowCollapse = !isNowCollapse">
                    <span>相对</span>
                    <i
                      :class="{
                        'el-icon-caret-bottom': isNowCollapse,
                        'el-icon-caret-top': !isNowCollapse
                      }"
                    />
                  </div>
                  <div class="sec-content">
                    <ul>
                      <li
                        v-for="(option, key) in relativeOptions"
                        :key="key"
                        @click="handleSelect(option)"
                        @mouseenter="handleMouseEnter(option)"
                        :class="{
                          active:
                            selectedValue &&
                            selectedValue.type &&
                            selectedValue.type === 'now' &&
                            selectedValue.gap === option.gap
                        }"
                      >
                        {{ option.text }}
                      </li>
                    </ul>
                  </div>
                </div>
                <div :class="{ 'select-sec': true, 'sec-content-expand': isAbsoluteCollapse }">
                  <div class="sec-header" @click="isAbsoluteCollapse = !isAbsoluteCollapse">
                    <span>整点时间</span>
                    <i
                      :class="{
                        'el-icon-caret-bottom': isAbsoluteCollapse,
                        'el-icon-caret-top': !isAbsoluteCollapse
                      }"
                    />
                  </div>
                  <div class="sec-content">
                    <ul>
                      <li
                        v-for="(option, key) in wholeOptions"
                        :key="key"
                        @click="handleSelect(option)"
                        @mouseenter="handleMouseEnter(option)"
                        :class="{
                          active:
                            selectedValue &&
                            selectedValue.type &&
                            selectedValue.type === 'absolute' &&
                            selectedValue.gap === option.gap
                        }"
                      >
                        {{ option.text }}
                      </li>
                    </ul>
                  </div>
                </div>
                <div
                  :class="{ 'select-sec': true, 'sec-content-expand': isCustomCollapse }"
                  v-if="showCustom"
                >
                  <div class="sec-header" @click="isCustomCollapse = !isCustomCollapse">
                    <span>自定义</span>
                    <i
                      :class="{
                        'el-icon-caret-bottom': isCustomCollapse,
                        'el-icon-caret-top': !isCustomCollapse
                      }"
                      @click="!isCustomCollapse"
                    />
                  </div>
                  <div class="sec-content" style="padding:12px 0;">
                    <el-date-picker
                      v-model="timeRange"
                      :picker-options="selefPickerOptions"
                      type="datetimerange"
                      style="width:100%;"
                      range-separator="~"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期"
                      @change="handleCustomChange"
                    >
                    </el-date-picker>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { relativeOptions, wholeOptions, getDuration, formatDate } from './date'
export default {
  data() {
    return {
      isShow: false,
      relativeOptions,
      wholeOptions,
      date: '',
      timeRange: '',
      isNowCollapse: true,
      isAbsoluteCollapse: true,
      isCustomCollapse: true,
      selefPickerOptions: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      }
    }
  },
  props: {
    showCustom: {
      type: Boolean,
      default: () => {
        return true
      }
    },
    selectedValue: {
      type: Object
    }
  },
  methods: {
    handleMouseEnter(option) {
      const duration = getDuration(option.type, option.gap)
      this.date = `${formatDate(duration.startTime * 1000)}~${formatDate(duration.endTime * 1000)}`
    },
    handleSelect(option) {
      const duration = getDuration(option.type, option.gap)
      const startTime = formatDate(duration.startTime * 1000)
      const endTime = formatDate(duration.endTime * 1000)
      const str = `${startTime}~${endTime}`
      this.date = str
      this.$emit('update:value', {
        ...option,
        startTime,
        endTime,
        displayText: `${option.text}（${this.getDateLabel(option.type)}）`
      })
      this.timeRange = ''
      this.isShow = false
    },
    handleCustomChange(arr) {
      const startTime = formatDate(new Date(arr[0]))
      const endTime = formatDate(new Date(arr[1]))
      const str = `${formatDate(startTime)}~${formatDate(endTime)}`
      this.date = str
      this.$emit('update:value', {
        displayText: `${str}（${this.getDateLabel()}）`,
        text: str,
        queryTimeType: -1,
        type: 'custom',
        startTime,
        endTime
      })
      this.isShow = false
    },
    handleOpen() {
      this.isShow = true
    },
    handleClose() {
      this.isShow = false
      this.date = ''
    },
    getDateLabel(type) {
      if (type === 'now') {
        return '相对'
      } else if (type === 'absolute') {
        return '整点时间'
      } else {
        return '自定义'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common';
.select-sec {
  .sec-header {
    display: flex;
    overflow: hidden;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #ebecec;
    height: 40px;
    line-height: 39px;
    background: #f5f7f9;
    font-size: 14px;
    color: #373d41;
    cursor: pointer;
    position: relative;
    padding: 0 20px;
    transition: background 0.2s;
    &:hover {
      background: #edf1f6;
    }
    i {
      color: #838b9b;
      font-size: 16px;
    }
  }
  .sec-content {
    overflow: hidden;
    height: 0;
    padding: 0 12px;
    background: #fff;
    font-size: 12px;
    color: #73777a;
    transition: all 0.3s cubic-bezier(0.23, 1, 0.32, 1);
    opacity: 0;
    ul {
      margin-bottom: 1em;
      overflow: hidden;
      box-sizing: border-box;
      list-style: none;
      margin: 0;
      padding: 0;
      li {
        float: left;
        padding: 6px 15px;
        margin: 2px;
        cursor: pointer;
        color: #333;
        border-radius: 5px;
        &:hover,
        &.active {
          background-color: $primary-color;
          color: #fff;
        }
      }
    }
  }
  &.sec-content-expand .sec-content {
    display: block;
    padding: 12px;
    height: auto;
    opacity: 1;
  }
  /deep/ .el-date-editor {
    .el-range-input,
    .el-range-separator {
      font-size: 12px;
    }
  }
}
</style>
