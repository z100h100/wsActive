<template>
  <div class="grafanaDatePicker">
    <el-input
      class="timepicker-nav-btn"
      :class="{ active: isShow }"
      :suffix-icon="iconClass"
      :size="size"
      disabled
      v-model="choseValue.label"
      v-on:click.native="timepickerSwitch"
    >
    </el-input>
    <div
      class="timepicker-dropdown"
      :class="{ left: this.position == 'left', right: this.position == 'right' }"
    >
      <el-collapse-transition>
        <div v-show="isShow" class="timepicker-panel">
          <div class="timepicker-main">
            <div class="title">自定义范围</div>
            <div class="startTime">
              <!--              <span class="demonstration">开始时间：</span>-->
              <el-date-picker
                popper-class="defaultTimeSelectpicker"
                v-model="startTime"
                type="datetime"
                :picker-options="selefPickerOptions_start"
                :size="size"
                prefix-icon="el-icon-date"
                :value-format="valueFormat"
                :format="format"
                :clearable="false"
                :editable="editable"
                :placeholder="startPlaceholder"
                @change="userDefine"
              >
              </el-date-picker>
            </div>
            <div class="endTime">
              <!--              <span class="demonstration">结束时间：</span>-->
              <el-date-picker
                popper-class="defaultTimeSelectpicker"
                v-model="endTime"
                type="datetime"
                :picker-options="selefPickerOptions_end"
                prefix-icon="el-icon-date"
                :size="size"
                :clearable="false"
                :value-format="valueFormat"
                :format="format"
                :editable="editable"
                :placeholder="endPlaceholder"
                @change="userDefine"
              >
              </el-date-picker>
            </div>
            <div v-if="hasRefresh" class="refreshTime">
              <span class="demonstration">刷新间隔：</span>
              <div class="refreshpanel">
                <el-select
                  v-if="hasRefresh"
                  class="refreshTimerWrap"
                  popper-class="refreshTimerSelect"
                  v-model="refreshTimer"
                  :size="size"
                  placeholder="请选择"
                >
                  <el-option
                    v-for="(item, index) in refreshTimerArray"
                    :key="index"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
                <el-button :size="size" type="primary" @click="setPicker">确定</el-button>
              </div>
            </div>
            <div v-else class="refreshTime" style="margin-top: 15px">
              <el-button :size="size" type="primary" @click="setPicker">确定</el-button>
            </div>
          </div>
          <div class="timepicker-sidebar">
            <div class="title">快捷选择</div>
            <el-radio-group v-model="shortcutValue" @change="pickerChange">
              <el-radio-button
                v-for="(item, index) in pickerOptions"
                :key="index"
                :label="item.value"
                >{{ item.label }}</el-radio-button
              >
            </el-radio-group>
          </div>
        </div>
      </el-collapse-transition>
    </div>
  </div>
</template>

<script>
export default {
  name: 'grafanaDatePicker',
  data() {
    return {
      iconClass: 'el-icon-caret-bottom',
      choseValue: {
        label: '',
        value: ''
      }, // 选中的时间
      minOfMs: 60000, // 一分钟毫秒数
      isShow: false, // 下拉是否显示
      startTime: '',
      endTime: '',
      shortcutValue: '', // 快捷选择选中的项
      refreshTimer: '', // 刷新时间段
      userDefined: false,
      selefPickerOptions_start: this.beginDate(),
      selefPickerOptions_end: this.processDate(),
      hasValue: false,
      hasTimer: false
    }
  },
  props: {
    value: {},
    lastDate: {},
    // 开始时间选择器占位符
    startPlaceholder: {
      type: String,
      default: '请选择开始时间'
    },
    // 结束时间选择器占位符
    endPlaceholder: {
      type: String,
      default: '请选择结束时间'
    },
    // 输入框是否可输入
    editable: {
      type: Boolean,
      default: false
    },
    // 输入框显示时间格式
    format: {
      type: String,
      default: 'yyyy-MM-dd HH:mm:ss'
    },
    // 输入框尺寸
    size: {
      type: String,
      default: 'small'
    },
    // 返回时间格式
    valueFormat: {
      type: String,
      // default: 'yyyy-MM-dd HH:mm:ss'
      default: 'timestamp'
    },
    // 默认选中值
    defaultValue: {
      type: [String, Number],
      default: '120'
    },
    // 快捷选择数组 [{label: '过去5分钟前', value: '5'}]
    pickerOptions: {
      type: Array,
      default: () => []
    },
    // 是否显示刷新组件
    hasRefresh: {
      type: Boolean,
      default: true
    },
    refreshTimerArray: {
      type: Array,
      default: () => [
        { label: 'off', value: 'off' },
        { label: '10s', value: '10' },
        { label: '30s', value: '30' },
        { label: '60s', value: '60' },
        { label: '90s', value: '90' }
      ]
    },
    defaultRefreshTimer: {
      type: String,
      default: 'off'
    },
    position: {
      type: String,
      default: 'left'
    }
  },
  watch: {
    // value: {
    //   handler (val, oldval) {
    //     console.log('111111', val)
    //     // this.hasValue = true
    //   },
    //   deep: true
    // },
    lastDate: {
      handler(val, oldval) {
        this.assign(true)
      },
      deep: true
    },
    defaultValue: val => {
      console.log(val)
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.refreshTimer = this.defaultRefreshTimer
      this.shortcutValue = this.defaultValue + '' // 转为字符串 以便radiogroup 反选
      this.getPickerTime()
      this.getPickerLabel(this.defaultValue)
    },
    beginDate() {
      let self = this
      return {
        disabledDate(time) {
          if (self.endTime != '') {
            return time.getTime() > Date.now() || time.getTime() > self.endTime
          } else {
            return time.getTime() > Date.now()
          }
        }
      }
    },
    processDate() {
      let self = this
      return {
        disabledDate(time) {
          // return time.getTime() > Date.now()
          // if (self.startTime != '') {
          //   return time.getTime() < self.startTime || time.getTime() > Date.now()
          // } else {
          //   return time.getTime() > Date.now()
          // }
          let diff = time - self.startTime
          let dayMs = 86400000
          if (diff < dayMs) {
            // 如果时间差小于一天 给计算用的开始时间减去一天 用于显示结束时间选中当天
            return time.getTime() < self.startTime - dayMs || time.getTime() > Date.now()
          } else {
            return time.getTime() < self.startTime || time.getTime() > Date.now()
          }
        }
      }
    },
    assign() {
      this.shortcutValue = this.defaultValue + '' // 转为字符串 以便radiogroup 反选
      this.startTime = this.lastDate.dateRange[0]
      this.endTime = this.lastDate.dateRange[1]
      let value = (this.endTime - this.startTime) / this.minOfMs
      this.getPickerLabel(value)
      this.setParam()
    },
    // 设置显示或隐藏
    timepickerSwitch() {
      this.isShow = !this.isShow
      this.userDefined = false
      if (!this.isShow) {
        this.iconClass = 'el-icon-caret-bottom'
      } else {
        this.iconClass = 'el-icon-caret-top'
      }
    },
    // 快捷选择有变化时
    pickerChange(value) {
      this.timepickerSwitch()
      this.getPickerLabel()
      this.getPickerTime()
    },
    // 根据选择的值获取lable
    getPickerLabel(value) {
      let hasShortcut = false // 是否选中快捷列表中
      this.pickerOptions.map(item => {
        if (item.value == this.shortcutValue) {
          this.choseValue.label = item.label
          this.choseValue.value = item.value
          hasShortcut = true
        }
        // if (value && item.value == value) {
        //   this.choseValue.label = item.label
        //   this.choseValue.value = item.value
        //   this.defaultValue = value
        //   hasShortcut = true
        //   console.log('this.defaultValue=', this.defaultValue)
        // }
        // if (!value && item.value == this.shortcutValue) {
        //   this.choseValue.label = item.label
        //   this.choseValue.value = item.value
        //   hasShortcut = true
        // }
      })
      // 快捷列表中如果没有 则为自定义选择
      if (!hasShortcut) {
        this.userDefine()
        this.userDefinedSetLabel()
      }
    },
    // 获取快捷选择的时间段
    getPickerTime() {
      let dateRange = this.handleTime(this.shortcutValue)
      let param = {
        dateRange: dateRange,
        timer: this.refreshTimer,
        type: this.shortcutValue,
        step: this.getStep(this.startTime, this.endTime)
      }
      this.emitEventChange(param)
    },
    // 获取时间 不触发
    getPickerTimeNoemit() {
      let dateRange = this.handleTime(this.shortcutValue)
      let param = {
        dateRange: dateRange,
        timer: this.refreshTimer,
        type: this.shortcutValue,
        step: this.getStep(this.startTime, this.endTime)
      }
      return param
    },
    // 自定义时间
    userDefine() {
      this.userDefined = true
    },
    // 设置timepicker-nav-btn 展示内容
    setPicker() {
      // 如果是自定义时间段 设置timepicker-nav-btn 为具体时间段
      if (this.userDefined) {
        this.userDefinedSetLabel()
      }
      this.timepickerSwitch()
      this.setParam()
    },
    // 获取时间跨度（MONTH,DAY,HOUR）
    getStep(start, end) {
      let startTime
      let endTime
      if (this.valueFormat != 'timestamp') {
        startTime = start.getTime()
        endTime = end.getTime()
      } else {
        startTime = start
        endTime = end
      }
      let stepTime = endTime - startTime

      let step = ''
      if (stepTime <= 12 * 3600000) {
        step = 'MINUTE'
      } else if (12 * 3600000 < stepTime && stepTime <= 24 * 3600000) {
        step = 'HOUR'
      } else if (24 * 3600000 < stepTime && stepTime < 24 * 30 * 3600000) {
        step = 'DAY'
      } else {
        step = 'MONTH'
      }
      return step
    },
    // 把** 之前转换为时间范围
    handleTime(num) {
      // console.log('num=', num)
      num = parseFloat(num)
      let start, end
      let nowStamp = new Date().getTime()
      let pastStamp = nowStamp - num * this.minOfMs
      if (this.valueFormat === 'timestamp') {
        end = nowStamp
        start = pastStamp
      } else {
        end = this.formatTime(this.valueFormat, nowStamp)
        start = this.formatTime(this.valueFormat, pastStamp)
      }
      // 如果用户自定义时间段后 不触发时间更新
      if (!this.userDefined) {
        this.startTime = start
        this.endTime = end
      }
      // console.log([start, end])
      return [start, end]
    },
    // 格式化时间戳
    formatTime(fmt, time) {
      console.log('new Date(time)==', new Date())
      time = time ? new Date(Number(time)) : new Date()
      console.log('time==', time)
      var o = {
        'M+': time.getMonth() + 1, // 月份
        'd+': time.getDate(), // 日
        'H+': time.getHours(), // 小时
        'm+': time.getMinutes(), // 分
        's+': time.getSeconds(), // 秒
        'q+': Math.floor((time.getMonth() + 3) / 3), // 季度
        S: time.getMilliseconds() // 毫秒
      }
      if (/(y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (time.getFullYear() + '').substr(4 - RegExp.$1.length))
      }
      for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) {
          fmt = fmt.replace(
            RegExp.$1,
            RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length)
          )
        }
      }
      return fmt
    },
    userDefinedSetLabel() {
      this.choseValue.label =
        this.formatTime(this.format, this.startTime) +
        ' ~ ' +
        this.formatTime(this.format, this.endTime)
      this.choseValue.value = [this.startTime, this.endTime]
      this.shortcutValue = ''
    },
    setParam() {
      let dateRange = [this.startTime, this.endTime]
      let param = {
        dateRange: dateRange,
        timer: this.refreshTimer,
        type: this.shortcutValue,
        step: this.getStep(this.startTime, this.endTime)
      }
      this.emitEventChange(param)
    },
    // 触发change
    emitEventChange(param) {
      this.$emit('change', param)
    },
    emitEventInput(param) {
      this.$emit('change', param)
      this.$emit('input', param)
    }
  }
}
</script>

<style scoped lang="scss">
@import '~@/styles/common.scss';
$bgcolor: #0c344a;
$inputbgcolor: #011e34;
$pickerbgcolor: #0b3044;
$pickerbordercolor: #10425c;
$focusColor: $primary-color;
$btnfocusColor: #008997;
$inputColorlight: #019193;
$inputColor: #006f7b;
$colorTextPrimary: #494f5c; // 标题
/*$colorTextRegular:  #7D97A3; //主要内容*/
$colorTextSecondary: rgba(94, 102, 104, 0.64);
/*$colorTextPlaceholder: #c0c4cc; //占位符、info
  $colorTextSubPrimary: #89a0bf;
  $colorTextSubRegular: #787a80;*/
.grafanaDatePicker {
  position: relative;

  .timepicker-nav-btn {
    /deep/ {
      i {
        float: right;
      }
      /*span {*/
      /*margin: 0 5px 0 0;*/
      /*}*/
      .el-input__inner {
        cursor: pointer;
        background: #f2f4f9;
        border: 1px solid #f2f4f9;
        color: $base-font-color;
      }
      .el-input__icon {
        color: $base-font-color;
        cursor: pointer;
      }
    }
  }
  .timepicker-nav-btn.active {
    /deep/ {
      .el-input__inner {
        background: $white-bg;
        border: 1px solid #00b0ff;
        box-shadow: 0px 0px 0px 2px rgba(17, 178, 255, 0.2);
        /*border: 1px solid rgba(27, 216, 247, 0.5);*/
        //color: $inputColorlight;
      }
      .el-input__icon {
        //color: $focusColor;
      }
    }
  }
  .timepicker-dropdown {
    position: absolute;
    background: #fff;
    margin-top: 10px;
    box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.1);
    z-index: 1000;
    width: 435px;
    wi &.left {
      /*left: 0;*/
    }
    &.right {
      /*right: 0;*/
    }
  }
  .timepicker-panel {
    width: 100%;
    padding: 10px 20px 25px 20px;
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;
  }
  .startTime,
  .endTime {
    /deep/ .el-input__inner,
    .el-input {
      width: 278px;
    }
    /deep/.el-input__inner {
      &:focus {
        border-color: $primary-color;
        box-shadow: 0px 0px 0px 2px rgba(17, 178, 255, 0.2);
      }
      &:hover {
        border-color: $primary-color;
      }
    }
  }
  .startTime {
    margin-bottom: 20px;
  }
  .timepicker-main {
    width: 70%;
    /deep/ {
      .el-input__inner {
        // color: $colorTextPrimary;
        //background:$pickerbgcolor;
        //border: 1px solid $pickerbordercolor;
        padding-left: 10px;
      }
      .el-input {
        width: 100%;
        min-width: 220px;
      }
      .el-input__prefix {
        left: calc(100% - 30px);
        //color: #979797;
        //color: $colorTextPrimary;
      }
      .el-button {
        // background: $btnfocusColor;
        //border-color: $btnfocusColor;
      }
    }
    .endTime {
      margin: 10px 0 10px 0;
    }
  }
  .timepicker-sidebar {
    min-width: 70px;
    margin-left: 50px;
    width: 25%;
    .title {
      text-align: right;
    }
    .el-radio-group {
      width: 100%;
      .el-radio-button {
        display: block;
        text-align: right;
        /deep/.el-radio-button__inner {
          font-family: PingFangSC-Regular;
          font-size: 13px !important;
          letter-spacing: 0;
        }
      }
    }
  }
  .el-radio-button {
    /deep/ {
      .el-radio-button__inner {
        background: transparent;
        border: 0;
        box-shadow: none;
        color: $colorTextSecondary;
        padding: 8px 0;
      }
    }
  }
  .el-radio-button.is-active {
    /deep/ {
      .el-radio-button__inner {
        color: $focusColor;
      }
    }
  }
  .title {
    font-size: 14px;
    color: $colorTextPrimary;
    font-weight: 700;
    /*margin-bottom: 10px;*/
    text-align: left;
  }
  .demonstration {
    font-size: 12px;
    min-height: 16px;
    color: $colorTextSecondary;
  }
  .refreshTime {
    .refreshpanel {
      display: flex;
      align-items: center;
      .el-button,
      .el-button.is-round {
        height: 32px;
        line-height: 32px;
      }
    }
    .refreshTimerWrap {
      flex-grow: 1;
      margin-right: 15px;
    }
    .el-button {
      /*margin-left: 15px;*/
    }
    /deep/ {
      .el-select__caret {
        color: $colorTextPrimary;
      }
      .el-icon-arrow-up {
        color: #3d424d;
        /*font-family:"iconfont" !important;*/
        /*&:before {*/
        /*  content: "\E78F";*/
        /*  !*content: '\E60C';*!*/
        /*}*/
      }
    }
  }
  /deep/ {
    .el-button {
      border-radius: 2px;
    }
    .el-input__inner {
      border-radius: 2px;
    }
  }
}
</style>
