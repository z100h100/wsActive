import Vue from 'vue'

import { ListPanel, SearchPanel, FormButtonArea, AdvancedSearch, topTab, PageTitle } from './Layout'

Vue.component('search-panel', SearchPanel)
Vue.component('advanced-search-panel', AdvancedSearch)
Vue.component('list-panel', ListPanel)
Vue.component('form-button-area', FormButtonArea)
Vue.component('top-tab', topTab)
Vue.component('page-title', PageTitle)
