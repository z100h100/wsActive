<template>
  <div class="inputFullContent" :style="{width}">
    <div
      :title="showName"
      @click="contentClick"
      v-show="isShowName"
      class="content"
      :style="{color, fontSize, fontFamily}">
      <span id="showName">{{showName}}</span>
      <i class="el-icon-arrow-down"></i>
    </div>
    <el-select
      ref="select"
      v-model="defaultValue"
      v-show="!isShowName"
      :remote-method="handleRemoteMethod"
      @visible-change="handleVisibleChange"
      :placeholder="hoderValue"
      v-bind="$attrs">
      <el-option
        v-for="item in options"
        :key="item[prop.code]"
        :label="item[prop.name]"
        :value="item[prop.code]">
      </el-option>
    </el-select>
  </div>
</template>

<script>
  /**
   *  继承了所有el-select属性
   *  color, font-size, font-family 为标题显示的样式
   *  options 下拉框内容
   *  prop {name: '下拉框绑定的label值'， code: 下拉框绑定的value值}
   *  时间 change 选择变化事件
   * */
  export default {
    inheritAttrs: false,
    props: {
      color: {
        type: String,
        default: '#00B0FF'
      },
      'font-size': {
        type: String,
        default: '14px'
      },
      'font-family': {
        type: String,
        default: 'PingFangSC-Medium'
      },
      'remote-method': {
        type: Function
      },
      value: {
        default: ''
      },
      options: {
        type: Array,
        default: () => []
      },
      prop: {
        type: Object,
        default: () => {
          return {
            name: 'name',
            code: 'code'
          }
        }
      },
      placeholder: {
        default: ''
      }
    },
    computed: {
      defaultValue: {
        get () {
          return this.value
        },
        set (val) {
          this.$emit('input', val)
          this.$emit('change', val)
        }
      },
      showName: {
        get () {
          return this.getShowName()
        }
      }
    },
    data () {
      return {
        isShowName: true,
        hoderValue: '',
        width: '200px'
      }
    },
    mounted () {
      this.getWidth()
    },
    methods: {
      handleRemoteMethod () {
        if (typeof this['remoteMethod'] !== 'function') return
        this['remoteMethod']()
      },
      handleVisibleChange (status) {
        if (!status) {
          this.isShowName = true
          this.$nextTick(() => {
            this.getWidth()
          })
        }
      },
      getShowName () {
        let name = ''
        let obj = this.options.find(v => v[this.prop.code] === this.defaultValue)
        if (obj) name = obj[this.prop.name]
        return name
      },
      contentClick () {
        this.getWidth()
        this.isShowName = false
        this.hoderValue = this.showName
        this.defaultValue = ''
        this.$nextTick(() => {
          this.$refs.select.focus()
        })
      },
      getWidth () {
        let el = document.getElementById('showName')
        let range = document.createRange()
        range.setStart(el, 0)
        range.setEnd(el, el.childNodes.length)
        this.width = range.getBoundingClientRect().width + 50 + 'px'
        console.log(this.width)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .inputFullContent{
    .content{
      width: 100%;
      height: 32px;
      line-height: 32px;
      text-indent: 10px;
      overflow: hidden;
      text-overflow:ellipsis;
      white-space: nowrap;
      cursor: pointer;
    }
  }
</style>

<style lang="scss">
  .inputFullContent{
    .el-input__inner{
      border: 0px solid #dcdfe6 !important;
    }
    .el-select{
      width: 100%;
    }
  }
</style>

