<template>
  <div @mouseenter="cellHover">
    <el-popover placement="bottom-start" :width="slotWidth" @show="setContent" trigger="focus">
      <ul class="propList">
        <li v-for="item in messageList">
          <i class="state el-icon-success success" v-if="item.state == true"></i>
          <i class="state el-icon-error fail" v-else-if="item.state == false"></i>
          <i class="state cirle" v-else></i>
          <span>{{ item.msg }}</span>
        </li>
      </ul>
      <div slot="reference" ref="reference">
        <slot name="reference-area"></slot>
      </div>
    </el-popover>
  </div>
</template>

<script>
// import validator from 'async-validator/lib/index.js'
var Schema = require('async-validator')
export default {
  name: 'index',
  data() {
    return {
      errors: [],
      messageList: [],
      slotWidth: '200'
    }
  },
  props: {
    prop: {
      type: Array,
      default: () => []
    },
    value: {},
    message: {
      type: Array,
      default: () => []
    }
  },
  watch: {
    // prop: {
    //   // handler(val) {
    //   //   console.log('prop=', val)
    //   //   // this.setContent(val)
    //   // },
    //   // deep: true
    //   // value(val, old) {
    //   //   this.setContent(val)
    //   // }
    // },
    prop(val) {},
    value(val, old) {
      this.setvalute(val)
    },
    message(val, old) {
      this.messageList = JSON.parse(JSON.stringify(val))
    }
  },
  mounted() {},
  methods: {
    setContent() {
      if (this.messageList.length === 0) {
        this.messageList = JSON.parse(JSON.stringify(this.message))
      }
    },
    setvalute(val) {
      if (val === '') {
        // 输入值为空 设置所有message 状态为 null
        this.messageList.forEach(subItem => {
          subItem.state = null
        })
        return false
      }
      // 设置规则名称和验证规则
      var rules = {
        rulesname: this.prop
      }
      // 设置需要验证的值
      let value = {
        rulesname: this.value
      }
      let validator = new Schema(rules)
      let that = this
      //  firstFields: false  遇到验证失败的会继续下面的验证
      validator.validate(value, { firstFields: false }, (errors, fields) => {
        // console.log(fields)
        that.errors = errors
        that.setStatus()
        // if (errors) {
        //
        //   // return handleErrors(errors, fields);
        // }
        // validation passed
      })
    },
    setStatus() {
      this.messageList.forEach(subItem => {
        subItem.state = true
      })
      if (!this.errors) {
        return
      }
      var len = this.errors.length
      for (let i = 0; i < len; i++) {
        let item = this.errors[i]

        var subLen = this.messageList.length
        for (let j = 0; j < subLen; j++) {
          let subItem = this.messageList[j]

          if (item.message == subItem.msg) {
            subItem.state = false
            continue
          }
        }
      }
    },
    afterLeave() {
      this.messageList = []
    },
    cellHover(e) {
      let el = e.target
      this.slotWidth = el.offsetWidth
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';

.cirle {
  display: inline-block;
  width: 14px;
  height: 14px;
  text-align: center;
  line-height: 13px;
  border-radius: 50%;
  border: 1px solid #eee;
  font-size: 12px;
  color: #fff;
  background: #fff;
  vertical-align: middle;
}
.state {
  &.fail {
    color: $danger-color;
  }

  &.success {
    color: $success-color;
  }
}

.propList {
  list-style: none;
  padding: 0;
  line-height: 20px;
  font-size: 12px;
  color: #9097a4;
  li {
    margin: 8px 0;
    display: flex;
    align-items: center;
    i {
      font-size: 14px;
      flex-grow: 0;
      flex-shrink: 0;
    }
    span {
      padding-left: 5px;
    }
  }
}
</style>
