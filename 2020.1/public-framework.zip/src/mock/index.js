import Mock from 'mockjs'
import demoList from './json/demoList.json'
import formByAPI from './json/formSource.json'
import formDataByAPI from './json/tempSource.json'
import projectMember from './json/projectMember.json' // 右侧通讯录-获取项目成员
import userNotProject from './json/userNotProject.json' // 右侧通讯录-获取普通人员列表
import getRightDialogDemoList from './json/getRightDialogDemoList.json' // 右侧通讯录列表数据
import triggerHistoryDetail from './json/triggerHistoryDetail.json'
import echartsInList from './json/echartsInList.json'
import log from './json/log.json'
import treeData from './json/treeData.json'
Mock.setup({
  timeout: '350-600'
})

Mock.mock(new RegExp('/demo/list', 'i'), 'get', demoList)
Mock.mock(new RegExp('/demo/formByAPI', 'i'), 'get', formByAPI)
Mock.mock(new RegExp('/demo/formDataByAPI', 'i'), 'get', formDataByAPI)
Mock.mock(new RegExp('/demo/projectMember', 'i'), 'get', projectMember) // 右侧通讯录-获取项目成员
Mock.mock(new RegExp('/demo/getUserNotProject', 'i'), 'get', userNotProject) // 右侧通讯录-获取普通人员列表
Mock.mock(new RegExp('/demo/getRightDialogDemoList', 'i'), 'get', getRightDialogDemoList) // 右侧通讯录列表数据
Mock.mock(new RegExp('/demo/triggerHistoryDetail', 'i'), 'get', triggerHistoryDetail)
Mock.mock(new RegExp('/demo/log', 'i'), 'get', log)
Mock.mock(new RegExp('/demo/treeData', 'i'), 'get', treeData)
Mock.mock(new RegExp('/demo/echartsInList', 'i'), 'get', echartsInList)

export default Mock
