export let constantRouterMap = [
  {
    path: '/',
    component: resolve => require(['@/views/layout/Layout'], resolve),
    redirect: '/demo/common/list',
    name: 'home',
    hidden: true
  },
  // 404
  {
    path: '/404',
    component: resolve => require(['@/views/404'], resolve),
    hidden: true
  },
  // 503
  {
    path: '/503',
    component: resolve => require(['@/views/503'], resolve),
    hidden: true
  },
  // dashboard
  // {
  //   path: '/demo',
  //   redirect: '/demo/dashboard',
  //   component: resolve => require(['@/views/layout/Layout'], resolve),
  //   meta: {
  //     title: 'common',
  //     icon: 'icon-ic-shouye'
  //   },
  //   children: [
  //     {
  //       path: 'dashboard',
  //       name: 'dashboard',
  //       component: resolve => require(['@/views/demo/dashboard/index'], resolve),
  //       meta: {
  //         title: 'dashboard',
  //         breadLevel: 0,
  //         icon: 'icon-ic-shouye'
  //       }
  //     },
  //   ]
  // },
  // common
  {
    path: '/demo/common',
    redirect: '/demo/common/list',
    component: resolve => require(['@/views/layout/Layout'], resolve),
    meta: {
      title: 'common',
      icon: 'icon-ic-xinxiguanli'
    },
    children: [
      {
        path: 'list',
        name: 'listPage',
        component: resolve => require(['@/views/demo/common/list/index'], resolve),
        meta: {
          title: 'list',
          breadLevel: 0
        }
      },
      {
        path: 'advancedList',
        name: 'advancedList',
        component: resolve => require(['@/views/demo/common/list/advancedList'], resolve),
        meta: {
          title: 'advancedList',
          breadLevel: 0
        }
      },
      {
        path: 'listLeftTree',
        name: 'listLeftTree',
        component: resolve => require(['@/views/demo/common/list/listLeftTree/index'], resolve),
        meta: {
          title: 'listLeftTree',
          breadLevel: 0
        }
      },
      {
        path: 'tabList',
        name: 'tabList',
        component: resolve => require(['@/views/demo/common/list/tabList/index'], resolve),
        meta: {
          title: 'tabList',
          breadLevel: 0
        }
      },
      {
        path: 'listFilters',
        name: 'listFilters',
        component: resolve =>
          require(['@/views/demo/common/list/advancedListWithFilters/index'], resolve),
        meta: {
          title: 'listFilters',
          breadLevel: 0
        }
      },
      {
        path: 'stateTableWidthMessage',
        name: 'stateTableWidthMessage',
        component: resolve => require(['@/views/demo/common/list/stateTableWidthMessage'], resolve),
        meta: {
          title: 'stateTableWidthMessage',
          breadLevel: 0
        }
      },
      {
        path: 'rowEdit',
        name: 'rowEdit',
        component: resolve => require(['@/views/demo/common/list/rowEdit'], resolve),
        meta: {
          title: 'rowEdit',
          breadLevel: 0
        }
      },
      {
        path: 'onOffBubble',
        name: 'onOffBubble',
        component: resolve => require(['@/views/demo/common/list/onOffBubble'], resolve),
        meta: {
          title: 'onOffBubble',
          breadLevel: 0
        }
      },
      {
        path: 'moreHeader',
        name: 'moreHeader',
        component: resolve => require(['@/views/demo/common/list/moreHeader'], resolve),
        meta: {
          title: 'moreHeader',
          breadLevel: 0
        }
      },
      {
        path: 'detailBubble',
        name: 'detailBubble',
        component: resolve => require(['@/views/demo/common/list/detailBubble'], resolve),
        meta: {
          title: 'detailBubble',
          breadLevel: 0
        }
      },
      {
        path: 'listLeftTable',
        name: 'listLeftTable',
        component: resolve => require(['@/views/demo/common/list/listLeftTable'], resolve),
        meta: {
          title: 'listLeftTable',
          breadLevel: 0
        }
      },
      {
        path: 'tableNoData',
        name: 'tableNoData',
        component: resolve => require(['@/views/demo/common/list/tableNoData'], resolve),
        meta: {
          title: 'tableNoData',
          breadLevel: 0
        }
      },
      {
        path: 'commonSearch',
        name: 'commonSearch',
        component: resolve => require(['@/views/demo/common/list/commonSearch'], resolve),
        meta: {
          title: 'commonSearch',
          breadLevel: 0
        }
      },
      {
        path: 'echartsInList',
        name: 'echartsInList',
        component: resolve => require(['@/views/demo/common/list/echartsInList'], resolve),
        meta: {
          title: 'echartsInList',
          breadLevel: 0
        }
      },
      {
        path: 'listInList',
        name: 'listInList',
        component: resolve => require(['@/views/demo/common/list/listInList'], resolve),
        meta: {
          title: 'listInList',
          breadLevel: 0
        }
      },
      // 表单
      {
        path: 'regularSplitHorizontal',
        name: 'regularSplitHorizontal',
        component: resolve => require(['@/views/demo/common/form/regularSplitHorizontal'], resolve),
        meta: {
          title: 'regularSplitHorizontal',
          breadLevel: 0
        }
      },
      {
        path: 'regularTwoHorizontal',
        name: 'regularTwoHorizontal',
        component: resolve =>
          require(['@/views/demo/common/form/regularAppositionHorizontal'], resolve),
        meta: {
          title: 'regularTwoHorizontal',
          breadLevel: 0
        }
      },
      {
        path: 'regularThreeHorizontal',
        name: 'regularThreeHorizontal',
        component: resolve => require(['@/views/demo/common/form/regularThreeHorizontal'], resolve),
        meta: {
          title: 'regularThreeHorizontal',
          breadLevel: 0
        }
      },
      {
        path: 'inputForm',
        name: 'inputForm',
        component: resolve => require(['@/views/demo/common/form/inputForm'], resolve),
        meta: {
          title: 'inputForm',
          breadLevel: 0
        }
      },
      {
        path: 'radioForm',
        name: 'radioForm',
        component: resolve => require(['@/views/demo/common/form/radioForm'], resolve),
        meta: {
          title: 'radioForm',
          breadLevel: 0
        }
      },
      {
        path: 'checkBoxForm',
        name: 'checkBoxForm',
        component: resolve => require(['@/views/demo/common/form/checkBoxForm'], resolve),
        meta: {
          title: 'checkBoxForm',
          breadLevel: 0
        }
      },
      {
        path: 'inputNumberForm',
        name: 'inputNumberForm',
        component: resolve => require(['@/views/demo/common/form/inputNumberForm'], resolve),
        meta: {
          title: 'inputNumberForm',
          breadLevel: 0
        }
      },
      {
        path: 'selectForm',
        name: 'selectForm',
        component: resolve => require(['@/views/demo/common/form/selectForm'], resolve),
        meta: {
          title: 'selectForm',
          breadLevel: 0
        }
      },
      {
        path: 'cascaderForm',
        name: 'cascaderForm',
        component: resolve => require(['@/views/demo/common/form/cascaderForm'], resolve),
        meta: {
          title: 'cascaderForm',
          breadLevel: 0
        }
      },
      {
        path: 'switchForm',
        name: 'switchForm',
        component: resolve => require(['@/views/demo/common/form/switchForm'], resolve),
        meta: {
          title: 'switchForm',
          breadLevel: 0
        }
      },
      {
        path: 'sliderForm',
        name: 'sliderForm',
        component: resolve => require(['@/views/demo/common/form/sliderForm'], resolve),
        meta: {
          title: 'sliderForm',
          breadLevel: 0
        }
      },
      {
        path: 'datePickerForm',
        name: 'datePickerForm',
        component: resolve => require(['@/views/demo/common/form/datePickerForm'], resolve),
        meta: {
          title: 'datePickerForm',
          breadLevel: 0
        }
      },
      {
        path: 'uploadForm',
        name: 'uploadForm',
        component: resolve => require(['@/views/demo/common/form/uploadForm'], resolve),
        meta: {
          title: 'uploadForm',
          breadLevel: 0
        }
      },
      {
        path: 'rateAndColorForm',
        name: 'rateAndColorForm',
        component: resolve => require(['@/views/demo/common/form/rateAndColorForm'], resolve),
        meta: {
          title: 'rateAndColorForm',
          breadLevel: 0
        }
      },
      {
        path: 'transferForm',
        name: 'transferForm',
        component: resolve => require(['@/views/demo/common/form/transferForm'], resolve),
        meta: {
          title: 'transferForm',
          breadLevel: 0
        }
      },
      {
        path: 'customForm',
        name: 'customForm',
        component: resolve => require(['@/views/demo/common/form/customForm/index'], resolve),
        meta: {
          title: 'customForm',
          breadLevel: 0
        }
      },
      // 弹框
      {
        path: 'dialogLog',
        name: 'dialogLog',
        component: resolve => require(['@/views/demo/common/list/dialogLog'], resolve),
        meta: {
          title: 'dialogLog',
          breadLevel: 0
        }
      },
      {
        path: 'noticeDialog',
        name: 'noticeDialog',
        component: resolve => require(['@/views/demo/common/form/noticeDialog'], resolve),
        meta: {
          title: 'noticeDialog',
          breadLevel: 0
        }
      },
      {
        path: 'dialogFormHorizontal',
        name: 'dialogFormHorizontal',
        component: resolve => require(['@/views/demo/common/list/dialogFormHorizontal'], resolve),
        meta: {
          title: 'dialogFormHorizontal',
          breadLevel: 0
        }
      },
      {
        path: 'dialogListRight',
        name: 'dialogListRight',
        component: resolve => require(['@/views/demo/common/list/dialogListRight/index'], resolve),
        meta: {
          title: 'dialogListRight',
          breadLevel: 0
        }
      },
      {
        path: 'dialogList',
        name: 'dialogList',
        component: resolve => require(['@/views/demo/common/list/dialogList/index'], resolve),
        meta: {
          title: 'dialogList',
          breadLevel: 0
        }
      },
      {
        path: 'dialogRight',
        name: 'dialogRight',
        component: resolve =>
          require(['@/views/demo/common/list/advancedListWithDialogRight/index'], resolve),
        meta: {
          title: 'dialogRight',
          breadLevel: 0
        }
      },
      {
        path: 'detailMenuLeft',
        name: 'detailMenuLeft',
        component: resolve => require(['@/views/demo/common/detail/menuLeft'], resolve),
        meta: {
          title: 'detailMenuLeft',
          breadLevel: 0
        }
      },
      {
        path: 'detailMenuRight',
        name: 'detailMenuRight',
        component: resolve => require(['@/views/demo/common/detail/menuRight'], resolve),
        meta: {
          title: 'detailMenuRight',
          breadLevel: 0
        }
      },
      {
        path: 'multilevelTab',
        name: 'multilevelTab',
        component: resolve => require(['@/views/demo/common/list/multilevelTab'], resolve),
        meta: {
          title: 'multilevelTab',
          breadLevel: 0
        }
      },
      {
        path: 'charts',
        name: 'charts',
        component: resolve => require(['@/views/demo/common/list/charts'], resolve),
        meta: {
          title: 'charts',
          breadLevel: 0
        }
      }
    ]
  },
  // {
  //   path: '/demo/dagTest',
  //   hidden: false,
  //   component: resolve => require(['@/views/layout/Layout'], resolve),
  //   children: [
  //     {
  //       path: 'list',
  //       name: 'listPage',
  //       component: resolve => require(['@/views/demo/common/list/index'], resolve),
  //       meta: {
  //         title: 'list',
  //         icon: 'icon-ic-home'
  //       }
  //     }
  //   ]
  // },
  {
    path: '/demo/kmedia',
    redirect: '/demo/kmedia/kmedia',
    component: resolve => require(['@/views/layout/Layout'], resolve),
    meta: {
      title: 'kmedia',
      icon: 'icon-ic-zhujiliebiao'
    },
    children: [
      {
        path: 'singleFile',
        name: 'singleFile',
        component: resolve => require(['@/views/demo/thirdparty/kmedia/singleFile'], resolve),
        meta: {
          title: 'singleFile',
          breadLevel: 0
        }
      },
      {
        path: 'multipleFile',
        name: 'multipleFile',
        component: resolve => require(['@/views/demo/thirdparty/kmedia/multipleFile'], resolve),
        meta: {
          title: 'multipleFile',
          breadLevel: 0
        }
      },
      {
        path: 'liveStream',
        name: 'liveStream',
        component: resolve => require(['@/views/demo/thirdparty/kmedia/liveStream'], resolve),
        meta: {
          title: 'liveStream',
          breadLevel: 0
        }
      }
    ]
  },
  {
    path: '/demo/map',
    redirect: '/demo/map/kmap',
    component: resolve => require(['@/views/layout/Layout'], resolve),
    meta: {
      title: 'map',
      icon: 'icon-ic-hangzhengquyuguanli'
    },
    children: [
      {
        path: 'kedaNewMap',
        name: 'kedaNewMap',
        component: resolve => require(['@/views/demo/thirdparty/map/kedaNewMap'], resolve),
        meta: {
          title: 'kedaNewMap',
          breadLevel: 0
        }
      },
      // {
      //   path: 'gmap',
      //   name: 'gmap',
      //   component: resolve => require(['@/views/demo/thirdparty/map/gmap'], resolve),
      //   meta: {
      //     title: 'gmap',
      //     breadLevel: 0
      //   }
      // },
      {
        path: 'kmap',
        name: 'kmap',
        component: resolve => require(['@/views/demo/thirdparty/map/kmap'], resolve),
        meta: {
          title: 'kmap',
          breadLevel: 0
        }
      }
    ]
  },

  {
    path: '*',
    redirect: '/404',
    hidden: true
  }
]
let devRouter = [
  {
    path: '/demo/component',
    redirect: '/demo/component/dag',
    component: resolve => require(['@/views/layout/Layout'], resolve),
    meta: {
      title: 'component',
      icon: 'icon-ic-wangyefenxi'
    },
    children: [
      {
        path: 'dag-vertical',
        name: 'dagVertical',
        component: resolve => require(['@/views/demo/component/dag-vertical/index'], resolve),
        meta: {
          title: 'dagVertical',
          breadLevel: 0
        }
      },
      {
        path: 'dag-align',
        name: 'dagAlign',
        component: resolve => require(['@/views/demo/component/dag-align/index'], resolve),
        meta: {
          title: 'dagAlign',
          breadLevel: 0
        }
      },
      {
        path: 'code-mirror',
        name: 'codeMirror',
        component: resolve => require(['@/views/demo/component/code-mirror/index'], resolve),
        meta: {
          title: 'codeMirror',
          breadLevel: 0
        }
      },
      {
        path: 'deptTree',
        name: 'deptTree',
        component: resolve => require(['@/views/demo/component/deptTree/index'], resolve),
        meta: {
          title: 'deptTree',
          breadLevel: 0
        }
      },
      {
        path: 'timeSelect',
        name: 'timeSelect',
        component: resolve => require(['@/views/demo/component/TimeSelect/index'], resolve),
        meta: {
          title: 'timeSelect',
          breadLevel: 0
        }
      },
      {
        path: 'formByAPI',
        name: 'formByAPI',
        component: resolve => require(['@/views/demo/component/formcheck/formByAPI'], resolve),
        meta: {
          title: 'formByAPI',
          breadLevel: 0
        }
      },
      {
        path: 'formcheck',
        name: 'formcheck',
        component: resolve => require(['@/views/demo/component/formcheck/index'], resolve),
        meta: {
          title: 'formcheck',
          breadLevel: 0
        }
      },
      {
        path: 'slider',
        name: 'slider',
        component: resolve => require(['@/views/demo/component/slider/index'], resolve),
        meta: {
          title: 'slider',
          breadLevel: 0
        }
      },
      {
        path: 'timeRangeSlide',
        name: 'timeRangeSlide',
        component: resolve => require(['@/views/demo/component/timeRangeSlide/index'], resolve),
        meta: {
          title: 'timeRangeSlide',
          breadLevel: 0
        }
      },
      {
        path: 'validPopover',
        name: 'validPopover',
        component: resolve => require(['@/views/demo/component/validPopover/index'], resolve),
        meta: {
          title: 'validPopover',
          breadLevel: 0
        }
      },
      {
        path: 'tablePopover',
        name: 'tablePopover',
        component: resolve => require(['@/views/demo/component/tablePopover/index'], resolve),
        meta: {
          title: 'tablePopover',
          breadLevel: 0
        }
      }
      // {
      //   path: 'inputFullContent',
      //   name: 'inputFullContent',
      //   component: resolve => require(['@/views/demo/component/inputFullContent/index'], resolve),
      //   meta: {
      //     title: 'inputFullContent',
      //     breadLevel: 0
      //   }
      // }
    ]
  },
  {
    path: '/demo/apm',
    redirect: '/demo/apm/',
    alwaysShow: true,
    component: resolve => require(['@/views/layout/Layout'], resolve),
    meta: {
      title: 'apm',
      breadLevel: 0,
      icon: 'icon-zhujijiankong'
    },
    children: [
      {
        path: '',
        name: 'arms',
        component: resolve => require(['@/views/demo/thirdparty/apm/index'], resolve),
        meta: {
          title: 'arms',
          breadLevel: 1
        }
      }
    ]
  }
]

constantRouterMap = [...constantRouterMap, ...devRouter]

export default constantRouterMap
