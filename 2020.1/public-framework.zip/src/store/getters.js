const getters = {
  sidebar: state => state.app.sidebar,
  device: state => state.app.device,
  dialog: state => state.app.dialog,
  pageTip: state => state.app.pageTip,
  searchTags: state => state.demo.searchTags
}
export default getters
