// 国际化
export const SETLANGUAGE = 'setLanguage'

// 侧边栏
export const TOGGLE_SIDE_BAR = 'TOGGLE_SIDEBAR'
export const CLOSE_SIDE_BAR = 'CLOSE_SIDE_BAR'

// 切换device
export const TOGGLE_DEVICE = 'TOGGLE_DEVICE'

// 面包屑相关
export const BREADLISTADD = 'BREADLISTADD'
export const BREADLISTREMOVE = 'BREADLISTREMOVE'
export const BREADLISTSET = 'BREADLISTSET'

// 页面提示
export const SETPAGETIP = 'SETPAGETIP'
