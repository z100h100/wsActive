import api from '@/apis'
import * as TYPES from './mutationTypes'

export default {
  // 列表
  getDemoList({ commit }, params) {
    return api.demo
      .getDemoList(params)
      .then(response => response.data)
      .then(({ result }) => {
        commit(TYPES.GET_DEMO_LIST, {
          result,
          params
        })
        return result
      })
      .catch(error => Promise.reject(error))
  },

  resetSearchCriteria({ commit }) {
    commit(TYPES.RESET_SEARCH_CRITERIA)
  },
  getformDataAPI({ commit }, params) {
    return api.demo
      .getformByAPI(params)
      .then(response => response.data)
      .catch(error => Promise.reject(error))
  },
  getformDetailAPI({ commit }, params) {
    return api.demo
      .getformDataByAPI(params)
      .then(response => response.data)
      .catch(error => Promise.reject(error))
  },
  // 获取项目成员
  getProjectPersonListApi(commit, params) {
    return api.demo
      .getProjectPersonListApi(params)
      .then(response => {
        if (response.data) {
          return response.data
        } else {
          return response
        }
      })
      .catch(error => Promise.reject(error))
  },
  // 获取普通人员列表
  getPersonListApi(commit, params) {
    return api.demo
      .getPersonListApi(params)
      .then(response => {
        if (response.data) {
          return response.data
        } else {
          return response
        }
      })
      .catch(error => Promise.reject(error))
  },
  // 删除项目人员
  deleteProjectPersonApi(commit, params) {
    return api.demo
      .deleteProjectPersonApi({ params })
      .then(response => {
        if (response.data) {
          return response.data
        } else {
          return response
        }
      })
      .catch(error => Promise.reject(error))
  },
  // 添加项目成员
  setProjectPersonApi(commit, params) {
    return api.demo
      .setProjectPersonApi(params)
      .then(response => {
        if (response.data) {
          return response.data
        } else {
          return response
        }
      })
      .catch(error => Promise.reject(error))
  },
  // 批量添加项目成员
  setAllProjectPersonApi(commit, params) {
    return api.demo
      .setAllProjectPersonApi(params)
      .then(response => {
        if (response.data) {
          return response.data
        } else {
          return response
        }
      })
      .catch(error => Promise.reject(error))
  },
  // 获取右侧通讯录主页数据
  getRightDialogDemoList({ commit }, params) {
    return api.demo
      .getRightDialogDemoList(params)
      .then(response => response.data)
      .then(({ result }) => {
        commit(TYPES.GET_RIGHTDIALOG_LIST, {
          result,
          params
        })
      })
  },
  get_triggerHistoryDetail({ commit }, params) {
    return api.demo
      .gettriggerHistoryDetail(params)
      .then(response => response.data)
      .catch(error => Promise.reject(error))
  },
  // 日志
  get_Log({ commit }, params) {
    return api.demo
      .getLog(params)
      .then(response => response.data)
      .catch(error => Promise.reject(error))
  },
  // 树数据
  get_tree({ commit }, params) {
    return api.demo
      .getTreeData(params)
      .then(response => response.data)
      .then(({ result }) => {
        commit(TYPES.GET_TREE_DATA, {
          result,
          params
        })
        return result
      })
      .catch(error => Promise.reject(error))
  },
  getEchartsInList({ commit }, params) {
    return api.demo
      .getEchartsInList(params)
      .then(response => {
        if (response.data) {
          return response.data
        } else {
          return response
        }
      })
      .catch(error => Promise.reject(error))
  }
}
