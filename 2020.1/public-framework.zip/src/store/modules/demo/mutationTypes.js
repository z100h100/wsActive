export const GET_DEMO_LIST = 'GET_DEMO_LIST'
// 重置搜索
export const RESET_SEARCH_CRITERIA = 'RESET_SEARCH_CRITERIA'

// 获取右侧通讯录主页数据
export const GET_RIGHTDIALOG_LIST = 'GET_RIGHTDIALOG_LIST'

// 获取树数据
export const GET_TREE_DATA = 'GET_TREE_DATA'
