import * as TYPES from './mutationTypes'

export default {
  // 列表
  [TYPES.GET_DEMO_LIST](state, payload) {
    const { pageNo, pageSize, total } = payload.result
    Object.assign(state, {
      list: payload.result.data,
      paging: { pageNo, pageSize, total },
      searchCriteria: {
        id: payload.params.id,
        compoanyName: payload.params.compoanyName,
        userName: payload.params.userName,
        cardNumber: payload.params.cardNumber,
        cardNo: payload.params.cardNo,
        pageNo: payload.params.pageNo,
        pageSize: payload.params.pageSize
      }
    })
  },
  // 重置搜索项
  [TYPES.RESET_SEARCH_CRITERIA](state) {
    Object.assign(state, {
      searchCriteria: {
        id: '',
        compoanyName: '',
        userName: '',
        cardNumber: '',
        cardNo: '',
        pageNo: 0,
        pageSize: 10
      }
    })
  },
  // 获取右侧通讯录主页数据
  [TYPES.GET_RIGHTDIALOG_LIST](state, payload) {
    const { pageNo, pageSize, total } = payload.result
    Object.assign(state, {
      list: payload.result.data,
      paging: { pageNo, pageSize, total },
      searchCriteria: {
        id: payload.params.id,
        compoanyName: payload.params.compoanyName,
        userName: payload.params.userName,
        cardNumber: payload.params.cardNumber,
        cardNo: payload.params.cardNo,
        pageNo: payload.params.pageNo,
        pageSize: payload.params.pageSize
      }
    })
  },
  // 获取树数据
  [TYPES.GET_TREE_DATA](state, payload) {
    Object.assign(state, {
      treeData: payload.result.data
    })
  }
}
