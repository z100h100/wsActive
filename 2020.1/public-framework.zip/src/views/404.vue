<template>
  <div style="background:#fff;margin-top: -20px;">
    <div class="img">
      <img :src="img404" class="pic" alt="404" />
    </div>
    <div class="message-info">
      请检查您输入的网址是否正确，点击一下按钮返回主页或者发送错误报告。
    </div>
    <div class="btns">
      <el-button size="large" type="primary" @click="handleGoHome">返回首页</el-button>
      <el-button size="large">反馈问题</el-button>
    </div>
  </div>
</template>

<script>
import img404 from '@/assets/404_images/404.png'
export default {
  data() {
    return {
      img404
    }
  },
  computed: {},
  mounted() {
    document.getElementById('page-preloading').style.display = 'none'
  },
  methods: {
    handleGoHome() {
      this.$router.push({
        name: 'home'
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.img {
  width: 100%;
  display: flex;
  justify-content: center;
  .pic {
    position: relative;
    padding: 170px 0 55px;
  }
}
.message-info {
  margin-bottom: 30px;
  font-family: PingFangSC-Regular;
  font-size: 16px;
  color: #3d424d;
  text-align: center;
  line-height: 28px;
}
.btns {
  display: flex;
  justify-content: center;
  button {
    width: 104px;
    height: 42px;
    line-height: 42px;
    border-radius: 4px;
    font-size: 16px;
  }
  button + button {
    margin-left: 30px;
  }
}
</style>
