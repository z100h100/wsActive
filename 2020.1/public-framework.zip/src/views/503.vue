<template>
  <div style="background:#fff;margin-top: -20px;">
    <div class="img">
      <img :src="img503" class="pic" alt="404" />
    </div>
    <ul class="message-info">
      <li>1. 服务暂时不可用，请<a href="javascript:;">刷新</a>重试。</li>
      <li>2. 如果多次刷新仍未恢复正常，请稍后再尝试。</li>
      <li>3. 目前我们正在努力解决该问题，因此给您造成不便我们非常抱歉！</li>
    </ul>
    <div class="btns">
      <el-button size="large" type="primary" @click="handleGoHome">返回首页</el-button>
      <el-button size="large">反馈问题</el-button>
    </div>
  </div>
</template>

<script>
import img503 from '@/assets/503_images/503.png'
export default {
  data() {
    return {
      img503
    }
  },
  computed: {},
  mounted() {
    document.getElementById('page-preloading').style.display = 'none'
  },
  methods: {
    handleGoHome() {
      this.$router.push({
        name: 'home'
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.img {
  width: 100%;
  display: flex;
  justify-content: center;
  .pic {
    position: relative;
    padding: 170px 0 55px;
  }
}
.message-info {
  width: 550px;
  margin: 0 auto;
  list-style: none;
  margin-bottom: 30px;
  font-family: PingFangSC-Regular;
  font-size: 16px;
  color: #3d424d;
  text-align: left;
  line-height: 28px;
}
.btns {
  display: flex;
  justify-content: center;
  button {
    width: 104px;
    height: 42px;
    line-height: 42px;
    border-radius: 4px;
    font-size: 16px;
  }
  button + button {
    margin-left: 30px;
  }
}
</style>
