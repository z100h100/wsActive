<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">创建工单</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">多选框组件</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">多选框</div>
                </div>
              </div>
              <el-form-item :required="true" label="多选框" class="full">
                <el-checkbox v-model="checked1">复选框A</el-checkbox>
                <el-checkbox v-model="checked2">复选框B</el-checkbox>
                <el-checkbox v-model="checked3">复选框C</el-checkbox>
              </el-form-item>
              <el-form-item :required="true" label="多选框禁用状态" class="full">
                <el-checkbox v-model="checked4" disabled>已勾选</el-checkbox>
                <el-checkbox v-model="checked5" disabled>未勾选</el-checkbox>
              </el-form-item>
              <el-form-item :required="true" label="可选项目数量的限制" class="full">
                <el-checkbox-group v-model="checkedCities1" :min="1" :max="2">
                  <el-checkbox v-for="city in cities1" :label="city" :key="city">{{
                    city
                  }}</el-checkbox>
                </el-checkbox-group>
              </el-form-item>
              <el-form-item :required="true" label="按钮样式" class="full">
                <el-checkbox-group v-model="checkboxGroup" size="small">
                  <el-checkbox-button v-for="city in cities" :label="city" :key="city">{{
                    city
                  }}</el-checkbox-button>
                </el-checkbox-group>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>
<script>
const cityOptions = ['上海', '北京', '广州', '深圳']
const cityOptions1 = ['上海', '北京', '广州', '深圳']
export default {
  data() {
    return {
      checkAll: false,
      isIndeterminate: true,
      checkedCities: ['上海', '北京'],
      checkedCities1: ['上海', '北京'],
      cities: cityOptions,
      cities1: cityOptions1,
      checked1: true,
      checked2: false,
      checked3: false,
      checked4: true,
      checked5: false,
      checked6: false,
      checked7: false,
      checked8: false,
      checkboxGroup: ['上海']
    }
  },
  mounted() {},
  methods: {
    handleCheckAllChange(val) {
      this.checkedCities = val ? cityOptions : []
      this.isIndeterminate = false
    },
    handleCheckedCitiesChange(value) {
      let checkedCount = value.length
      this.checkAll = checkedCount === this.cities.length
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length
    }
  }
}
</script>
