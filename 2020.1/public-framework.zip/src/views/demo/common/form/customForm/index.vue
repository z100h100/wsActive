<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">自定义组件</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">自定义组件</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">输入框</div>
                </div>
              </div>
              <el-form-item :required="true" label="复合型输入框" class="full">
                <el-input placeholder="请输入内容" v-model="input1">
                  <template slot="append">
                    <el-select v-model="select1" placeholder="请选择" style="width: 60px">
                      <el-option
                        v-for="item in options1"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </template>
                </el-input>
              </el-form-item>
              <el-form-item :required="true" label="计量器可选单位" class="full">
                <el-input-number v-model="num" size="medium" :min="0" :max="10"></el-input-number>
                <el-select
                  v-model="select2"
                  placeholder="请选择"
                  style="width: 70px;margin-left: 10px"
                >
                  <el-option
                    v-for="item in options2"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item :required="true" label="单位人员单选" class="full">
                <DeptPersonTree
                  :data="treeList2"
                  :prop="prop"
                  v-model="dept"
                  ref="dept2"
                  node-key="code"
                  clearable
                  filter
                ></DeptPersonTree>
              </el-form-item>
              <el-form-item :required="true" label="单位人员多选" class="full">
                <DeptPersonTree
                  multiple
                  :data="treeList2"
                  :prop="prop"
                  v-model="dept2"
                  ref="dept2"
                  node-key="code"
                  clearable
                  filter
                ></DeptPersonTree>
              </el-form-item>
              <el-form-item :required="true" label="ARMS日期选择" class="full">
                <TimeSelect
                  clearable
                  v-model="timeRange"
                  :prop="timeProp"
                  :pickerOptions="timeOptions"
                  size="medium"
                  :defaultValue="defaultValue"
                  @change="TimeSelectChange"
                ></TimeSelect>
              </el-form-item>
              <el-form-item :required="true" label="分类多项选择器" class="full">
                <tree-select
                  style="width: 100%"
                  :data="treeSelect.options"
                  :defaultProps="treeSelect.defaultProps"
                  multiple
                  :nodeKey="treeSelect.nodeKey"
                  :checkedKeys="treeSelect.defaultCheckedKeys"
                >
                </tree-select>
              </el-form-item>
              <el-form-item :required="true" label="receiver" class="full">
                <div class="receiver-wrapper">
                  <receiver-item
                    v-for="(item, index) in receivers"
                    :key="index"
                    :index="index"
                    :ruleForm="item"
                    :options="receiversOptions"
                    @addReceiver="addReceiver"
                    @deleteReceiver="deleteReceiver"
                  ></receiver-item>
                </div>
              </el-form-item>
              <el-form-item :required="true" label="matchers" class="full">
                <div class="matcherItem matchersItem">
                  <matcher-item
                    v-for="(item, index) in matchers"
                    :ref="'matcherItem'"
                    :key="index"
                    :ruleForm="item"
                    :index="index"
                    @addMatcher="addMatcher"
                    @deleteMatcher="deleteMatcher"
                  >
                  </matcher-item>
                </div>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>
<script>
import { mapActions } from 'vuex'
import DeptPersonTree from '@/components/DeptPersonTree'
import TimeSelect from '@/components/TimeSelect/index-ops'
import TreeSelect from '@/components/TreeSelect'
import MatcherItem from './matcherItem'
import ReceiverItem from './receiverItem'
export default {
  components: {
    DeptPersonTree,
    TimeSelect,
    TreeSelect,
    MatcherItem,
    ReceiverItem
  },
  data() {
    return {
      active: false,
      active1: true,
      loading: false,
      radio: 0,
      date: null,
      label: '',
      label2: '',
      test: '',
      input1: '',
      num: 0,
      select1: 'S',
      options1: [
        {
          value: 'S',
          label: 'S'
        },
        {
          value: 'M',
          label: 'M'
        },
        {
          value: 'H',
          label: 'H'
        }
      ],
      select2: 'MB',
      options2: [
        {
          value: 'KB',
          label: 'KB'
        },
        {
          value: 'MB',
          label: 'MB'
        },
        {
          value: 'GB',
          label: 'GB'
        }
      ],
      apiOptions1: [],
      apiOptions2: [],
      value1: '',
      value3: '',
      value2: [],
      value4: [],
      treeList2: [],
      dept: '',
      dept2: ['wj11111'],
      prop: {
        name: 'name',
        code: 'code',
        children: 'children'
      },
      timeRange: [],
      timeProp: {
        label: 'name',
        value: 'code'
      },
      defaultValue: '300',
      timeOptions: [
        { label: '2小时前', value: '120' },
        { label: '5小时前', value: '300' },
        { label: '1天前', value: '1400' }
      ],
      treeSelect: {
        options: [
          {
            id: 'a',
            label: 'a',
            children: [
              {
                id: 'aa',
                label: 'aa'
              },
              {
                id: 'ab',
                label: 'ab'
              }
            ]
          },
          {
            id: 'b',
            label: 'b'
          },
          {
            id: 'c',
            label: 'c'
          }
        ],
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        nodeKey: 'id',
        defaultCheckedKeys: []
      },
      matchers: [{ name: '', value: '', isRegex: false }],
      receivers: [{ select: '' }],
      receiversOptions: [
        {
          value: 'a',
          label: 'a'
        },
        {
          value: 'b',
          label: 'b'
        },
        {
          value: 'c',
          label: 'c'
        }
      ]
    }
  },
  mounted() {
    this.onOK2()
  },
  methods: {
    ...mapActions(['get_tree']),
    TimeSelectChange(val) {
      console.log(val)
    },
    onOK2() {
      // setTimeout(() => {
      //   let arr = [...data]
      //   this.treeList = arr
      // }, 1000)
      setTimeout(() => {
        // this.dept2.push('131231412')
      }, 5000)
      let param = {}
      param['f_like_name_or_code'] = ''
      this.get_tree(param)
        .then(res => {
          console.log(res)
          this.treeList2 = res
        })
        .catch(err => {
          console.error(err)
        })
    },
    deleteItem(index) {
      this.matchers.splice(index, 1)
    },
    addMatcher() {
      this.matchers.push({
        name: '',
        value: '',
        isRegex: false
      })
    },
    deleteMatcher(index) {
      this.matchers.splice(index, 1)
    },
    addReceiver() {
      this.receivers.push({ select: '' })
    },
    deleteReceiver(index) {
      this.receivers.splice(index, 1)
    }
  }
}
</script>

<style lang="scss">
.matchersItem {
  width: 660px;
  padding: 0 10px 10px 10px;
  // margin-bottom: 25px;
  background: rgba(242, 244, 249, 0.5);

  .deletereciever {
    right: 20px !important;
    top: 5px !important;
    width: 30px;
    height: 30px;
    border: 1px #dcdfe6 solid;
    text-align: center;
    background: #fff;
    color: #dcdfe6 !important;
    font-weight: bold;

    &:hover {
      text-decoration: none;
    }

    &:before {
      display: block;
      content: '';
      width: 15px;
      height: 2px;
      background: #dcdfe6;
      margin: 14px auto;
    }
  }
}
.receiver-wrapper {
  background: #f7f8fc;
  padding: 0 10px 10px 10px;
}
</style>
