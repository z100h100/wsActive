<template>
  <div class="matcher-wrapper">
    <div v-if="index === 0">
      <div class="title" style="display: inline-block;margin-left: 10px;width: 150px;">Key</div>
      <div class="title" style="display: inline-block;margin-left: 10px;width: 305px;">Value</div>
      <div class="title" style="display: inline-block;margin-left: 10px;">正则表达式</div>
    </div>
    <el-form label-position="top" :inline="true" :model="ruleForm" :rules="rules" ref="ruleForm">
      <el-form-item prop="name">
        <el-input
          style="width: 150px"
          v-model.trim="ruleForm.name"
          placeholder="请输入name"
        ></el-input>
      </el-form-item>
      <el-form-item prop="value">
        <el-input
          style="width: 305px"
          v-model.trim="ruleForm.value"
          placeholder="请输入value"
        ></el-input>
      </el-form-item>
      <el-form-item prop="isRegex" style="width:125px;">
        <el-switch v-model="ruleForm.isRegex" active-color="#1FB6FF" inactive-color="#DCDFE6">
        </el-switch>
        <span class="option"> {{ !ruleForm.isRegex ? ' 禁用' : ' 启用' }}</span>
        <i
          class="iconfont icon-tianjiaxiao"
          v-if="index === 0"
          @click="() => $emit('addMatcher')"
        ></i>
        <i
          class="iconfont icon-shanchu1"
          v-if="index !== 0"
          @click="() => $emit('deleteMatcher', index)"
        ></i>
      </el-form-item>
    </el-form>
  </div>
</template>
<script>
export default {
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请填写name', trigger: 'blur' },
          {
            pattern: '^[a-zA-Z_:][a-zA-Z0-9_:]*$', // name校验
            message: '名称校验错误'
          }
        ],
        value: [
          { required: true, message: '请填写value', trigger: 'blur' }
          // { validator: this.checkDashboard, trigger: 'blur' }
        ],
        isRegex: []
      }
      // ruleForm: {
      //   name: '',
      //   value: '',
      //   isRegex: false
      // },
    }
  },
  props: {
    ruleForm: {
      type: Object
    },
    index: {
      type: Number
    }
  },
  mounted() {
    // this.getList()
  },
  watch: {},
  computed: {},
  methods: {
    closeDialog() {
      this.$refs['ruleForm'].resetFields()
    },
    sbumitName() {
      let that = this
      var result = new Promise(function(resolve, reject) {
        that.$refs['ruleForm'].validate(valid => {
          if (valid) {
            resolve(valid)
          } else {
            reject(new Error(valid))
          }
        })
      })
      return result
    }
  }
}
</script>

<style lang="scss" scoped>
.matcher-wrapper {
  .icon-tianjiaxiao {
    color: #11b2ff;
    font-size: 18px;
    margin-left: 20px;
  }
  .icon-shanchu1 {
    display: none;
    color: #fb4d49;
    font-size: 18px;
    margin-left: 20px;
  }
  .title {
    font-family: PingFangSC-Regular;
    font-size: 13px;
    color: #494f5e;
    letter-spacing: 0;
  }
}
/deep/ .el-form {
  padding-bottom: 0 !important;
  border: 1px solid rgba(242, 244, 249, 0.5);
  &:hover {
    background: #e9f8ff;
    border: 1px solid #c5ecff;
    .icon-shanchu1 {
      display: inline-block;
    }
  }
  .el-form-item {
    margin: 5px !important;
    &:last-child {
      margin-right: 0 !important;
    }
    .el-form-item__label {
      padding: 0;
    }
    .el-form-item__content {
      display: flex;
      align-items: center;
    }
    .el-form-item__error {
      padding-top: 0px;
      top: 97%;
    }
    .label-tit {
      font-family: PingFangSC-Regular;
      font-size: 13px;
      color: #494f5e !important;
      letter-spacing: 0;
    }
    .option {
      font-family: PingFangSC-Medium;
      font-size: 13px;
      color: #494f5c;
      letter-spacing: 0;
    }
    .iconfont {
      margin-left: 26px;
    }
  }
}
// .el-dialog .el-form.el-form--label-top /deep/ .el-form-item .label-tit
</style>
