<template>
  <div>
    <span v-if="index === 0" class="title">请选择联系人组</span>
    <el-form label-position="top" :model="ruleForm" :rules="rules" ref="ruleForm">
      <el-form-item prop="select">
        <el-select
          style="width: 300px"
          v-model="ruleForm.select"
          @change="handleChange"
          @keyup.enter.native="getList()"
          placeholder="请选择联系组"
        >
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
        <i
          v-if="index === 0"
          class="iconfont icon-tianjiaxiao"
          @click="() => $emit('addReceiver')"
        ></i>
        <i v-else class="iconfont icon-shanchu1" @click="() => $emit('deleteReceiver', index)"></i>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      rules: {
        select: [
          { required: true, message: '请选择联系组', trigger: 'change' }
          // { validator: this.checkDashboard, trigger: 'blur' }
        ]
      }
    }
  },
  props: {
    index: {
      type: Number
    },
    options: {
      default: () => []
    },
    ruleForm: {
      type: Object
    }
  },
  mounted() {
    // this.getList()
  },
  watch: {
    // value: {
    //   handler: val => {
    //     this.ruleForm.sselect = val
    //     console.log(333333)
    //   },
    //   deep: true
    // }
  },
  computed: {},
  methods: {
    sbumitName() {
      let that = this
      var result = new Promise(function(resolve, reject) {
        that.$refs['ruleForm'].validate(valid => {
          if (valid) {
            resolve(valid)
          } else {
            reject(new Error(valid))
          }
        })
      })
      return result
    },
    closeDialog() {
      this.$refs['ruleForm'].resetFields()
    },
    handleChange(val) {
      this.$emit('input', val)
      this.$emit('change', val)
    }
  }
}
</script>

<style lang="scss" scoped>
.title {
  font-family: PingFangSC-Regular;
  font-size: 13px;
  color: #494f5e;
  letter-spacing: 0;
  margin-left: 10px;
}
.icon-tianjiaxiao {
  color: #11b2ff;
  font-size: 18px;
  margin-left: 20px;
}
.icon-shanchu1 {
  display: none;
  color: #fb4d49;
  font-size: 18px;
  margin-left: 20px;
}

/deep/ .el-form {
  padding-bottom: 0 !important;
  border: 1px solid rgba(242, 244, 249, 0.5);
  &:hover {
    background: #e9f8ff;
    border: 1px solid #c5ecff;
    .icon-shanchu1 {
      display: inline-block;
    }
  }
  .el-form-item {
    margin: 5px !important;
    .el-form-item__content {
      display: flex;
      align-items: center;
    }
  }
}
</style>
