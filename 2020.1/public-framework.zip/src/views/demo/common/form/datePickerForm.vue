<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">创建工单</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="200px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">时间/日期选择器</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">时间选择器</div>
                </div>
              </div>
              <el-form-item :required="true" label="固定时间点" class="full">
                <el-time-select
                  v-model="time1"
                  :picker-options="{
                    start: '08:30',
                    step: '00:15',
                    end: '18:30'
                  }"
                  placeholder="选择时间"
                >
                </el-time-select>
              </el-form-item>
              <el-form-item :required="true" label="任意时间点" class="full">
                <el-time-picker
                  v-model="time2"
                  :picker-options="{
                    selectableRange: '18:30:00 - 20:30:00'
                  }"
                  placeholder="任意时间点"
                >
                </el-time-picker>
              </el-form-item>
              <el-form-item :required="true" label="任意时间点2" class="full">
                <el-time-picker
                  arrow-control
                  v-model="time3"
                  :picker-options="{
                    selectableRange: '18:30:00 - 20:30:00'
                  }"
                  placeholder="任意时间点"
                >
                </el-time-picker>
              </el-form-item>
              <el-form-item :required="true" label="固定时间范围" class="full">
                <el-time-select
                  placeholder="起始时间"
                  v-model="time4"
                  :picker-options="{
                    start: '08:30',
                    step: '00:15',
                    end: '18:30'
                  }"
                >
                </el-time-select>
                <el-time-select
                  style="margin-left: 15px"
                  placeholder="结束时间"
                  v-model="time5"
                  :picker-options="{
                    start: '08:30',
                    step: '00:15',
                    end: '18:30',
                    minTime: startTime
                  }"
                >
                </el-time-select>
              </el-form-item>
              <el-form-item :required="true" label="任意时间范围" class="full">
                <el-time-picker
                  is-range
                  v-model="time6"
                  range-separator="至"
                  start-placeholder="开始时间"
                  end-placeholder="结束时间"
                  placeholder="选择时间范围"
                >
                </el-time-picker>
                <el-time-picker
                  style="margin-left: 15px"
                  is-range
                  arrow-control
                  v-model="time7"
                  range-separator="至"
                  start-placeholder="开始时间"
                  end-placeholder="结束时间"
                  placeholder="选择时间范围"
                >
                </el-time-picker>
              </el-form-item>
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">日期选择器</div>
                </div>
              </div>
              <el-form-item :required="true" label="默认" class="full">
                <el-date-picker v-model="date1" type="date" placeholder="选择日期">
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="带快捷" class="full">
                <el-date-picker
                  v-model="date2"
                  align="right"
                  type="date"
                  placeholder="选择日期"
                  :picker-options="pickerOptions1"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="其他日期单位（周）" class="full">
                <el-date-picker
                  v-model="date3"
                  type="week"
                  format="yyyy 第 WW 周"
                  placeholder="选择周"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="其他日期单位（年）" class="full">
                <el-date-picker v-model="date4" type="month" placeholder="选择月"> </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="其他日期单位（月）" class="full">
                <el-date-picker v-model="date5" type="year" placeholder="选择年"> </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="多个日期（月）" class="full">
                <el-date-picker type="dates" v-model="date6" placeholder="选择一个或多个日期">
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="选择日期范围" class="full">
                <el-date-picker
                  v-model="date7"
                  style="width: 400px"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="选择日期范围（带快捷）" class="full">
                <el-date-picker
                  v-model="date8"
                  style="width: 400px"
                  type="daterange"
                  align="right"
                  unlink-panels
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  :picker-options="pickerOptions2"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="选择月份范围" class="full">
                <el-date-picker
                  v-model="date9"
                  style="width: 400px"
                  type="monthrange"
                  range-separator="至"
                  start-placeholder="开始月份"
                  end-placeholder="结束月份"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="选择月份范围（带快捷）" class="full">
                <el-date-picker
                  v-model="date10"
                  style="width: 400px"
                  type="monthrange"
                  align="right"
                  unlink-panels
                  range-separator="至"
                  start-placeholder="开始月份"
                  end-placeholder="结束月份"
                  :picker-options="pickerOptions3"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="默认显示日期" class="full">
                <el-date-picker
                  v-model="date11"
                  style="width: 400px"
                  type="daterange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="默认为Date对象值" class="full">
                <el-date-picker
                  v-model="date12"
                  type="date"
                  placeholder="选择日期"
                  format="yyyy 年 MM 月 dd 日"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="使用value-format" class="full">
                <el-date-picker
                  v-model="date13"
                  type="date"
                  placeholder="选择日期"
                  format="yyyy 年 MM 月 dd 日"
                  value-format="yyyy-MM-dd"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="时间戳值" class="full">
                <el-date-picker
                  v-model="date14"
                  type="date"
                  placeholder="选择日期"
                  format="yyyy 年 MM 月 dd 日"
                  value-format="timestamp"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="组件值" class="full">
                <el-date-picker
                  v-model="date15"
                  type="daterange"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  :default-time="['00:00:00', '23:59:59']"
                >
                </el-date-picker>
              </el-form-item>
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">日期时间选择器</div>
                </div>
              </div>
              <el-form-item :required="true" label="日期和时间点" class="full">
                <el-date-picker v-model="datetime1" type="datetime" placeholder="选择日期时间">
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="带快捷选项" class="full">
                <el-date-picker
                  v-model="datetime2"
                  type="datetime"
                  placeholder="选择日期时间"
                  align="right"
                  :picker-options="pickerOptions4"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="设置默认时间" class="full">
                <el-date-picker
                  v-model="datetime3"
                  type="datetime"
                  placeholder="选择日期时间"
                  default-time="12:00:00"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="日期时间范围" class="full">
                <el-date-picker
                  v-model="datetime4"
                  type="datetimerange"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="带快捷日期时间范围" class="full">
                <el-date-picker
                  v-model="datetime5"
                  type="datetimerange"
                  :picker-options="pickerOptions5"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  align="right"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="默认的起始时刻" class="full">
                <el-date-picker
                  v-model="datetime6"
                  type="datetimerange"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  :default-time="['12:00:00']"
                >
                </el-date-picker>
              </el-form-item>
              <el-form-item :required="true" label="默认起始和结束时刻" class="full">
                <el-date-picker
                  v-model="datetime7"
                  type="datetimerange"
                  align="right"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  :default-time="['12:00:00', '08:00:00']"
                >
                </el-date-picker>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>

<script>
export default {
  data() {
    return {
      time1: '',
      time2: '',
      time3: '',
      time4: '',
      time5: '',
      time6: [new Date(2016, 9, 10, 8, 40), new Date(2016, 9, 10, 9, 40)],
      time7: [new Date(2016, 9, 10, 8, 40), new Date(2016, 9, 10, 9, 40)],
      date1: '',
      date2: '',
      date3: '',
      date4: '',
      date5: '',
      date6: '',
      date7: '',
      date8: '',
      date9: '',
      date10: '',
      date11: '',
      date12: '',
      date13: '',
      date14: '',
      date15: '',
      datetime1: '',
      datetime2: '',
      datetime3: '',
      datetime4: '',
      datetime5: '',
      datetime6: '',
      datetime7: '',
      startTime: '',
      endTime: '',
      pickerOptions1: {
        disabledDate(time) {
          return time.getTime() > Date.now()
        },
        shortcuts: [
          {
            text: '今天',
            onClick(picker) {
              picker.$emit('pick', new Date())
            }
          },
          {
            text: '昨天',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24)
              picker.$emit('pick', date)
            }
          },
          {
            text: '一周前',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', date)
            }
          }
        ]
      },
      pickerOptions2: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      pickerOptions3: {
        shortcuts: [
          {
            text: '本月',
            onClick(picker) {
              picker.$emit('pick', [new Date(), new Date()])
            }
          },
          {
            text: '今年至今',
            onClick(picker) {
              const end = new Date()
              const start = new Date(new Date().getFullYear(), 0)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近六个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setMonth(start.getMonth() - 6)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      },
      pickerOptions4: {
        shortcuts: [
          {
            text: '今天',
            onClick(picker) {
              picker.$emit('pick', new Date())
            }
          },
          {
            text: '昨天',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24)
              picker.$emit('pick', date)
            }
          },
          {
            text: '一周前',
            onClick(picker) {
              const date = new Date()
              date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', date)
            }
          }
        ]
      },
      pickerOptions5: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            }
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            }
          }
        ]
      }
    }
  }
}
</script>

<style scoped>
.form-center-wrapper {
  width: 930px;
}
</style>
