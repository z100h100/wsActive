<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">创建工单</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">计数器组件</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">计数器</div>
                </div>
              </div>
              <el-form-item :required="true" label="计数器" class="full">
                <el-input-number
                  v-model="num1"
                  size="small"
                  @change="handleChange"
                  :min="1"
                  :max="10"
                  label="描述文字"
                ></el-input-number>
              </el-form-item>
              <el-form-item :required="true" label="计数器禁用状态" class="full">
                <el-input-number v-model="num2" size="small" :sdisabled="true"></el-input-number>
              </el-form-item>
              <el-form-item :required="true" label="步数" class="full">
                <el-input-number v-model="num3" size="small" :step="2"></el-input-number>
              </el-form-item>
              <el-form-item :required="true" label="严格步数" class="full">
                <el-input-number
                  v-model="num4"
                  size="small"
                  :step="2"
                  step-strictly
                ></el-input-number>
              </el-form-item>
              <el-form-item :required="true" label="精度" class="full">
                <el-input-number
                  v-model="num5"
                  size="small"
                  :precision="2"
                  :step="0.1"
                  :max="10"
                ></el-input-number>
              </el-form-item>
              <el-form-item :required="true" label="按钮位置" class="full">
                <el-input-number
                  v-model="num6"
                  size="small"
                  controls-position="right"
                  @change="handleChange"
                  :min="1"
                  :max="10"
                ></el-input-number>
              </el-form-item>
              <el-form-item :required="true" label="按钮位置禁用" class="full">
                <el-input-number
                  v-model="num7"
                  size="small"
                  disabled
                  controls-position="right"
                  @change="handleChange"
                  :min="1"
                  :max="10"
                ></el-input-number>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>
<script>
export default {
  data() {
    return {
      num1: 1,
      num2: 1,
      num3: 1,
      num4: 1,
      num5: 1,
      num6: 1,
      num7: 1
    }
  },
  mounted() {}
}
</script>
