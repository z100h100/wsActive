<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">新建集群</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">基础信息维护</div>
            <el-form-item :required="true" label="集群名称" class="full">
              <el-input
                v-model="clusterName"
                placeholder="仅支持数字、小写字母、下划线、中划线，少于50字"
              />
            </el-form-item>
            <el-form-item :required="true" label="CA" class="full">
              <el-radio v-model="ca" label="1">使用预置CA</el-radio>
              <el-radio v-model="ca" label="2">上传新CA</el-radio>
              <el-popover placement="right" width="288" trigger="hover">
                <div class="ca-content">
                  <p>使用预制CA</p>
                  <span>海豚部署平台自带的CA证书，当***情况下使用预制CA。</span>
                  <p>上传新CA</p>
                  <span>海豚部署平台自带的CA证书，当***情况下使用新CA。</span>
                </div>
                <i
                  slot="reference"
                  class="iconfont icon-shuoming"
                  style="color:#C3C7CE;font-size: 16px"
                ></i>
              </el-popover>
            </el-form-item>
            <el-form-item>
              <el-button>取消</el-button>
              <el-button type="primary" @click="showDialog">下一步</el-button>
            </el-form-item>
          </div>
        </el-form>
      </template>
    </list-panel>
    <el-dialog
      custom-class="notice-dialog"
      :visible.sync="visible"
      width="600px"
      :modal="false"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      title="新建集群-须知"
    >
      <div class="content">
        <div class="tip">
          <span>提示：为了节省您的时间，请确认一下您是否已经获取以下信息</span>
        </div>
        <div class="notice-list">
          <div class="notice-item" v-for="(notice, index) in noticeList">
            <div>
              <div class="order-num">{{ index + 1 }}</div>
              <span class="title">{{ notice.title }}</span>
            </div>
            <div>
              <span class="content">{{ notice.content }}</span>
            </div>
          </div>
        </div>
      </div>
      <template slot="footer">
        <el-checkbox v-model="checked" style="float: left">我已获知以上信息!</el-checkbox>
        <el-button type="primary" :disabled="disabled" @click="visible = false">继续</el-button>
      </template>
    </el-dialog>
  </div>
</template>
<script>
export default {
  data() {
    return {
      clusterName: '',
      ca: '',
      visible: false,
      checked: false,
      disabled: true,
      noticeList: [
        {
          title: '至少已经申请了1台主机',
          content: '有主机信息，包括：主机ip，管理员账密，管理端口，数据分区等信息。'
        },
        {
          title: '至少已经申请了1台主机',
          content: '有主机信息，包括：主机ip，管理员账密，管理端口，数据分区等信息。'
        },
        {
          title: '至少已经申请了1台主机',
          content: '有主机信息，包括：主机ip，管理员账密，管理端口，数据分区等信息。'
        },
        {
          title: '至少已经申请了1台主机',
          content: '有主机信息，包括：主机ip，管理员账密，管理端口，数据分区等信息。'
        },
        {
          title: '至少已经申请了1台主机',
          content: '有主机信息，包括：主机ip，管理员账密，管理端口，数据分区等信息。'
        }
      ]
    }
  },
  mounted() {},
  watch: {
    checked(newValue, oldValue) {
      this.disabled = !newValue
    }
  },
  methods: {
    showDialog() {
      this.visible = true
    }
  }
}
</script>

<style lang="scss">
.notice-dialog {
  .content {
    .tip {
      height: 40px;
      line-height: 40px;
      background: #ecf9ff;
      border-radius: 2px;
      border-left: 3px solid #11b2ff;
      padding-left: 14px;
      span {
        height: 20px;
        line-height: 20px;
        font-family: PingFangSC-Regular;
        font-size: 14px;
        color: #3d424d;
        letter-spacing: -0.17px;
      }
    }
    .notice-list {
      margin: 24px 0 15px 0;
      .notice-item {
        margin-top: 20px;
        .order-num {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          height: 22px;
          width: 22px;
          margin-left: 40px;
          border-radius: 11px;
          background: #f2f4f9;
          color: #3d424d;
          font-size: 16px;
          font-weight: 600;
        }
        .title {
          margin-left: 15px;
          font-family: PingFangSC-Medium;
          font-size: 15px;
          color: #3d424d;
          letter-spacing: 0;
        }
        .content {
          margin-left: 77px;
          font-family: PingFangSC-Regular;
          font-size: 13px;
          color: #9097a4;
          letter-spacing: 0;
          line-height: 24px;
        }
      }
    }
  }
  .el-dialog__body {
    padding: 20px 30px !important;
  }
  .el-dialog__footer {
    justify-content: space-between;
  }
}
</style>
<style lang="scss" scoped>
.ca-content {
  margin: 0 8px;
  p {
    font-family: PingFangSC-Medium;
    font-size: 13px;
    color: #25282f;
    letter-spacing: 0;
    line-height: 24px;
    margin: 5px 0;
  }
  span {
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #494f5c;
    letter-spacing: 0;
    line-height: 24px;
  }
}
</style>
