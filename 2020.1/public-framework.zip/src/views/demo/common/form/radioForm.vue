<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">创建工单</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">单选框组件</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">单选框</div>
                </div>
              </div>
              <el-form-item :required="true" label="单选框" class="full">
                <el-radio v-model="radio" label="1">备选项</el-radio>
                <el-radio v-model="radio" label="2">备选项</el-radio>
              </el-form-item>
              <el-form-item :required="true" label="单选框" class="full">
                <el-radio disabled v-model="radio1" label="禁用">备选项</el-radio>
                <el-radio disabled v-model="radio1" label="选中且禁用">备选项</el-radio>
              </el-form-item>
              <el-form-item :required="true" label="单选框禁用状态" class="full">
                <el-radio v-model="radio2" label="1" border size="small">备选项1</el-radio>
                <el-radio v-model="radio2" label="2" border size="small">备选项2</el-radio>
              </el-form-item>
              <el-form-item :required="true" label="带有边框" class="full">
                <el-radio-group v-model="radio3" disabled>
                  <el-radio label="1" border size="small">备选项1</el-radio>
                  <el-radio label="2" border size="small">备选项2</el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item :required="true" label="按钮样式" class="full">
                <el-radio-group v-model="radio4" size="small">
                  <el-radio-button label="上海"></el-radio-button>
                  <el-radio-button label="北京"></el-radio-button>
                  <el-radio-button label="广州"></el-radio-button>
                  <el-radio-button label="深圳"></el-radio-button>
                </el-radio-group>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>
<script>
export default {
  data() {
    return {
      radio: '1',
      radio1: '选中且禁用',
      radio2: '1',
      radio3: '1',
      radio4: '上海'
    }
  },
  mounted() {}
}
</script>
