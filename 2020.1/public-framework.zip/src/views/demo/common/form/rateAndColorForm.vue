<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">创建工单</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">评分/颜色选择器组件</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">评分</div>
                </div>
              </div>
              <el-form-item :required="true" label="默认不区分颜色" class="full">
                <el-rate v-model="rate1"></el-rate>
              </el-form-item>
              <el-form-item label="区分颜色" class="full">
                <el-rate v-model="rate2" :colors="colors"> </el-rate>
              </el-form-item>
              <el-form-item :required="true" label="辅助文字" class="full">
                <el-rate v-model="rate3" show-text> </el-rate>
              </el-form-item>
              <el-form-item :required="true" label="其他ICON" class="full">
                <el-rate
                  v-model="rate4"
                  :icon-classes="iconClasses"
                  void-icon-class="el-icon-cloudy"
                  :colors="['#99A9BF', '#F7BA2A', '#FF9900']"
                >
                </el-rate>
              </el-form-item>
              <el-form-item :required="true" label="只读" class="full">
                <el-rate
                  v-model="rate5"
                  disabled
                  show-score
                  text-color="#ff9900"
                  score-template="{value}"
                >
                </el-rate>
              </el-form-item>
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">颜色选择器组件</div>
                </div>
              </div>
              <el-form-item label="有默认值" class="full">
                <el-color-picker v-model="color1"></el-color-picker>
              </el-form-item>
              <el-form-item label="有默认值" class="full">
                <el-color-picker v-model="color2"></el-color-picker>
              </el-form-item>
              <el-form-item label="选择透明度" class="full">
                <el-color-picker v-model="color3"></el-color-picker>
              </el-form-item>
              <el-form-item label="预定义颜色" class="full">
                <el-color-picker v-model="color4" show-alpha :predefine="predefineColors">
                </el-color-picker>
              </el-form-item>
              <el-form-item label="不同尺寸" class="full">
                <el-color-picker v-model="color5"></el-color-picker>
                <el-color-picker
                  v-model="color6"
                  size="medium"
                  style="margin-left: 16px"
                ></el-color-picker>
                <el-color-picker
                  v-model="color7"
                  size="small"
                  style="margin-left: 16px"
                ></el-color-picker>
                <el-color-picker
                  v-model="color8"
                  size="mini"
                  style="margin-left: 16px"
                ></el-color-picker>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>

<script>
export default {
  data() {
    return {
      rate1: 4,
      rate2: 4,
      rate3: 4,
      rate4: 4,
      rate5: 3.7,
      colors: ['#99A9BF', '#F7BA2A', '#FF9900'], // 等同于 { 2: '#99A9BF', 4: { value: '#F7BA2A', excluded: true }, 5: '#FF9900' }
      iconClasses: ['el-icon-sunrise', 'el-icon-sunset', 'el-icon-sunny'], // 等同于 { 2: 'icon-rate-face-1', 4: { value: 'icon-rate-face-2', excluded: true }, 5: 'icon-rate-face-3' }
      color1: '#409EFF',
      color2: null,
      color3: 'rgba(19, 206, 102, 0.8)',
      color4: 'rgba(255, 69, 0, 0.68)',
      color5: '#409EFF',
      color6: '#409EFF',
      color7: '#409EFF',
      color8: '#409EFF',
      predefineColors: [
        '#ff4500',
        '#ff8c00',
        '#ffd700',
        '#90ee90',
        '#00ced1',
        '#1e90ff',
        '#c71585',
        'rgba(255, 69, 0, 0.68)',
        'rgb(255, 120, 0)',
        'hsv(51, 100, 98)',
        'hsva(120, 40, 94, 0.5)',
        'hsl(181, 100%, 37%)',
        'hsla(209, 100%, 56%, 0.73)',
        '#c7158577'
      ]
    }
  }
}
</script>

<style lang="scss">
.el-rate {
  line-height: 50px;
  height: 40px;
  .el-rate__text {
    display: inline-block;
    height: 50px;
    line-height: 40px;
    margin-left: 10px;
    font-family: PingFangSC-Regular;
    font-size: 13px;
    color: #494f5c;
    letter-spacing: 0;
    text-align: right;
  }
}

.icon-rate-face-off:before {
  content: '\e900';
}
</style>
