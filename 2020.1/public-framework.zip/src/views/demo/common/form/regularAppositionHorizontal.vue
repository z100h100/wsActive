<template>
  <el-form label-width="100px">
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">新增设备</span>
      </div>
    </div>
    <div class="apposition-card-list horizontal">
      <div class="cart-item">
        <div class="cart-tit">设备配置</div>
        <div class="cart-con">
          <el-form-item :required="true" class="tip-wrap" label="采集站编号">
            <el-input />
            <el-tooltip placement="top" popper-class="custom-tooltip">
              <div slot="content">
                <div class="tit">采集站编号</div>
                <div class="con">
                  采集站编号是用于区别采集站，编号不一样，存储位置不同，如不知道具体编号，请联系
                  <a href="javascript:;">采集站管理员</a> 确认，或查看<a href="javascript:;"
                    >wiki文档</a
                  >
                </div>
              </div>
              <i class="iconfont icon-wenhao"></i>
            </el-tooltip>
          </el-form-item>
          <el-form-item label="入网ID" :required="true">
            <el-input />
          </el-form-item>
          <el-form-item :required="true" label="通道">
            <el-switch v-model="active" active-color="#1FB6FF" inactive-color="#DCDFE6">
            </el-switch>
          </el-form-item>
          <el-form-item :required="true" label="日期">
            <el-date-picker
              v-model="date"
              type="datetimerange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
            >
            </el-date-picker>
          </el-form-item>
          <el-form-item :required="true" label="标签">
            <el-select v-model="label" style="width:100%;" multiple size="mini">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item :required="true" label="关键字">
            <el-select v-model="label2" multiple collapse-tags style="width:100%;">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
        </div>
      </div>
      <div class="cart-item">
        <div class="cart-tit">网络配置</div>
        <div class="cart-con">
          <el-form-item :required="true" label="注册用户名">
            <el-input />
          </el-form-item>
          <el-form-item label="重点标签" :required="true">
            <el-radio-group v-model="radio">
              <el-radio :label="0">是</el-radio>
              <el-radio :label="1">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="通道" :required="true">
            <el-switch v-model="active1" active-color="#1FB6FF" inactive-color="#DCDFE6">
            </el-switch>
          </el-form-item>
          <el-form-item :required="true" label="身份证号">
            <el-input />
          </el-form-item>
        </div>
      </div>
    </div>
    <form-button-area>
      <el-button>取消</el-button>
      <el-button type="primary">确认</el-button>
    </form-button-area>
  </el-form>
</template>
<script>
export default {
  data() {
    return {
      active: false,
      active1: true,
      radio: 0,
      date: null,
      label: '',
      label2: '',
      options: [
        {
          value: '选项1',
          label: '黄金糕'
        },
        {
          value: '选项2',
          label: '双皮奶'
        },
        {
          value: '选项3',
          label: '蚵仔煎'
        },
        {
          value: '选项4',
          label: '龙须面'
        },
        {
          value: '选项5',
          label: '北京烤鸭'
        }
      ]
    }
  }
}
</script>
<style lang="scss" scoped></style>
