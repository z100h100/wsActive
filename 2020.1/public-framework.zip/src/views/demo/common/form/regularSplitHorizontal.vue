<template>
  <el-form label-width="100px">
    <div class="card-list split horizontal">
      <div class="cart-item">
        <div class="cart-tit">设备配置</div>
        <div class="cart-con">
          <el-form-item :required="true" label="采集站编号" class="tip-wrap">
            <el-input />
            <el-tooltip placement="top" popper-class="custom-tooltip">
              <div slot="content">
                <div class="tit">采集站编号</div>
                <div class="con">
                  采集站编号是用于区别采集站，编号不一样，存储位置不同，如不知道具体编号，请联系
                  <a href="javascript:;">采集站管理员</a> 确认，或查看<a href="javascript:;"
                    >wiki文档</a
                  >
                </div>
              </div>
              <i class="iconfont icon-wenhao"></i>
            </el-tooltip>
          </el-form-item>
          <el-form-item :required="true" label="入网ID">
            <el-input />
          </el-form-item>
          <el-form-item :required="true" label="通道">
            <el-switch v-model="active" active-color="#1FB6FF" inactive-color="#DCDFE6">
            </el-switch>
          </el-form-item>
          <el-form-item :required="true" label="设备名称">
            <el-input />
          </el-form-item>
        </div>
      </div>
      <div class="cart-item">
        <div class="cart-tit">网络配置</div>
        <div class="cart-con">
          <el-form-item :required="true" label="注册用户名">
            <el-input />
          </el-form-item>
          <el-form-item :required="true" label="重点标签">
            <el-radio-group v-model="radio">
              <el-radio :label="0">是</el-radio>
              <el-radio :label="1">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :required="true" label="通道">
            <el-switch v-model="active1" active-color="#1FB6FF" inactive-color="#DCDFE6">
            </el-switch>
          </el-form-item>
          <el-form-item :required="true" label="身份证号">
            <el-input />
          </el-form-item>
        </div>
      </div>
    </div>
    <form-button-area>
      <el-button>取消</el-button>
      <el-button type="primary">确认</el-button>
    </form-button-area>
  </el-form>
</template>
<script>
export default {
  data() {
    return {
      active: false,
      active1: true,
      radio: 0
    }
  }
}
</script>
<style lang="scss" scoped></style>
