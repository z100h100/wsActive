<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">新增设备</span>
      </div>
      <div class="right">
        <custom-progress :steps="steps" :currentStep="currentStep" />
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-steps class="stepsWrap" :active="2" align-center>
          <el-step title="发布方式" icon="el-icon-edit"></el-step>
          <el-step title="创建镜像" icon="el-icon-edit"></el-step>
          <el-step title="项目配置" icon="el-icon-edit"></el-step>
          <el-step title="发布申请" icon="el-icon-edit"></el-step>
        </el-steps>
        <el-form label-width="100px">
          <div class="form-center-wrapper horizontal">
            <div class="tit">创建工单模板</div>
            <div class="con">
              <el-form-item :required="true" label="采集站编号">
                <el-input />
              </el-form-item>
              <el-form-item label="入网ID" :required="true">
                <el-input />
              </el-form-item>
              <el-form-item :required="true" label="通道">
                <el-switch v-model="active" active-color="#1FB6FF" inactive-color="#DCDFE6">
                </el-switch>
              </el-form-item>
              <el-form-item :required="true" label="设备名称">
                <el-input />
              </el-form-item>
              <el-form-item :required="true" label="标签">
                <el-select v-model="label" style="width:100%;" multiple>
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
              <el-form-item :required="true" label="关键字">
                <el-select v-model="label2" multiple collapse-tags style="width:100%;">
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-form-item>
            </div>
            <div class="footer">
              <el-button>取消</el-button>
              <el-button type="primary">下一步</el-button>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>
<script>
import CustomProgress from '@/components/Progress/custom'
import { mapActions } from 'vuex'
// import Step from '@/components/Progress'
export default {
  components: {
    'custom-progress': CustomProgress
    // step: Step
  },
  data() {
    return {
      steps: [
        {
          label: '选择工单模板',
          value: '0'
        },
        {
          label: '创建工单模板',
          value: '1'
        },
        {
          label: '创建成功',
          value: '2'
        }
      ],
      currentStep: '1',
      active: false,
      active1: true,
      radio: 0,
      label: '',
      label2: '',
      options: [
        {
          value: '选项1',
          label: '黄金糕'
        },
        {
          value: '选项2',
          label: '双皮奶'
        },
        {
          value: '选项3',
          label: '蚵仔煎'
        },
        {
          value: '选项4',
          label: '龙须面'
        },
        {
          value: '选项5',
          label: '北京烤鸭'
        }
      ]
    }
  },
  mounted() {
    this.setPageTip(
      '专有宿主机DDH是一台虚拟化托管的物理服务器，物理服务器上的资源由您独享，与其他租户在物理级别上隔离。您可以在DDH上创建ECS实例。'
    )
  },
  methods: {
    ...mapActions(['setPageTip'])
  }
}
</script>
<style lang="scss" scoped>
.stepsWrap {
  margin-top: 40px;
  padding: 20px 10%;
}
</style>
