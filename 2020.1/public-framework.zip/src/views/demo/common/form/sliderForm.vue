<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">创建工单</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">滑块组件</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">基础用法</div>
                </div>
              </div>
              <el-form-item :required="true" label="默认" class="full">
                <el-slider v-model="value1"></el-slider>
              </el-form-item>
              <el-form-item :required="true" label="自定义初始值" class="full">
                <el-slider v-model="value2"></el-slider>
              </el-form-item>
              <el-form-item :required="true" label="隐藏 Tooltip" class="full">
                <el-slider v-model="value3" :show-tooltip="false"></el-slider>
              </el-form-item>
              <el-form-item :required="true" label="格式化 Tooltip" class="full">
                <el-slider v-model="value4" :format-tooltip="formatTooltip"></el-slider>
              </el-form-item>
              <el-form-item :required="true" label="禁用" class="full">
                <el-slider v-model="value5" disabled></el-slider>
              </el-form-item>
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">离散值</div>
                </div>
              </div>
              <el-form-item :required="true" label="不显示间断点" class="full">
                <el-slider v-model="value6"></el-slider>
              </el-form-item>
              <el-form-item :required="true" label="显示间断点" class="full">
                <el-slider v-model="value7" :step="10" show-stops></el-slider>
              </el-form-item>
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">带有输入框</div>
                </div>
              </div>
              <el-form-item :required="true" label="带有输入框" class="full">
                <el-slider v-model="value8" show-input></el-slider>
              </el-form-item>
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">范围选择</div>
                </div>
              </div>
              <el-form-item :required="true" label="范围选择" class="full">
                <el-slider v-model="value9" range show-stops :max="10"></el-slider>
              </el-form-item>
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">竖向模式</div>
                </div>
              </div>
              <el-form-item :required="true" label="竖向模式" class="full">
                <el-slider v-model="value10" vertical height="200px"> </el-slider>
              </el-form-item>
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">展示标记</div>
                </div>
              </div>
              <el-form-item :required="true" label="展示标记" class="full">
                <el-slider v-model="value11" range :marks="marks"></el-slider>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>
<script>
export default {
  data() {
    return {
      value1: 0,
      value2: 50,
      value3: 36,
      value4: 48,
      value5: 42,
      value6: 0,
      value7: 0,
      value8: 0,
      value9: [4, 8],
      value10: 30,
      value11: [30, 60],
      marks: {
        0: '0°C',
        8: '8°C',
        37: '37°C',
        50: {
          style: {
            color: '#1989FA'
          },
          label: this.$createElement('strong', '50%')
        }
      }
    }
  },
  mounted() {},
  methods: {
    formatTooltip(val) {
      return val / 100
    }
  }
}
</script>
