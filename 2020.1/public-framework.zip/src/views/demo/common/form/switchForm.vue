<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">创建工单</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">开关组件</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">开关</div>
                </div>
              </div>
              <el-form-item :required="true" label="基本用法" class="full">
                <el-switch v-model="switch1" :active-text="switch1 ? '开启' : '关闭'"> </el-switch>
              </el-form-item>
              <el-form-item :required="true" label="输入框" class="full">
                <el-switch v-model="switch2" active-text="按月付费" inactive-text="按年付费">
                </el-switch>
              </el-form-item>
              <el-form-item :required="true" label="扩展的 value 类型" class="full">
                <el-switch v-model="switch3" active-value="100" inactive-value="0"> </el-switch>
              </el-form-item>
              <el-form-item :required="true" label="开启的禁用状态" class="full">
                <el-switch v-model="switch4" disabled :active-text="switch4 ? '开启' : '关闭'">
                </el-switch>
              </el-form-item>
              <el-form-item :required="true" label="关闭的禁用状态" class="full">
                <el-switch v-model="switch5" disabled :active-text="switch5 ? '开启' : '关闭'">
                </el-switch>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>
<script>
export default {
  data() {
    return {
      switch1: true,
      switch2: true,
      switch3: '100',
      switch4: true,
      switch5: false
    }
  },
  mounted() {}
}
</script>
