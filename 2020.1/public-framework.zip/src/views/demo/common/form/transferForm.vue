<template>
  <div>
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">创建工单</span>
      </div>
    </div>
    <list-panel>
      <template slot="main">
        <el-form label-width="170px" label-suffix="：">
          <div class="form-center-wrapper horizontal">
            <div class="tit">穿梭框组件</div>
            <div class="form-center-wrapper">
              <div class="card-list">
                <div class="cart-item">
                  <div class="cart-tit">Transfer 穿梭框</div>
                </div>
              </div>
              <el-form-item :required="true" label="基础用法" class="full">
                <el-transfer v-model="value" :data="data"></el-transfer>
              </el-form-item>
              <el-form-item :required="true" label="可搜索" class="full">
                <el-transfer
                  filterable
                  :filter-method="filterMethod"
                  filter-placeholder="请输入城市拼音"
                  v-model="value1"
                  :data="data1"
                >
                </el-transfer>
              </el-form-item>
              <el-form-item :required="true" label="可自定义-01" class="full">
                <el-transfer
                  style="text-align: left; display: inline-block"
                  v-model="value2"
                  filterable
                  :left-default-checked="[2, 3]"
                  :right-default-checked="[1]"
                  :render-content="renderFunc"
                  :titles="['Source', 'Target']"
                  :button-texts="['到左边', '到右边']"
                  :format="{
                    noChecked: '${total}',
                    hasChecked: '${checked}/${total}'
                  }"
                  @change="handleChange"
                  :data="data2"
                >
                  <el-button class="transfer-footer" slot="left-footer" size="small"
                    >操作</el-button
                  >
                  <el-button class="transfer-footer" slot="right-footer" size="small"
                    >操作</el-button
                  >
                </el-transfer>
                <div class="tip">使用 render-content 自定义数据项</div>
              </el-form-item>
              <el-form-item :required="true" label="可自定义-02" class="full">
                <el-transfer
                  style="text-align: left; display: inline-block"
                  v-model="value3"
                  filterable
                  :left-default-checked="[2, 3]"
                  :right-default-checked="[1]"
                  :titles="['Source', 'Target']"
                  :button-texts="['到左边', '到右边']"
                  :format="{
                    noChecked: '${total}',
                    hasChecked: '${checked}/${total}'
                  }"
                  @change="handleChange"
                  :data="data3"
                >
                  <span slot-scope="{ option }">{{ option.key }} - {{ option.label }}</span>
                  <el-button class="transfer-footer" slot="left-footer" size="small"
                    >操作</el-button
                  >
                  <el-button class="transfer-footer" slot="right-footer" size="small"
                    >操作</el-button
                  >
                </el-transfer>
                <div class="tip">使用 scoped-slot 自定义数据项</div>
              </el-form-item>
            </div>
          </div>
        </el-form>
      </template>
    </list-panel>
  </div>
</template>

<script>
export default {
  data() {
    const generateData = _ => {
      const data = []
      for (let i = 1; i <= 15; i++) {
        data.push({
          key: i,
          label: `备选项 ${i}`,
          disabled: i % 4 === 0
        })
      }
      return data
    }
    const generateData1 = _ => {
      const data = []
      const cities = ['上海', '北京', '广州', '深圳', '南京', '西安', '成都']
      const pinyin = ['shanghai', 'beijing', 'guangzhou', 'shenzhen', 'nanjing', 'xian', 'chengdu']
      cities.forEach((city, index) => {
        data.push({
          label: city,
          key: index,
          pinyin: pinyin[index]
        })
      })
      return data
    }
    return {
      data: generateData(),
      value: [1, 4],
      data1: generateData1(),
      value1: [],
      data2: generateData(),
      value2: [1],
      data3: generateData(),
      value3: [1],
      filterMethod(query, item) {
        return item.pinyin.indexOf(query) > -1
      },
      renderFunc(h, option) {
        return (
          <span>
            {option.key} - {option.label}
          </span>
        )
      }
    }
  },
  methods: {
    handleChange(value, direction, movedKeys) {
      console.log(value, direction, movedKeys)
    }
  }
}
</script>

<style scoped lang="scss">
.form-center-wrapper {
  width: 930px;
}
.tip {
  font-family: PingFangSC-Regular;
  font-size: 13px;
  color: #9097a4;
  letter-spacing: 0;
}
</style>
