<template>
  <div>
    <advanced-search-panel
      ref="advancedSearch"
      :searchTypeOptions="searchTypeOptions"
      :getList="handleAdSearch"
      :delSearchTags="handleDelSearchTags"
    >
      <template slot="ordinaryOper-area">
        <el-dropdown>
          <el-button type="info">
            {{ $t('common.operateLabel') }}
            <i class="el-icon-caret-bottom el-icon--right"></i>
          </el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>{{ $t('common.add') }}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <el-button type="info" icon="iconfont icon-ic-new"></el-button>
        <el-button-group>
          <el-button type="info" icon="iconfont icon-outport"></el-button>
          <el-button type="info" icon="iconfont icon-ic-loaddown"></el-button>
          <el-button type="info" icon="iconfont icon-ic-setting"></el-button>
        </el-button-group>
      </template>
      <template slot="form-area">
        <el-form-item :label="$t('demo.channelId')">
          <el-input
            v-model="searchCriteria.id"
            @keyup.enter.native="getList()"
            placeholder="请输入通道ID"
          ></el-input>
        </el-form-item>
        <el-form-item label="单位名称">
          <el-input
            v-model="searchCriteria.compoanyName"
            @keyup.enter.native="getList()"
            placeholder="请输入单位名称"
          ></el-input>
        </el-form-item>
        <el-form-item label="姓名">
          <el-input
            v-model="searchCriteria.userName"
            @keyup.enter.native="getList()"
            placeholder="请输入姓名"
          ></el-input>
        </el-form-item>
        <el-form-item label="工号">
          <el-input
            v-model="searchCriteria.cardNumber"
            @keyup.enter.native="getList()"
            placeholder="请输入工号"
          ></el-input>
        </el-form-item>
        <el-form-item label="身份证">
          <el-input
            v-model="searchCriteria.cardNo"
            @keyup.enter.native="getList()"
            placeholder="请输入身份证"
          ></el-input>
        </el-form-item>
      </template>
      <template slot="oper-area">
        <el-button type="primary" icon="iconfont icon-ic-search" @click="getList()">{{
          $t('common.searchButton')
        }}</el-button>
        <el-button @click="reset">{{ $t('common.resetButton') }}</el-button>
      </template>
    </advanced-search-panel>
    <list-panel>
      <!-- main start -->
      <template slot="main">
        <el-table :data="list" highlight-current-row style="width: 100%">
          <el-table-column prop="name" :label="$t('demo.nameLabel')" />
          <el-table-column prop="code" :label="$t('demo.codeLabel')" />
          <el-table-column prop="date" :label="$t('demo.dateLabel')"></el-table-column>
          <el-table-column :label="$t('common.operateLabel')" :width="165">
            <template slot-scope="scope">
              <a class="tableActionStyle" @click="handleStart(scope.row)" href="javascript:;">
                {{ $t('demo.showDetailButton') }}
              </a>
            </template>
          </el-table-column>
        </el-table>
      </template>
      <!-- main end -->
      <!-- pagination start -->
      <template slot="pagination">
        <el-pagination
          background=""
          v-if="paging.total != 0"
          :page-size="paging.pageSize"
          :total="paging.total"
          :current-page="paging.pageNo + 1"
          class="pagination"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </template>
      <!-- pagination end -->
    </list-panel>
    <el-dialog
      title="添加存储"
      :visible.sync="addStoreVisible"
      width="40%"
      :before-close="closeAddStore"
    >
      <el-form
        label-position="top"
        :model="storeForm"
        label-width="80px"
        :inline="true"
        :rules="storeRules"
        ref="storeRules"
      >
        <el-form-item class="full" prop="num">
          <template slot="label">
            <span class="label-tit">采集站编号</span>
            <span class="label-sub-tit">您真实姓名，用于核查信息</span>
          </template>
          <el-input v-model="storeForm.num" />
        </el-form-item>
        <el-form-item style="width:60%;margin-right:50px;" prop="id">
          <template slot="label">
            <span class="label-tit">入网ID</span>
            <span class="label-sub-tit">请核查你的ID</span>
          </template>
          <el-input v-model="storeForm.id" />
        </el-form-item>
        <el-form-item :required="true">
          <template slot="label">
            <span class="label-tit">通道</span>
          </template>
          <el-switch
            v-model="storeForm.active"
            active-color="#1FB6FF"
            inactive-color="#DCDFE6"
          ></el-switch>
        </el-form-item>
        <el-form-item class="full" prop="name">
          <template slot="label">
            <span class="label-tit">设备名称</span>
            <span class="label-sub-tit">设备名称自定义采用数字或者字母</span>
          </template>
          <el-input v-model="storeForm.name" />
        </el-form-item>
        <el-form-item prop="label" class="full">
          <template slot="label">
            <span class="label-tit">标签</span>
            <span class="label-sub-tit">标签便于识别设备</span>
          </template>
          <el-select v-model="storeForm.label" style="width:100%;" multiple>
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :required="true" class="full">
          <template slot="label">
            <span class="label-tit">关键字</span>
            <span class="label-sub-tit">可输入多个关键字</span>
          </template>
          <el-select v-model="storeForm.label2" multiple collapse-tags style="width:100%;">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeAddStore">取消</el-button>
        <el-button type="primary" @click="sbumitStore">确定</el-button>
      </div>
    </el-dialog>
    <!-- 侧边弹窗 -->
    <dialogRight :show="detailShow" :id="historyId" @closeLayer="closeLayer">
      <template slot="content">
        <div class="detail ">
          <p class="tit">满足<span style="color:#fc5753;">所有</span>触发条件：</p>
          <div>
            <p v-for="item in conditionsAll" class="conditionsAll">
              <span>
                <span>{{ item.field ? item.field : '--' }}</span>
                <span>{{
                  conditionsDetailMatch[item.sign] ? conditionsDetailMatch[item.sign] : '--'
                }}</span>
                <!-- input直接显示 -->
                <span
                  v-if="
                    item.code == 'TITLE' ||
                      item.code == 'SUMMARY' ||
                      item.code == 'KEYWORD' ||
                      item.code == 'RECEIPT'
                  "
                  >{{ item.expect }}</span
                >
                <!-- 数组循环显示 -->
                <span v-else-if="item.code == 'TEMPLATE'">{{ item.expect }}</span>
                <span v-else v-for="child in item.expect">{{ child }}</span>
              </span>
              <span v-if="item.match != null">
                <span
                  v-if="
                    item.code == 'TITLE' ||
                      item.code == 'SUMMARY' ||
                      item.code == 'KEYWORD' ||
                      item.code == 'RECEIPT' ||
                      item.code == 'SUBMITER'
                  "
                  >实际：{{ item.value }}</span
                >
                <span v-else-if="item.code == 'TEMPLATE'">实际：{{ item.value.name }}</span>
                <span>
                  <i class="iconfont icon-icon-correct-line green" v-if="item.match"></i>
                  <i class="el-icon-circle-close-outline red" v-else></i>
                </span>
              </span>
            </p>
          </div>
        </div>
        <div class="detail">
          <p class="tit">满足<span style="color:#fc5753;">任意</span>触发条件：</p>
          <div>
            <p v-for="item in conditionsAny" class="conditionsAny">
              <span>
                <span>{{ item.field ? item.field : '--' }}</span>
                <span>{{
                  conditionsDetailMatch[item.sign] ? conditionsDetailMatch[item.sign] : '--'
                }}</span>
                <!-- input直接显示 -->
                <span
                  v-if="
                    item.code == 'TITLE' ||
                      item.code == 'SUMMARY' ||
                      item.code == 'KEYWORD' ||
                      item.code == 'RECEIPT'
                  "
                  >{{ item.expect }}</span
                >
                <span v-else-if="item.code == 'TEMPLATE'">{{ item.expect }}</span>
                <!-- 数组循环显示 -->
                <span v-else v-for="child in item.expect">{{ child }}</span>
              </span>
              <span>
                <!-- <span>实际：{{item.value}}</span> -->
                <span v-if="item.match != null">
                  <span
                    v-if="
                      item.code == 'TITLE' ||
                        item.code == 'SUMMARY' ||
                        item.code == 'KEYWORD' ||
                        item.code == 'RECEIPT' ||
                        item.code == 'SUBMITER'
                    "
                    >实际：{{ item.value }}</span
                  >
                  <span v-else-if="item.code == 'TEMPLATE'">实际：{{ item.value.name }}</span>
                  <span>
                    <i class="iconfont icon-icon-correct-line green" v-if="item.match"></i>
                    <i class="el-icon-circle-close-outline red" v-else></i>
                  </span>
                </span>
              </span>
            </p>
          </div>
        </div>
        <div class="detail actions">
          <p class="tit">执行动作：</p>
          <div>
            <p v-for="item in actions1" class="actions">
              <span>
                <span>{{ actionDetailMatch[item.type] }}</span>
                <span v-if="item.subType != null && item.subType != ''">{{
                  positionMatchArr[item.subType]
                }}</span>
                <span>{{ item.params.value }}</span>
                <span v-for="user in item.userList">{{ user.name }}</span>
                <span>
                  执行
                  <i class="iconfont icon-icon-correct-line green" v-if="item.match"></i>
                  <i class="el-icon-circle-close-outline red" v-else></i>
                </span>
                <span>
                  成功
                  <i class="iconfont icon-icon-correct-line green" v-if="item.match"></i>
                  <i class="el-icon-circle-close-outline red" v-else></i>
                </span>
              </span>
            </p>
          </div>
        </div>
      </template>
    </dialogRight>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import dialogRight from '@/components/Dialog/dialogRight'
import optionSource from '@/views/demo/common/list/advancedListWithDialogRight/options.json'
export default {
  data() {
    return {
      isLoading: false,
      isPageSizeChanging: false,
      addStoreVisible: false,
      options: [
        {
          value: '选项1',
          label: '黄金糕'
        },
        {
          value: '选项2',
          label: '双皮奶'
        },
        {
          value: '选项3',
          label: '蚵仔煎'
        },
        {
          value: '选项4',
          label: '龙须面'
        },
        {
          value: '选项5',
          label: '北京烤鸭'
        }
      ],
      storeForm: {
        label: '',
        label2: '',
        active: true,
        num: '',
        id: '',
        name: ''
      },
      storeRules: {
        num: [{ required: true, message: '请输入活动名称', trigger: 'blur' }],
        name: [{ required: true, message: '请输入设备名称', trigger: 'blur' }],
        label: [{ required: true, message: '请输入标签', trigger: 'blur' }],
        id: [{ required: true, message: '请输入ID', trigger: 'blur' }]
      },
      detailShow: false,
      historyId: '',
      searchTypeOptions: [
        {
          label: this.$t('demo.channelId'),
          value: 'id',
          placeholder: this.$t('demo.channelIdPlaceholder')
        },
        {
          label: this.$t('demo.organization'),
          value: 'compoanyName',
          placeholder: this.$t('demo.organizationPlaceholder')
        },
        {
          label: this.$t('demo.name'),
          value: 'userName',
          placeholder: this.$t('demo.namePlaceholderD')
        },
        {
          label: this.$t('demo.jobNumber'),
          value: 'cardNumber',
          placeholder: this.$t('demo.jobNumberPlaceholder')
        },
        {
          label: this.$t('demo.cardNo'),
          value: 'cardNo',
          placeholder: this.$t('demo.cardNoPlaceholder')
        }
      ],
      actions1: [],
      conditionsAll: [],
      conditionsAny: [],
      actionDetailMatch: optionSource.actionDetailMatch,
      positionMatchArr: optionSource.positionMatchArr,
      conditionsDetailMatch: optionSource.conditionsDetailMatch
    }
  },

  mounted() {
    this.getList()
  },
  computed: {
    ...mapState({
      list: state => state.demo.list,
      paging: state => state.demo.paging,
      searchCriteria: state => state.demo.searchCriteria
    })
  },
  watch: {
    detailShow: function() {
      if (this.detailShow) {
        document.documentElement.style.overflowY = 'hidden'
      } else {
        document.documentElement.style.overflowY = 'scroll'
      }
    }
  },
  components: {
    dialogRight
  },
  methods: {
    ...mapActions(['getDemoList', 'resetSearchCriteria', 'get_triggerHistoryDetail']),
    handleAdSearch(ordinarySearch) {
      const { searchCriteria } = this
      let params = {
        ...searchCriteria,
        pageNo: 0,
        pageSize: 10,
        [ordinarySearch.searchType]: ordinarySearch.searchinput
      }
      this.getDemoList(params).then(() => {
        ordinarySearch.searchinput && this.setOrdSearchTags(ordinarySearch)
      })
    },
    getList(pageSize = 10, pageNo = 0) {
      const { searchCriteria } = this
      let params = {
        ...searchCriteria,
        pageNo,
        pageSize
      }
      this.getDemoList(params).then(() => {
        this.$nextTick(() => {
          this.setAdSearchTags()
        })
      })
    },
    setAdSearchTags() {
      const { searchCriteria, searchTypeOptions } = this
      const tags = []
      Object.keys(searchCriteria).forEach(key => {
        const searchType = searchTypeOptions.find(item => item.value === key)
        if (searchType) {
          tags.push({
            value: key,
            content: searchCriteria[key],
            label: searchType.label
          })
        }
      })
      this.$refs.advancedSearch.updateSearchTags(tags)
    },
    setOrdSearchTags(ordinarySearch) {
      let value = ordinarySearch.searchType
      let content = ordinarySearch.searchinput
      let label = this.searchTypeOptions.find(v => v.value === value).label
      this.$refs.advancedSearch.updateSearchTags([{ value, content, label }])
    },
    handleDelSearchTags(tags) {
      const { searchCriteria } = this
      const tagParams = {}
      tags.forEach(tag => {
        tagParams[tag.value] = ''
      })
      let params = {
        ...searchCriteria,
        pageNo: 0,
        pageSize: 10,
        ...tagParams
      }
      this.getDemoList(params)
    },
    reset() {
      this.resetSearchCriteria()
      this.$refs.advancedSearch.clearSearchTags()
      this.getList()
    },
    handleSizeChange(pageSize) {
      this.isPageSizeChanging = true
      this.getList(pageSize)
    },
    handlePageChange(pageNo) {
      const { paging, isPageSizeChanging } = this
      if (!isPageSizeChanging) {
        this.getList(paging.pageSize, pageNo - 1)
      }
    },
    searchTypeChange(val) {
      if (val == 'ID') {
        this.typePlaceholder = '请选择通道号ID精确查找'
      } else {
        this.typePlaceholder = '请选择单位名称精确查找'
      }
      /* switch (val) {
        case 'ID':
          this.typePlaceholder = '请选择通道号ID精确查找'
          break
        case 'name':
          this.typePlaceholder = '请选择单位名称精确查找'
          break
        } */
    },
    addStore() {
      this.addStoreVisible = true
    },
    closeAddStore() {
      this.$refs.storeRules.resetFields()
      this.addStoreVisible = false
    },
    sbumitStore() {
      this.closeAddStore()
    },
    handleStart(row) {
      this.detailShow = true
      this.historyId = row.code
      this.getDetail(row.code)
    },
    closeLayer() {
      this.detailShow = false
    },
    getDetail(id) {
      this.loading = true
      this.get_triggerHistoryDetail(id).then(res => {
        this.loading = false
        console.log(res)
        this.actions = this.actionsDeal(res.result.actions)
        this.conditionsAll = this.conditionsDeal(res.result.conditionsAll)
        this.conditionsAny = this.conditionsDeal(res.result.conditionsAny)
      })
    },
    actionsDeal(data) {
      if (!(data && data.length)) {
        return []
      }
      let newArr = []
      let arr = []
      if (data) {
        newArr = data
        newArr.forEach(item => {
          if (
            item.type == 'CHANGE_RECEIPTER' ||
            item.type == 'ADD_FOLLOWER' ||
            item.type == 'DELETE_FOLLOWER' ||
            item.type == 'NOTICE'
          ) {
            let value = JSON.parse(item.params).value ? JSON.parse(item.params).value : []
            item = {
              type: item.type,
              execute: item.execute,
              success: item.success,
              userIds: [],
              userList: [],
              subType: '',
              deptIds: [],
              expect: [],
              params: { value: '' }
            }
            item.userIds = item.userIds.concat(value.map(item => item.id))
            item.userList = value
            arr.push(item)
          }
          if (
            item.type == 'CHANGE_STATE' ||
            item.type == 'CHANGE_PRIORITY' ||
            item.type == 'CHANGE_TEMPLATE'
          ) {
            if (item.type == 'CHANGE_TEMPLATE') {
              let value = JSON.parse(item.params).value
              item = {
                type: item.type,
                params: { value: value },
                success: item.success,
                execute: item.execute,
                subType: '',
                deptIds: [],
                userIds: []
              }
              arr.push(item)
            } else {
              let value = JSON.parse(item.params).value
              item = {
                type: item.type,
                execute: item.execute,
                success: item.success,
                params: { value: value },
                subType: '',
                deptIds: [],
                userIds: []
              }
              arr.push(item)
            }
          }
          if (
            item.type == 'CLEAR_FOLLOWER' ||
            item.type == 'NOTICE_SUBMITER' ||
            item.type == 'NOTICE_APPROVER' ||
            item.type == 'NOTICE_FOLLOWER' ||
            item.type == 'NOTICE_RECEIPTER'
          ) {
            item = {
              type: item.type,
              execute: item.execute,
              success: item.success,
              subType: '',
              deptIds: [],
              params: { value: '' },
              userIds: []
            }
            arr.push(item)
          }
          if (item.type == 'ADD_TAG' || item.type == 'DELETE_TAG') {
            let value = JSON.parse(item.params).value
            item = {
              type: item.type,
              subType: item.subType,
              success: item.success,
              execute: item.execute,
              params: { value: value },
              deptIds: [],
              userIds: []
            }
            arr.push(item)
          }
        })
      }
      console.log('arr', arr)
      return arr
    },
    conditionsDeal(data) {
      let newArr = []
      if (data) {
        newArr = data
        newArr.forEach(item => {
          if (
            item.code == 'TITLE' ||
            item.code == 'SUMMARY' ||
            item.code == 'KEYWORD' ||
            item.code == 'RECEIPT'
          ) {
            // let a = item.expect
            // item.expect = a
          }
          if (item.code == 'STATE' || item.code == 'EVALUATE' || item.code == 'PRIORITY') {
            item.expect = item.expect ? JSON.parse(item.expect) : []
          }
          if (item.code == 'SUBMITER') {
            let ids = item.expect ? JSON.parse(item.expect) : []
            item.value = ids.length ? ids[0].name : ''
            item.expect = ids.map(item => item.name)

            console.log(item.expect)
          }
          if (item.code == 'TEMPLATE') {
            let ids = item.expect ? JSON.parse(item.expect) : []
            console.log(ids.name)
            item.expect = ids.name
            item.value = item.value ? JSON.parse(item.value) : []
          }
        })
      }
      console.log(newArr)
      return newArr
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
.detail {
  margin-bottom: 28px;
  .tit {
    margin: 0;
    padding: 0;
    padding-bottom: 12px;
    line-height: 20px;
    font-size: 14px;
    border-bottom: 1px #f2f6f9 solid;
    font-weight: 600;
    color: #3d424d;
  }
}
.conditionsAll,
.conditionsAny {
  display: flex;
  border-bottom: 1px #f2f6f9 solid;
  padding: 0;
  color: $base-font-color;
  > span {
    flex: 1;
    padding: 9px 10px;
    &:last-child {
      background: $gray;
    }
    span {
      margin-right: 10px;
      display: inline-block;
      font-size: 12px;
    }
  }
}
.actions {
  > span {
    span {
      margin-right: 10px;
      display: inline-block;
      font-size: 12px;
    }
  }
}
.green {
  color: #21bf70;
}
.red {
  color: #f86463;
}
</style>
