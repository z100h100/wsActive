<template>
  <div class="chart" id="aaa"></div>
</template>

<script>
import chart from 'echarts'
export default {
  name: 'chart',
  props: {
    options: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  data() {
    return {
      myChart: null,
      timer: null
    }
  },
  mounted() {
    this.init()
    window.addEventListener('resize', this.resize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resize)
    if (this.timer) clearTimeout(this.timer)
  },
  methods: {
    init() {
      this.myChart = chart.init(this.$el)
      this.options.grid = {
        left: 60,
        top: '15%',
        right: 40,
        bottom: 50
      }
      // 如果是柱状图或者折线图 带X Y坐标 对坐标进行处理
      if (this.options.xAxis && this.options.yAxis) {
        if (!this.options.legend) this.options.legend = {}
        if (!this.options.xAxis.axisLine) this.options.xAxis.axisLine = {}
        if (!this.options.xAxis.axisLabel) this.options.xAxis.axisLabel = {}
        if (!this.options.yAxis.axisLabel) this.options.yAxis.axisLabel = {}
        if (!this.options.yAxis.axisLine) this.options.yAxis.axisLine = {}
        if (!this.options.yAxis.axisTick) this.options.yAxis.axisTick = {}
        if (!this.options.xAxis.axisTick) this.options.xAxis.axisTick = {}
        this.options.xAxis.axisLabel.color = '#9097A5'
        this.options.yAxis.axisLabel.color = '#9097A5'
        this.options.xAxis.axisLine.show = false
        this.options.yAxis.axisLine.show = false
        this.options.yAxis.axisTick.show = false
        this.options.xAxis.axisTick.lineStyle = { color: '#bac1cf' }
      }
      this.options.legend.bottom = 0
      this.options.color = [
        '#3FA1FE',
        '#74C9E6',
        '#3DCACA',
        '#6CD9B2',
        '#4FCA73',
        '#9DD96C',
        '#FAD343',
        '#E6965C',
        '#F2637B',
        '#546570',
        '#D66BCA'
      ]
      this.myChart.setOption(this.options)
    },
    resize() {
      if (this.timer) clearTimeout(this.timer)
      this.timer = setTimeout(() => {
        this.myChart.resize()
      }, 300)
    }
  }
}
</script>

<style lang="scss" scoped>
.chart {
  width: 100%;
  height: 100%;
  padding: 20px 10px 10px 10px;
}
</style>
