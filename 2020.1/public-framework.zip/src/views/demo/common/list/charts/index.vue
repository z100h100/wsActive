<template>
  <div class="charts">
    <div class="page-tit" style="width: 100%">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <span class="page-tit-txt">图表</span>
      </div>
      <div class="right">
        <el-button icon="el-icon-refresh"></el-button>
      </div>
    </div>
    <div class="chart-item" v-for="(item, i) in options" :key="i" :class="{ right: i % 2 === 0 }">
      <chart :options="item"></chart>
    </div>
  </div>
</template>

<script>
import chart from './chart'
import { options } from './options'
export default {
  name: 'charts',
  components: { chart },
  data() {
    return {
      options
    }
  },
  methods: {}
}
</script>

<style lang="scss" scoped>
div {
  box-sizing: border-box;
}
.charts {
  display: flex;
  flex-wrap: wrap;
  background: #ffffff;
  .page-tit {
    .right {
      .el-button {
        background: #f2f4f9;
        padding: 0px;
        height: 32px;
        line-height: 32px;
        width: 36px;
        font-size: 22px;
        color: #454545;
      }
    }
  }
  .chart-item {
    height: 420px;
    width: 50%;
    border-bottom: 1px solid #e8edf1;
  }
  .right {
    border-right: 1px solid #e8edf1;
  }
}
</style>
