let data = genData(50)
let { bigData, bigDataAxios } = getBigData(100)
const options = [
  {
    title: {
      text: '折线图堆叠'
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: ['邮件营销', '联盟广告', '视频广告', '直接访问', '搜索引擎']
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '邮件营销',
        type: 'line',
        stack: '总量',
        symbol: 'circle',
        data: [120, 132, 101, 134, 90, 230, 210]
      },
      {
        name: '联盟广告',
        type: 'line',
        stack: '总量',
        symbol: 'circle',
        data: [220, 182, 191, 234, 290, 330, 310]
      },
      {
        name: '视频广告',
        type: 'line',
        stack: '总量',
        symbol: 'circle',
        data: [150, 232, 201, 154, 190, 330, 410]
      },
      {
        name: '直接访问',
        type: 'line',
        stack: '总量',
        symbol: 'circle',
        data: [320, 332, 301, 334, 390, 330, 320]
      },
      {
        name: '搜索引擎',
        type: 'line',
        stack: '总量',
        symbol: 'circle',
        data: [820, 932, 901, 934, 1290, 1330, 1320]
      }
    ]
  },
  {
    title: {
      text: '同名数量统计',
      subtext: '纯属虚构'
    },
    tooltip: {
      trigger: 'item',
      formatter: '{b} : {c} ({d}%)'
    },
    legend: {
      type: 'scroll',
      orient: 'vertical',
      right: 10,
      top: 20,
      bottom: 20,
      data: data.legendData,
      selected: data.selected
    },
    series: [
      {
        name: '姓名',
        type: 'pie',
        radius: ['40%', '65%'],
        center: ['40%', '50%'],
        data: data.seriesData,
        label: {
          formatter: '{d}%'
          // formatter: '{b}:{d}%'
        },
        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  },
  {
    title: {
      text: '世界人口总量',
      subtext: '数据来自网络'
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    legend: {
      data: ['2011年', '2012年']
    },
    xAxis: {
      type: 'value',
      boundaryGap: [0, 0.01]
    },
    yAxis: {
      type: 'category',
      data: ['巴西', '印尼', '美国', '印度', '中国', '总计(万)']
    },
    series: [
      {
        name: '2011年',
        type: 'bar',
        data: [18203, 23489, 29034, 104970, 131744, 630230],
        barWidth: '20px'
      }
    ]
  },
  {
    title: {
      text: '世界人口总量',
      subtext: '数据来自网络'
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    legend: {
      data: ['2011年', '2012年', '2013年']
    },
    xAxis: {
      type: 'category',
      data: ['巴西', '印尼', '美国', '印度', '中国', '激活']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '2011年',
        type: 'bar',
        barGap: '120%',
        barWidth: '8px',
        data: [18203, 23489, 29034, 104970, 131744, 130230]
      },
      {
        name: '2012年',
        type: 'bar',
        symbol: 'circle',
        barWidth: '8px',
        data: [29325, 28438, 39000, 22594, 234141, 181807]
      },
      {
        name: '2013年',
        type: 'bar',
        symbol: 'circle',
        barWidth: '8px',
        data: [39325, 38438, 29000, 22594, 234141, 181807]
      }
    ]
  },
  {
    title: {
      text: '世界人口总量',
      subtext: '数据来自网络'
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    legend: {
      data: ['2011年', '2012年', '2013']
    },
    xAxis: {
      type: 'category',
      data: ['巴西', '印尼', '美国', '印度', '中国', '世界人口(万)']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '2011年',
        type: 'bar',
        barWidth: '20px',
        data: [18203, 23489, 29034, 104970, 131744, 630230]
      },
      {
        name: '2012年',
        type: 'line',
        symbol: 'circle',
        data: [29325, 28438, 39000, 22594, 234141, 581807]
      }
    ]
  },
  {
    title: {
      text: '漏斗图',
      subtext: '纯属虚构'
    },
    tooltip: {
      trigger: 'item',
      formatter: '{b}：{d}%'
    },
    legend: {
      data: ['展现', '点击', '访问', '咨询', '订单']
    },
    calculable: true,
    series: [
      {
        name: '漏斗图',
        type: 'funnel',
        left: '10%',
        top: 60,
        bottom: 60,
        width: '80%',
        min: 0,
        max: 100,
        minSize: '0%',
        maxSize: '100%',
        sort: 'descending',
        gap: 2,
        label: {
          show: true,
          position: 'inside',
          // formatter: ['{b|{b}}', '{c|{c}}', '{d|{d}}%'].join('\n'),
          // formatter: ['{b}', '{c}', '{d|{d}%}'].join('\n'),
          formatter: ['{b|{b}：{c}}', '{d|{d}%}'].join('\n'),
          rich: {
            b: {
              height: 20,
              lineHeight: 20,
              color: '#fff',
              textBorderColor: 'none'
            },
            c: {},
            d: {
              width: 57,
              height: 20,
              lineHeight: 20,
              backgroundColor: '#fff',
              color: '#3D424D',
              textBorderColor: 'none'
            }
          }
        },
        labelLine: {
          length: 10,
          lineStyle: {
            width: 1,
            type: 'solid'
          }
        },
        itemStyle: {
          borderColor: '#fff',
          borderWidth: 1
        },
        emphasis: {
          label: {
            fontSize: 12
          }
        },
        data: [
          { value: 60, name: '访问' },
          { value: 40, name: '咨询' },
          { value: 20, name: '订单' },
          { value: 180, name: '点击' },
          { value: 220, name: '展现' }
        ]
      }
    ]
  },
  {
    title: {
      text: '折线图堆叠'
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: ['邮件营销', '联盟广告', '视频广告', '直接访问', '搜索引擎']
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '邮件营销',
        type: 'line',
        stack: '总量',
        symbol: 'circle',
        data: [120, 132, 101, 134, 90, 230, 210]
      }
    ]
  },
  {
    title: {
      text: '折线图堆叠'
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: ['邮件营销', '联盟广告', '视频广告', '直接访问', '搜索引擎']
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '邮件营销',
        type: 'line',
        stack: '总量',
        data: [120, 132, 101, 134, 90, 230, 210],
        symbol: 'none',
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              {
                offset: 0,
                color: '#50CB74' // 0% 处的颜色
              },
              {
                offset: 1,
                color: '#fff' // 100% 处的颜色
              }
            ]
          }
        }
      }
    ]
  },
  {
    title: {
      text: '折线图堆叠'
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: ['邮件营销', '联盟广告', '视频广告', '直接访问', '搜索引擎']
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: bigDataAxios
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '邮件营销',
        type: 'line',
        stack: '总量',
        data: bigData,
        symbol: 'none',
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              {
                offset: 0,
                color: '#3FA1FE' // 0% 处的颜色
              },
              {
                offset: 1,
                color: '#fff' // 100% 处的颜色
              }
            ]
          }
        }
      }
    ]
  }
]
function genData(count) {
  var nameList = [
    '赵',
    '钱',
    '孙',
    '李',
    '周',
    '吴',
    '郑',
    '王',
    '冯',
    '陈',
    '褚',
    '卫',
    '蒋',
    '沈',
    '韩',
    '杨',
    '朱',
    '秦',
    '尤',
    '许',
    '何',
    '吕',
    '施',
    '张',
    '孔',
    '曹',
    '严',
    '华',
    '金',
    '魏',
    '陶',
    '姜',
    '戚',
    '谢',
    '邹',
    '喻',
    '柏',
    '水',
    '窦',
    '章',
    '云',
    '苏',
    '潘',
    '葛',
    '奚',
    '范',
    '彭',
    '郎',
    '鲁',
    '韦',
    '昌',
    '马',
    '苗',
    '凤',
    '花',
    '方',
    '俞',
    '任',
    '袁',
    '柳',
    '酆',
    '鲍',
    '史',
    '唐',
    '费',
    '廉',
    '岑',
    '薛',
    '雷',
    '贺',
    '倪',
    '汤',
    '滕',
    '殷',
    '罗',
    '毕',
    '郝',
    '邬',
    '安',
    '常',
    '乐',
    '于',
    '时',
    '傅',
    '皮',
    '卞',
    '齐',
    '康',
    '伍',
    '余',
    '元',
    '卜',
    '顾',
    '孟',
    '平',
    '黄',
    '和',
    '穆',
    '萧',
    '尹',
    '姚',
    '邵',
    '湛',
    '汪',
    '祁',
    '毛',
    '禹',
    '狄',
    '米',
    '贝',
    '明',
    '臧',
    '计',
    '伏',
    '成',
    '戴',
    '谈',
    '宋',
    '茅',
    '庞',
    '熊',
    '纪',
    '舒',
    '屈',
    '项',
    '祝',
    '董',
    '梁',
    '杜',
    '阮',
    '蓝',
    '闵',
    '席',
    '季',
    '麻',
    '强',
    '贾',
    '路',
    '娄',
    '危'
  ]
  var legendData = []
  var seriesData = []
  var selected = {}
  var name = ''
  for (var i = 0; i < 50; i++) {
    name = Math.random() > 0.65 ? makeWord(4, 1) + '·' + makeWord(3, 0) : makeWord(2, 1)
    legendData.push(name)
    seriesData.push({
      name: name,
      value: Math.round(Math.random() * 100000)
    })
    selected[name] = i < 6
  }

  return {
    legendData: legendData,
    seriesData: seriesData,
    selected: selected
  }

  function makeWord(max, min) {
    var nameLen = Math.ceil(Math.random() * max + min)
    var name = []
    for (var i = 0; i < nameLen; i++) {
      name.push(nameList[Math.round(Math.random() * nameList.length - 1)])
    }
    return name.join('')
  }
}
function getBigData(count) {
  let bigDataAxios = []
  let bigData = []
  for (let i = 1; i < count; i++) {
    bigDataAxios.push(i)
    bigData.push(Math.round(Math.floor(Math.random() * (10000 - 4000 + 1)) + 4000))
  }
  return { bigDataAxios, bigData }
}
export { options }
