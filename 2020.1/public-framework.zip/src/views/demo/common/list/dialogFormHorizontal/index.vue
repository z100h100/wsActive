<template>
  <div>
    <advanced-search-panel
      ref="advancedSearch"
      :searchTypeOptions="searchTypeOptions"
      :getList="handleAdSearch"
      :delSearchTags="handleDelSearchTags"
    >
      <template slot="ordinaryOper-area">
        <el-dropdown>
          <el-button type="info">
            {{ $t('common.operateLabel') }}
            <i class="el-icon-caret-bottom el-icon--right"></i>
          </el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>{{ $t('common.add') }}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <el-button type="info" icon="iconfont icon-ic-new"></el-button>
        <el-button-group>
          <el-button type="info" icon="iconfont icon-outport"></el-button>
          <el-button type="info" icon="iconfont icon-ic-loaddown"></el-button>
          <el-button type="info" icon="iconfont icon-ic-setting"></el-button>
        </el-button-group>
      </template>
      <template slot="form-area">
        <el-form-item :label="$t('demo.channelId')">
          <el-input
            v-model="searchCriteria.id"
            @keyup.enter.native="getList()"
            placeholder="请输入通道ID"
          ></el-input>
        </el-form-item>
        <el-form-item label="单位名称">
          <el-input
            v-model="searchCriteria.compoanyName"
            @keyup.enter.native="getList()"
            placeholder="请输入单位名称"
          ></el-input>
        </el-form-item>
        <el-form-item label="姓名">
          <el-input
            v-model="searchCriteria.userName"
            @keyup.enter.native="getList()"
            placeholder="请输入姓名"
          ></el-input>
        </el-form-item>
        <el-form-item label="工号">
          <el-input
            v-model="searchCriteria.cardNumber"
            @keyup.enter.native="getList()"
            placeholder="请输入工号"
          ></el-input>
        </el-form-item>
        <el-form-item label="身份证">
          <el-input
            v-model="searchCriteria.cardNo"
            @keyup.enter.native="getList()"
            placeholder="请输入身份证"
          ></el-input>
        </el-form-item>
      </template>
      <template slot="oper-area">
        <el-button type="primary" icon="iconfont icon-ic-search" @click="getList()">{{
          $t('common.searchButton')
        }}</el-button>
        <el-button @click="reset">{{ $t('common.resetButton') }}</el-button>
      </template>
    </advanced-search-panel>
    <list-panel>
      <!-- main start -->
      <template slot="main">
        <el-table :data="list" highlight-current-row style="width: 100%">
          <el-table-column prop="name" :label="$t('demo.nameLabel')" />
          <el-table-column prop="code" :label="$t('demo.codeLabel')" />
          <el-table-column prop="date" :label="$t('demo.dateLabel')"></el-table-column>
          <el-table-column :label="$t('common.operateLabel')" :width="165">
            <template slot-scope="scope">
              <a class="tableActionStyle" @click="handleGoDetail(scope.row)" href="javascript:;">
                {{ $t('demo.showDetailButton') }}
              </a>
            </template>
          </el-table-column>
        </el-table>
      </template>
      <!-- main end -->
      <!-- pagination start -->
      <template slot="pagination">
        <el-pagination
          background=""
          v-if="paging.total != 0"
          :page-size="paging.pageSize"
          :total="paging.total"
          :current-page="paging.pageNo + 1"
          class="pagination"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </template>
      <!-- pagination end -->
    </list-panel>
    <el-dialog :title="title" :visible="addStoreVisible" width="40%" :before-close="closeAddStore">
      <el-form
        :model="storeForm"
        label-width="100px"
        @validate="validateChange"
        :rules="rules"
        ref="storeRules"
      >
        <el-form-item prop="num" ref="item" label="采集站编号" class="tip-wrap">
          <validPopover :prop="this.numRules" :message="this.message" :value="storeForm.num">
            <template slot="reference-area">
              <el-input v-model="storeForm.num" ref @input="changeValue" />
            </template>
          </validPopover>
          <el-tooltip placement="right" popper-class="custom-tooltip">
            <div slot="content">
              <div class="tit">采集站编号</div>
              <div class="con">
                采集站编号是用于区别采集站，编号不一样，存储位置不同，如不知道具体编号，请联系
                <a href="javascript:;">采集站管理员</a> 确认，或查看<a href="javascript:;"
                  >wiki文档</a
                >
              </div>
            </div>
            <i class="iconfont icon-wenhao"></i>
          </el-tooltip>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeAddStore">取消</el-button>
        <el-button type="primary" @click="sbumitStore">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import validPopover from '@/components/validPopover'
export default {
  data() {
    var validateRule = (rule, value, callback, source, options) => {
      var errors = []
      let reg2 = /^[a-z0-9_\-]*$/
      let reg3 = /^([a-z0-9]([\s\S]*[a-z0-9])?)?$/
      if (!value) {
        if (rule.required === true) {
        }
      } else {
        if (value.length < 4 || value.length > 64) {
          errors.push('长度为3-64个字符')
        }
        if (!reg3.test(value)) {
          errors.push('只能以小写字母和数字开头和结尾')
        }
        if (!reg2.test(value)) {
          errors.push('仅支持小写字母、数字、连字符( - )和下划线( _ )')
        }
        callback(errors)
      }
    }
    return {
      isLoading: false,
      isPageSizeChanging: false,
      addStoreVisible: false,
      storeForm: {
        label: '',
        label2: '',
        active: true,
        num: '',
        id: '',
        name: ''
      },
      rules: {
        num: [
          { required: true, message: '请输入活动名称', trigger: 'blur' },
          { validator: validateRule, trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入活动名称', trigger: 'blur' },
          { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        label: [{ required: true, message: '请输入标签', trigger: 'blur' }],
        id: [{ required: true, message: '请输入ID', trigger: 'blur' }]
      },
      title: '',
      validatorDes: {},
      numRules: [{ validator: validateRule }],
      message: [
        { msg: '长度为3-64个字符', state: null },
        { msg: '仅支持小写字母、数字、连字符( - )和下划线( _ )', state: null },
        { msg: '只能以小写字母和数字开头和结尾', state: null }
      ],
      searchTypeOptions: [
        {
          label: this.$t('demo.channelId'),
          value: 'id',
          placeholder: this.$t('demo.channelIdPlaceholder')
        },
        {
          label: this.$t('demo.organization'),
          value: 'compoanyName',
          placeholder: this.$t('demo.organizationPlaceholder')
        },
        {
          label: this.$t('demo.name'),
          value: 'userName',
          placeholder: this.$t('demo.namePlaceholderD')
        },
        {
          label: this.$t('demo.jobNumber'),
          value: 'cardNumber',
          placeholder: this.$t('demo.jobNumberPlaceholder')
        },
        {
          label: this.$t('demo.cardNo'),
          value: 'cardNo',
          placeholder: this.$t('demo.cardNoPlaceholder')
        }
      ]
    }
  },
  components: {
    validPopover
  },
  mounted() {
    this.getList()
  },
  computed: {
    ...mapState({
      list: state => state.demo.list,
      paging: state => state.demo.paging,
      searchCriteria: state => state.demo.searchCriteria
    })
  },
  methods: {
    ...mapActions(['getDemoList', 'resetSearchCriteria']),
    handleAdSearch(ordinarySearch) {
      const { searchCriteria } = this
      let params = {
        ...searchCriteria,
        pageNo: 0,
        pageSize: 10,
        [ordinarySearch.searchType]: ordinarySearch.searchinput
      }
      this.getDemoList(params).then(() => {
        ordinarySearch.searchinput && this.setOrdSearchTags(ordinarySearch)
      })
    },
    getList(pageSize = 10, pageNo = 0) {
      const { searchCriteria } = this
      let params = {
        ...searchCriteria,
        pageNo,
        pageSize
      }
      this.getDemoList(params).then(() => {
        this.$nextTick(() => {
          this.setAdSearchTags()
        })
      })
    },
    setAdSearchTags() {
      const { searchCriteria, searchTypeOptions } = this
      const tags = []
      Object.keys(searchCriteria).forEach(key => {
        const searchType = searchTypeOptions.find(item => item.value === key)
        if (searchType) {
          tags.push({
            value: key,
            content: searchCriteria[key],
            label: searchType.label
          })
        }
      })
      this.$refs.advancedSearch.updateSearchTags(tags)
    },
    setOrdSearchTags(ordinarySearch) {
      let value = ordinarySearch.searchType
      let content = ordinarySearch.searchinput
      let label = this.searchTypeOptions.find(v => v.value === value).label
      this.$refs.advancedSearch.updateSearchTags([{ value, content, label }])
    },
    handleDelSearchTags(tags) {
      const { searchCriteria } = this
      const tagParams = {}
      tags.forEach(tag => {
        tagParams[tag.value] = ''
      })
      let params = {
        ...searchCriteria,
        pageNo: 0,
        pageSize: 10,
        ...tagParams
      }
      this.getDemoList(params)
    },
    reset() {
      this.resetSearchCriteria()
      this.$refs.advancedSearch.clearSearchTags()
      this.getList()
    },
    handleSizeChange(pageSize) {
      this.isPageSizeChanging = true
      this.getList(pageSize)
    },
    handlePageChange(pageNo) {
      const { paging, isPageSizeChanging } = this
      if (!isPageSizeChanging) {
        this.getList(paging.pageSize, pageNo - 1)
      }
    },
    handleGoDetail() {
      this.openEditDialog('查看')
    },
    addStore() {
      this.openEditDialog(this.$t('common.add'))
    },
    openEditDialog(value) {
      this.title = value
      this.addStoreVisible = true
    },
    closeAddStore() {
      this.$refs.storeRules.resetFields()
      this.addStoreVisible = false
    },
    sbumitStore() {
      this.$refs.storeRules.validate(valid => {
        if (valid) {
          console.log('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
      // this.closeAddStore()
    },
    validateChange(val, valid, error) {
      console.log(val, valid, error)
      this.validatorDes = {
        key: val,
        validata: valid,
        msg: error
      }
    },
    changeValue(val) {
      // console.log('val=', val)
      // console.log(this.$refs.item)
      // this.$refs.storeRules.validateField(prop)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
</style>
