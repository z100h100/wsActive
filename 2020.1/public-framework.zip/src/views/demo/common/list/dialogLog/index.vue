<template>
  <div>
    <advanced-search-panel
      ref="advancedSearch"
      :searchTypeOptions="searchTypeOptions"
      :getList="handleAdSearch"
      :delSearchTags="handleDelSearchTags"
    >
      <template slot="ordinaryOper-area">
        <el-dropdown>
          <el-button type="info">
            {{ $t('common.operateLabel') }}
            <i class="el-icon-caret-bottom el-icon--right"></i>
          </el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>{{ $t('common.add') }}</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <el-button type="info" icon="iconfont icon-ic-new"></el-button>
        <el-button-group>
          <el-button type="info" icon="iconfont icon-outport"></el-button>
          <el-button type="info" icon="iconfont icon-ic-loaddown"></el-button>
          <el-button type="info" icon="iconfont icon-ic-setting"></el-button>
        </el-button-group>
      </template>
      <template slot="form-area">
        <el-form-item :label="$t('demo.channelId')">
          <el-input
            v-model="searchCriteria.id"
            @keyup.enter.native="getList()"
            placeholder="请输入通道ID"
          ></el-input>
        </el-form-item>
        <el-form-item label="单位名称">
          <el-input
            v-model="searchCriteria.compoanyName"
            @keyup.enter.native="getList()"
            placeholder="请输入单位名称"
          ></el-input>
        </el-form-item>
        <el-form-item label="姓名">
          <el-input
            v-model="searchCriteria.userName"
            @keyup.enter.native="getList()"
            placeholder="请输入姓名"
          ></el-input>
        </el-form-item>
        <el-form-item label="工号">
          <el-input
            v-model="searchCriteria.cardNumber"
            @keyup.enter.native="getList()"
            placeholder="请输入工号"
          ></el-input>
        </el-form-item>
        <el-form-item label="身份证">
          <el-input
            v-model="searchCriteria.cardNo"
            @keyup.enter.native="getList()"
            placeholder="请输入身份证"
          ></el-input>
        </el-form-item>
      </template>
      <template slot="oper-area">
        <el-button type="primary" icon="iconfont icon-ic-search" @click="getList()">{{
          $t('common.searchButton')
        }}</el-button>
        <el-button @click="reset">{{ $t('common.resetButton') }}</el-button>
      </template>
    </advanced-search-panel>
    <list-panel>
      <!-- main start -->
      <template slot="main">
        <el-table :data="list" highlight-current-row style="width: 100%">
          <el-table-column prop="name" :label="$t('demo.nameLabel')" />
          <el-table-column prop="code" :label="$t('demo.codeLabel')" />
          <el-table-column prop="date" :label="$t('demo.dateLabel')"></el-table-column>
          <el-table-column :label="$t('common.operateLabel')" :width="165">
            <template slot-scope="scope">
              <a class="tableActionStyle" @click="handleGoDetail(scope.row)" href="javascript:;">
                {{ $t('demo.showDetailButton') }}
              </a>
            </template>
          </el-table-column>
        </el-table>
      </template>
      <!-- main end -->
      <!-- pagination start -->
      <template slot="pagination">
        <el-pagination
          background=""
          v-if="paging.total != 0"
          :page-size="paging.pageSize"
          :total="paging.total"
          :current-page="paging.pageNo + 1"
          class="pagination"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </template>
      <!-- pagination end -->
    </list-panel>
    <el-dialog
      :title="title"
      :visible.sync="addStoreVisible"
      width="60%"
      class="no-padding"
      :before-close="closeAddStore"
    >
      <div class="log__content">
        <div>
          <span style="color: #000;white-space: pre-line;" v-html="logContent"></span>
        </div>
      </div>
      <!--<div slot="footer" class="dialog-footer">
        <el-button @click="closeAddStore">取消</el-button>
        <el-button type="primary" @click="sbumitStore">确定</el-button>
      </div>-->
    </el-dialog>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'

export default {
  data() {
    return {
      isLoading: false,
      isPageSizeChanging: false,
      addStoreVisible: false,
      logContent: '',
      title: '',
      searchTypeOptions: [
        {
          label: this.$t('demo.channelId'),
          value: 'id',
          placeholder: this.$t('demo.channelIdPlaceholder')
        },
        {
          label: this.$t('demo.organization'),
          value: 'compoanyName',
          placeholder: this.$t('demo.organizationPlaceholder')
        },
        {
          label: this.$t('demo.name'),
          value: 'userName',
          placeholder: this.$t('demo.namePlaceholderD')
        },
        {
          label: this.$t('demo.jobNumber'),
          value: 'cardNumber',
          placeholder: this.$t('demo.jobNumberPlaceholder')
        },
        {
          label: this.$t('demo.cardNo'),
          value: 'cardNo',
          placeholder: this.$t('demo.cardNoPlaceholder')
        }
      ]
    }
  },

  mounted() {
    this.getList()
  },
  computed: {
    ...mapState({
      list: state => state.demo.list,
      paging: state => state.demo.paging,
      searchCriteria: state => state.demo.searchCriteria
    })
  },
  methods: {
    ...mapActions(['getDemoList', 'resetSearchCriteria', 'get_Log']),
    handleAdSearch(ordinarySearch) {
      const { searchCriteria } = this
      let params = {
        ...searchCriteria,
        pageNo: 0,
        pageSize: 10,
        [ordinarySearch.searchType]: ordinarySearch.searchinput
      }
      this.getDemoList(params).then(() => {
        ordinarySearch.searchinput && this.setOrdSearchTags(ordinarySearch)
      })
    },
    getList(pageSize = 10, pageNo = 0) {
      const { searchCriteria } = this
      let params = {
        ...searchCriteria,
        pageNo,
        pageSize
      }
      this.getDemoList(params).then(() => {
        this.$nextTick(() => {
          this.setAdSearchTags()
        })
      })
    },
    setAdSearchTags() {
      const { searchCriteria, searchTypeOptions } = this
      const tags = []
      Object.keys(searchCriteria).forEach(key => {
        const searchType = searchTypeOptions.find(item => item.value === key)
        if (searchType) {
          tags.push({
            value: key,
            content: searchCriteria[key],
            label: searchType.label
          })
        }
      })
      this.$refs.advancedSearch.updateSearchTags(tags)
    },
    setOrdSearchTags(ordinarySearch) {
      let value = ordinarySearch.searchType
      let content = ordinarySearch.searchinput
      let label = this.searchTypeOptions.find(v => v.value === value).label
      this.$refs.advancedSearch.updateSearchTags([{ value, content, label }])
    },
    handleDelSearchTags(tags) {
      const { searchCriteria } = this
      const tagParams = {}
      tags.forEach(tag => {
        tagParams[tag.value] = ''
      })
      let params = {
        ...searchCriteria,
        pageNo: 0,
        pageSize: 10,
        ...tagParams
      }
      this.getDemoList(params)
    },
    reset() {
      this.resetSearchCriteria()
      this.$refs.advancedSearch.clearSearchTags()
      this.getList()
    },
    handleSizeChange(pageSize) {
      this.isPageSizeChanging = true
      this.getList(pageSize)
    },
    handlePageChange(pageNo) {
      const { paging, isPageSizeChanging } = this
      if (!isPageSizeChanging) {
        this.getList(paging.pageSize, pageNo - 1)
      }
    },
    handleGoDetail() {
      this.openEditDialog('查看日志')
      let params = {
        id: '010'
      }
      this.get_Log(params).then(res => {
        this.logContent = res.result.content
      })
    },
    searchTypeChange(val) {
      if (val == 'ID') {
        this.typePlaceholder = '请选择通道号ID精确查找'
      } else {
        this.typePlaceholder = '请选择单位名称精确查找'
      }
      /* switch (val) {
        case 'ID':
          this.typePlaceholder = '请选择通道号ID精确查找'
          break
        case 'name':
          this.typePlaceholder = '请选择单位名称精确查找'
          break
        } */
    },
    getLog() {
      this.openEditDialog('主机日志')
      let params = {
        id: '010'
      }
      this.get_Log(params).then(res => {
        this.logContent = res.result.content
      })
    },
    openEditDialog(value) {
      this.title = value
      this.addStoreVisible = true
    },
    closeAddStore() {
      this.addStoreVisible = false
    },
    sbumitStore() {
      this.closeAddStore()
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
</style>
