<template>
  <!--chart-style-->
  <div :id="echarts" class="tableChart"></div>
</template>

<script>
import echarts from 'echarts'
import { mapGetters } from 'vuex'
/*   */
import { updateChart, setChartData, setYData } from './echartsData.js'

export default {
  name: 'tableCharts',
  data() {
    return {
      chartColor: [
        '16,131,132',
        '166,122,16',
        '162,41,41',
        '33,102,167',
        '12,135,103',
        '101,17,159'
      ],
      charts: null,
      series: {
        name: '',
        type: 'line',
        // barCategoryGap: '20%',
        // yAxisIndex: 0,
        yAxisIndex: 0,
        itemStyle: {
          // color: item.color
        },
        lineStyle: {
          // color: item.color
        },
        areaStyle: {
          // color: item.color,
          // opacity: i >= 2 ? '0' : '0.1' // 第三条数据，没有区域颜色
          opacity: 0 // 第三条数据，没有区域颜色
        },
        // symbol: 'none',
        // symbolSize: 1,
        showSymbol: false,
        smooth: true
      },
      XAxis: {
        type: 'category',
        min: 'dataMin',
        max: 'dataMax',
        splitNumber: 6,
        boundaryGap: true,
        axisLine: {
          lineStyle: {
            color: '#EEF1F2'
          }
        },
        axisLabel: {
          color: '#9097A5',
          showMinLabel: true,
          showMaxLabel: true
          // interval: (index, value) => {},
          // formatter: datas => {
          //   if (!datas) { return }
          //   let date = datas.split(' ')
          //   return `${date[0] ? date[0] : ''}\n${date[1] ? date[1] : ''}`
          // }
        }
      },
      YAxis: {
        minInterval: 1,
        name: '',
        splitLine: {
          // 网格线 y轴对应的是否显示
          show: true,
          lineStyle: {
            color: ['#F3F5FA']
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          // formatter: item.formatter,
          color: '#9097A5'
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: '#DCDFE6'
          }
        },
        nameTextStyle: {
          color: '#9097A5',
          align: 'left'
        },
        nameLocation: 'end'
      },
      chartsObject: {
        title: {
          top: '0',
          left: '0',
          textStyle: {
            fontSize: 14,
            color: '#494F5C'
          },
          text: ''
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'line' // 默认为直线，可选为：'line' | 'shadow'
          },
          backgroundColor: '#fff',
          textStyle: {
            color: '#666',
            fontSize: '12'
          },
          padding: [15, 15],
          // formatter: '{c}%',
          extraCssText: 'box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);',
          position: function(point, params, dom, rect, size) {
            // 提示框位置
            let x = 0 // x坐标位置
            let y = 0 // y坐标位置
            let offect = 10
            // 当前鼠标位置
            let pointX = point[0]
            let pointY = point[1]
            // 提示框大小
            let boxWidth = size.contentSize[0]
            let boxHeight = size.contentSize[1]
            // boxWidth > pointX 说明鼠标左边放不下提示框
            // if (boxWidth > pointX) {
            //   x = 5
            // } else { // 左边放的下
            //   x = pointX - boxWidth
            // }
            x = pointX - boxWidth - offect
            // boxHeight > pointY 说明鼠标上边放不下提示框
            // if (boxHeight > pointY) {
            //   y = 5
            // } else { // 上边放得下
            //   y = pointY - boxHeight
            // }
            y = pointY - boxHeight - offect
            return [x, y]
          }
        },
        legend: {
          bottom: '0',
          icon: 'circle',
          itemGap: 40,
          itemWidth: 10,
          itemHeight: 10,
          data: ['Value', 'Free'],
          textStyle: {
            color: '#494F5C',
            fontSize: 12
          }
        },
        grid: {
          top: '20%',
          left: '50',
          right: '30',
          bottom: '10%',
          containLabel: false
        },
        series: [],
        xAxis: [],
        yAxis: []
        // xAxis: [
        //   {
        //     show: false,
        //     type: 'category',
        //     boundaryGap: false,
        //     axisTick: {
        //       show: false
        //     },
        //     axisLabel: {
        //       show: true,
        //       textStyle: {
        //         color: '#9097A5',
        //         fontWeight: 100,
        //         fontSize: 12
        //       }
        //     },
        //     splitLine: { show: false},
        //     axisLine: {
        //       show: false,
        //       lineStyle: {
        //         color: '#EEF1F2',
        //         width: 1,
        //         type: 'solid'
        //       }
        //     },
        //     data: ['17:00', '21:00', '01:00', '05:00', '09:00', '13:00', '17:00']
        //   }
        // ]
        // yAxis: [],
        // series: []
      }
    }
  },
  props: ['optctions'],
  computed: {
    ...mapGetters(['sidebar']),
    echarts() {
      return 'echarts' + new Date().getTime() + Math.random() * 100000
    }
  },
  watch: {
    optctions: {
      handler(val, oldval) {
        // console.log('watch optctions val=', val)
        this.setOptction()
      },
      deep: true
    },
    sidebar: {
      handler(val, oldval) {
        setTimeout(this.chartsresize, 150)
      },
      deep: true
    }
  },
  mounted() {
    this.charts = echarts.init(document.getElementById(this.echarts))
    window.addEventListener('resize', this.chartsresize, false)
  },
  methods: {
    setOptction() {
      let ops = {}
      // ops.title = true
      // ops.legendOps = this.optctions.legendOps
      // ops.legendHide = this.optctions.legendHide
      // ops.noNeedContainLabel = this.optctions.noNeedContainLabel
      // ops.xAxisHide = this.optctions.xAxisHide
      // ops.yAxisHide = this.optctions.yAxisHide
      // ops.grid = this.optctions.grid
      // ops.title = this.optctions.title
      ops.series = setChartData(
        this.optctions.series,
        this.optctions.chartsType,
        this.optctions.colors
      )
      ops.legend = setYData(this.optctions.series).map(item => item.name)
      // ops.yAxis = this.optctions.yAxis
      // ops.xAxis = this.optctions.xAxis
      // ops.tooltipFormatter = this.optctions.tooltipFormatter
      // ops.tooltipPosition = this.optctions.tooltipPosition
      ops = Object.assign({}, this.optctions, ops)
      updateChart(this.charts, ops)
    },
    chartsresize() {
      if (this.charts) this.charts.resize()
    },
    destroy() {
      this.charts = null
    }
  },
  destroyed() {
    window.removeEventListener('resize', this.chartsresize, false)
    this.destroy()
  }
}
</script>

<style scoped>
.tableChart {
  height: 315px;
  width: 100%;
  position: relative;
}
</style>
