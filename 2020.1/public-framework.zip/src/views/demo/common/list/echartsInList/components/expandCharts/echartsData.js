/* eslint-disable */
import { isEmpty } from '@/utils'

// 基础监控--line处理option中的数据
export function updateChart(myChartLine, option) {
  // console.log('option=', option)
  // cpuChart初始化数据
  if (!myChartLine) return

  // 处理无数据
  function checkData(dom, hasData) {
    let newEl = document.createElement('div')
    newEl.className = 'echarts-empty'
    let con = `<div class="echarts__empty-text"><div class="charts-title">${(option &&
      option.title) ||
      ''}</div> <div class="content">暂无数据</div> </div>`
    newEl.innerHTML = con
    let el = dom._dom.childNodes
    let len = el.length
    let hasEmpty = false
    for (let i = 0; i < len; i++) {
      let item = el[i]
      // console.log('item.classList.contains(\'echarts-empty\')=', item.classList.contains('echarts-empty'))
      if (item.classList.contains('echarts-empty')) {
        hasEmpty = true
        break
      }
    }
    if (hasEmpty && hasData) {
      // console.log('let el=', myChartLine._dom.childNodes[2])
      // console.log('有占位符 有数据', myChartLine._dom)
      // let dom = myChartLine._dom.childNodes
      // myChartLine._dom.removeChild(myChartLine._dom.childNodes[2])
      let emptyDom = myChartLine._dom.getElementsByClassName('echarts-empty')[0]
      myChartLine._dom.removeChild(emptyDom)
    }
    if (!hasEmpty && !hasData) {
      // console.log('没占位符 没数据就')
      myChartLine._dom.appendChild(newEl)
      return false
    }
  }

  if (!option || !option.series.length || !option.xAxis.length) {
    checkData(myChartLine, false)
    return false
  } else {
    tolerateDateFault(option) // 对于数据与时间轴不对应的取最小数组长度截断
    checkData(myChartLine, true)
  }
  // 处理Y轴
  let yAxis = []
  // console.log('option= ', option)
  // console.log('option= ', option.yAxis)
  if (option.yAxis && option.yAxis.length) {
    for (let i = 0; i < option.yAxis.length; i++) {
      const item = option.yAxis[i]
      let yAxisItem = {}
      yAxisItem = {
        show: !option.xAxisHide,
        // min: 'dataMin',
        minInterval: 1,
        name: hackForYname(item.name, item.position),
        splitLine: {
          // 网格线 y轴对应的是否显示
          show: true,
          lineStyle: {
            color: ['#F3F5FA']
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          // formatter: item.formatter,
          color: '#9097A5'
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: '#DCDFE6'
          }
        },
        nameTextStyle: {
          color: '#9097A5',
          // width: '100%'
          align: 'left'
        },
        nameLocation: 'end'
        // boundaryGap: ['20%', '20%']
        // nameLocation: 'center',
        // nameGap: 100
        // nameRotate: 90
      }
      yAxis.push(yAxisItem)
    }
  } else {
    yAxis = []
  }
  // 处理series
  let series = []
  if (option.series && option.series.length) {
    for (let i = 0; i < option.series.length; i++) {
      const item = option.series[i]
      let seriesItem = {}
      seriesItem = {
        name: item.name,
        type: item.type || 'line',
        barWidth: item.barWidth || '',
        // barCategoryGap: '20%',
        // yAxisIndex: 0,
        yAxisIndex: item.yAxisIndex == 'left' ? 0 : 1,
        itemStyle: {
          color: item.color
        },
        lineStyle: {
          color: item.color,
          type: item.borderType || 'solid'
        },
        areaStyle: {
          color: item.color,
          // opacity: i >= 2 ? '0' : '0.1' // 第三条数据，没有区域颜色
          opacity: 0 // 第三条数据，没有区域颜色
        },
        // symbol: 'none',
        // symbolSize: 1,
        showSymbol: false,
        formatter: item.formatter,
        smooth: true,
        data: item.data
      }
      if (item.data.length < 10) {
        seriesItem.showSymbol = true
      } else {
        seriesItem.showSymbol = false
      }
      series.push(seriesItem)
    }
  } else {
    series = []
  }
  // 处理x 轴
  let xAxis = {
    show: !option.xAxisHide,
    type: 'category',
    min: 'dataMin',
    max: 'dataMax',
    splitNumber: 6,
    // interval: (option.xAxis.length / xNum).toFixed(0),
    // interval: 200,
    // type: 'time',
    boundaryGap: true, // 坐标轴两边不留白
    // splitLine: { // 网格线 x轴对应的是否显示
    //     show: true,
    //     lineStyle: {
    //         color: ['#F3F5FA']
    //     }
    // },
    // axisPointer: {
    //   type: 'shadow'
    // },
    axisLine: {
      lineStyle: {
        color: '#EEF1F2'
      }
    },
    // axisTick: {
    //   show: true,
    //   alignWithLabel: true
    // },
    axisLabel: {
      color: '#9097A5',
      showMinLabel: true,
      showMaxLabel: true,
      align: 'center',
      // interval: (index, value) => {},
      formatter: datas => {
        if (!datas) {
          return
        }
        let date = datas.split(' ')
        return `${date[0] ? date[0] : ''}\n${date[1] ? date[1] : ''}`
      }
    },
    data: option.xAxis || []
  }
  if (!isEmpty(option.Xinterval)) {
    xAxis.axisLabel.interval = option.Xinterval
  } else {
    // 设置x轴图例分段
    let xNum = 4 // 分割段数
    let xSplitnum = 0 // 间隔数
    switch (option.step) {
      case 'anHouer':
        // xNum = [4]
        xNum = 4
        break
      case 'threeHouer':
        // xNum = [4, 5]
        xNum = 5
        break
      case 'sixHouer':
        // xNum = [3, 4, 5]
        xNum = 4
        break
      case 'twelveHouer':
        // xNum = [3, 4, 5]
        xNum = 4
        break
      case 'oneday':
        // xNum = [2]
        xNum = 2
        break
      case 'threeDay':
        // xNum = [3, 4, 5]
        xNum = 4
        break
      default:
        // xNum = [4, 5]
        xNum = 4
    }

    if (option.xAxis.length > 10) {
      // 计算正常分段时 每段之间的间隔点数
      let dataLen = option.xAxis.length / xNum
      // 因为x轴 默认显示 最小值和的最大值 所以实际分段点数要减去开始和结束的点数 （dataLen * 2） 还要再减去实际分段的数
      let dataLength = option.xAxis.length - parseInt(dataLen * 2) - (xNum - 2)
      xSplitnum = parseInt(dataLength / (xNum - 2))
      xAxis.axisLabel.interval = Number(xSplitnum)
    }
  }
  // 拼装option
  // console.log('option.grid=', option)
  let setOption = {
    title: {
      text: option.title || '',
      top: (option.titleOpt && option.titleOpt.top) || '0',
      left: '0',
      textStyle: {
        fontSize: 14,
        color: '#494F5C'
      },
      padding: [0, 0, 16, 0]
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: 'line' // 默认为直线，可选为：'line' | 'shadow'
      },
      backgroundColor: '#fff',
      textStyle: {
        color: '#666',
        fontSize: '12'
      },
      padding: [15, 15],
      // formatter: '{c}%',
      extraCssText: 'box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);',
      position:
        option.tooltipPosition ||
        function(point, params, dom, rect, size) {
          // 提示框位置
          let x = 0 // x坐标位置
          let y = 0 // y坐标位置
          // let offect = 10
          // 当前鼠标位置
          let pointX = point[0]
          let pointY = point[1]
          // 提示框大小
          let boxWidth = size.contentSize[0]
          let boxHeight = size.contentSize[1]
          // boxWidth > pointX 说明鼠标左边放不下提示框
          if (boxWidth > pointX) {
            x = 5
          } else {
            // 左边放的下
            x = pointX - boxWidth - 10
          }
          // x = pointX - boxWidth - offect
          // boxHeight > pointY 说明鼠标上边放不下提示框
          if (boxHeight > pointY) {
            y = 5
          } else {
            // 上边放得下
            y = pointY - boxHeight - 10
          }
          // y = pointY - boxHeight - offect
          return [x, y]
        },
      formatter: option.tooltipFormatter || ''
    },
    grid: {
      left: (option.grid && option.grid.left) || '20',
      right: (option.grid && option.grid.right) || '20',
      bottom: (option.grid && option.grid.bottom) || '26',
      top: (option.grid && option.grid.top) || '22%',
      containLabel: !option.noNeedContainLabel
    },
    legend: {
      type: 'scroll',
      // pageButtonPosition: 'end',
      // x: option.legendX || '',
      left: (option.legendOps && option.legendOps.left) || 'center',
      // right: (option.legendOps && option.legendOps.right) || 'center',
      width: (option.legendOps && option.legendOps.left) || 'auto',
      orient: (option.legendOps && option.legendOps.orient) || 'horizontal',
      // height: (option.legendOps && option.legendOps.height) || '10',
      show: !option.legendHide,
      padding: [5, 5],
      icon: 'circle',
      itemGap: (option.legendOps && option.legendOps.itemGap) || 40,
      // top: (option.legendOps && option.legendOps.top) || '0',
      bottom: (option.legendOps && option.legendOps.bottom) || '6',
      itemWidth: 10,
      itemHeight: 10,
      data: option.legend || [],
      formatter: option.legendFormatter || {}
    },
    xAxis: xAxis,
    yAxis: yAxis,
    series: series
  }
  if (option.tooltip) {
    setOption.tooltip = option.tooltip
  }
  // myChartLine.clear()
  console.log('setOption=', setOption)
  myChartLine.setOption(setOption, true)

  function hackForYname(name, position) {
    let len = 0
    for (let i = 0; i < name.length; i++) {
      var c = name.charCodeAt(i)
      // 单字节加1
      if ((c >= 0x0001 && c <= 0x007e) || (c >= 0xff60 && c <= 0xff9f)) {
        len++
      } else {
        len += 2
      }
    }
    if (len > 6) {
      let a = ((len - 6) / 2).toFixed(0)
      let space = ''
      for (let i = 0; i < a; i++) {
        space += '\u3000'
      }
      if (position == 'left') {
        name = space + name
      } else {
        name = name + space
      }
    }
    // console.log('name=', name)
    return name
  }
}

// 基础监控--处理series
export function setChartData(seriesData, type, color) {
  // let opt = Object.assign({}, page)
  // console.log('seriesData', seriesData)
  let series = []
  if (seriesData && !seriesData.length) {
    return series
  } else if (!seriesData) {
    return series
  }
  let colors = color || [
    '#3399FF',
    '#FEB64D',
    '#3DCCA6',
    '#FA816D',
    '#d4ec59',
    '#af79f6',
    '#3399FF',
    '#FEB64D',
    '#3DCCA6',
    '#FA816D',
    '#d4ec59',
    '#af79f6'
  ]
  seriesData.map((item, index) => {
    let seriesItem = []
    seriesItem.color = colors[index]
    seriesItem.name = item.name
    seriesItem.yAxisIndex = item.position || 'left'
    seriesItem.data = item.data
    seriesItem.type = (type && type[index]) || 'line'
    seriesItem.borderType = item.borderType || 'solid'

    if (type && type[index] === 'bar') {
      seriesItem.barMaxWidth = '20'
    }
    series.push(seriesItem)
  })
  return series
}

// 基础监控处理Y轴
export function setYData(seriesData) {
  // console.log(seriesData)
  let yAxis = []
  seriesData = seriesData || []
  seriesData.map(item => {
    let yAxisItem = {
      name: item.name
      // formatter: item.formatter
    }
    yAxis.push(yAxisItem)
  })
  // console.log(yAxis)
  return yAxis
}

// 重构 处理serise
export function setSeries(obj) {
  let defaultOpt = {
    type: ['line'],
    color: ['#3399FF', '#FEB64D', '#3DCCA6', '#FA816D', '#d4ec59', '#af79f6']
  }
  const { data, type, color, del, select } = Object.assign({}, defaultOpt, obj)
  // data serise {}
  // type 图表类型 []
  // color 图表颜色 []
  // del 要删除的数据名称 []
  // select 默认选中的类型 ''
  // console.log('type=', type)
  // console.log('del=', del)
  // console.log('color=', color)
  // console.log('select=', select)
  // console.log('data=', data)
  let baseData = [] // 处理好的源数据
  let series = []
  if (data) {
    data.map((item, index) => {
      // console.log('select==', select)
      let seriesItem = {}
      seriesItem.color = color[index]
      seriesItem.name = item.name
      seriesItem.yAxisIndex = item.position
      seriesItem.data = item.data
      seriesItem.type = (type && type[index]) || 'line'
      if (type && type[index] === 'bar') {
        seriesItem.barMaxWidth = '20'
      }
      baseData.push(seriesItem)

      if (!select && !del) {
        seriesItem.color = color[index]
        seriesItem.name = item.name
        seriesItem.yAxisIndex = item.position
        seriesItem.data = item.data
        seriesItem.type = (type && type[index]) || 'line'
        if (type && type[index] === 'bar') {
          seriesItem.barMaxWidth = '20'
        }
        series.push(seriesItem)
      }
      // console.log('select=', select)
      // console.log('item.name', item.name)
      // console.log('item.name.indexOf(select)=', item.name.indexOf(select))
      if (select && item.name.indexOf(select) >= 0) {
        seriesItem.color = color[index]
        seriesItem.name = item.name
        seriesItem.yAxisIndex = item.position
        seriesItem.data = item.data
        seriesItem.type = (type && type[index]) || 'line'
        if (type && type[index] === 'bar') {
          seriesItem.barMaxWidth = '20'
        }
        series.push(seriesItem)
      }
      if (
        del &&
        del.map(subItem => {
          return item.name.indexOf(subItem)
        }) == -1
      ) {
        seriesItem.color = color[index]
        seriesItem.name = item.name
        seriesItem.yAxisIndex = item.position
        seriesItem.data = item.data
        seriesItem.type = (type && type[index]) || 'line'
        if (type && type[index] === 'bar') {
          seriesItem.barMaxWidth = '20'
        }
        series.push(seriesItem)
      }
    })
  }
  // 如果没有匹配到任何数据 则返回源数据
  if (series.length == 0) {
    series = baseData
  }
  return series
}

// 获取指定serise值
export function getSerieData(obj) {
  let defaultOpt = {
    key: []
  }
  const { data, key } = Object.assign({}, defaultOpt, obj)
  let series = []
  data.map(item => {
    let seriesItem = {}
    if (
      key &&
      key.map(subItem => {
        return item.name.indexOf(subItem)
      }) != -1
    ) {
      seriesItem.name = item.name
      seriesItem.data = item.data[0]
      series.push(seriesItem)
    }
  })
  return series
}

// 获取series type
export function getSeriesType(data) {
  // console.log('data=', data)
  let typeLists = [{ label: '全部', value: '' }]
  data.forEach(item => {
    // console.log('item= ', item)
    // 根据中文名称获取类型
    let name = item.name.split('-')
    if (name.length >= 2) {
      let hasLabel = typeLists.find(subItem => {
        return subItem.label == name[1]
      })
      if (!hasLabel) {
        typeLists.push({ label: name[1], value: name[1] })
      }
    } else {
    }
  })
  return typeLists
}

// dashboard页面仪表盘处理option中数据
export function setgaugeData(targit, res) {
  let optionData = {
    title: {
      text: res.title,
      top: '7%',
      left: 'center',
      color: '#fff',
      textStyle: {
        // fontWeight: 'normal',
        color: '#fff',
        width: '100%'
        // fontSize: 28,
      }
      // subtext: 'CPU已使用'
    },
    tooltip: {
      formatter: '{a}%'
    },
    series: [
      {
        type: 'gauge',
        center: ['50%', '50%'], // 默认全局居中
        radius: '50%',
        axisLine: {
          show: false,
          lineStyle: {
            // 属性lineStyle控制线条样式
            color: res.color,
            width: 24
          }
        },
        splitLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: false
        },
        pointer: {
          show: false,
          length: '0',
          width: '0'
        },
        detail: {
          fontWeight: 'bold',
          formatter: ['{value}%', '{b|CPU已使用}'].join('\n'),
          rich: {
            a: {
              color: '#fff',
              fontSize: '20'
            },
            b: {
              color: '#fff',
              fontSize: '12',
              height: 26
            }
          },
          offsetCenter: [0, '5%'],
          color: '#fff',
          fontSize: '20'
        },
        data: [
          {
            // name: 'CPU已使用',
            value: res.value,
            x: 'center',
            y: 'center',
            itemStyle: {
              color: '#FFF',
              fontSize: '15'
            }
          }
        ]
      }
    ]
  }
  setOption(targit, optionData)
}

// dashboard页面饼图处理option中数据
export function setPieData(targit, res) {
  let pieData = {
    title: {
      text: `${res.value}%`,
      subtext: `${res.name}已使用`,
      x: 'center',
      y: '43%',
      textStyle: {
        // fontWeight: 'normal',
        color: '#fff',
        fontSize: '20'
      },
      subtextStyle: {
        fontWeight: 'normal',
        color: '#fff'
      }
    },
    color: ['rgba(176, 212, 251, 1)'],
    legend: {
      show: true,
      itemGap: 12,
      data: ['已用', '剩余'],
      top: '15%',
      textStyle: {
        color: '#C1E5FF'
      },
      icon: 'circle',
      itemWidth: 5,
      itemHeight: 5
    },

    series: [
      {
        // name: '内存使用情况',
        type: 'pie',
        clockWise: true,
        startAngle: -90,
        radius: ['36%', '50%'],
        color: res.color,
        itemStyle: {
          normal: {
            label: {
              show: false
            },
            labelLine: {
              show: false
            }
          }
        },
        hoverAnimation: false,
        data: [
          {
            value: res.value,
            name: '已用'
          },
          {
            name: '剩余',
            value: 100 - res.value
            // color: '#ffe858',
          }
        ]
      }
    ]
  }
  // console.log(targit, pieData)
  setOption(targit, pieData)
}

// 网络流量
export function setLineData(targit, res, type) {
  // console.log('series res', res)
  let series = setOptionData(res, type)
  let yAxis = setyAxis(res.yAxis)
  let subtext
  if (yAxis.length === 1) {
    // 单位的判断
    subtext = yAxis[0].formatter.split('{value}')[1]
    // console.log('subtext', subtext)
  }
  let lineData = {
    title: {
      text: res.title,
      subtext: `单位: ${subtext}`,
      top: '5%',
      left: '5%',
      textStyle: {
        color: '#fff',
        fontWeight: 'normal'
      },
      subtextStyle: {
        color: '#4E9ED8'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: 'line' // 默认为直线，可选为：'line' | 'shadow'
      }
      // formatter: (data) => {
      //     // for (var i = 0, length = data.length; i < length; i++) {
      //     //     res = data[i].name
      //     // }
      //     // return res
      // }
    },
    color: ['#C0A54D', '#6553D2', '#2a8eff', '#86d258'],
    legend: {
      data: res.legend,
      type: res.legend.length > 3 ? 'scroll' : 'plain',
      width: '88%',
      pageIconSize: 10,
      pageTextStyle: {
        color: '#fff',
        fontSize: 10
      },
      bottom: '1%',
      textStyle: {
        color: '#C1E5FF'
      },
      icon: 'circle',
      itemWidth: 5,
      itemHeight: 5,
      itemGap: 40
    },
    grid: {
      left: '5%',
      right: '5%',
      bottom: '10%',
      top: '30%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      splitLine: {
        lineStyle: {
          color: '#5170DA',
          opacity: 0.1
        }
      },
      axisLine: {
        lineStyle: {
          color: '#5170DA',
          opacity: 0.1
        }
      },
      data: res.xAxis
    },
    yAxis: yAxis,
    series: series
  }
  // console.log('lineData', lineData)
  setOption(targit, lineData)
}

// dashboard中bar的y轴处理
export function setyAxis(data) {
  let yAxis = []
  data.map(item => {
    let newItem = {
      // 'type': 'value',
      splitLine: {
        lineStyle: {
          color: '#5170DA',
          opacity: 0.1
        }
      },
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: '#5170DA',
          opacity: 0.1
        }
      },
      formatter: item.formatter
      // 'name': item.name
    }
    yAxis.push(newItem)
  })
  // console.log('11111', yAxis)
  return yAxis
}

export function setOptionData(option, type) {
  let series = []
  if (type == 'line') {
    if (option.series && option.series.length) {
      for (let i = 0; i < option.series.length; i++) {
        const item = option.series[i]
        let seriesItem = {}
        seriesItem = {
          name: option.legend[i],
          type: type,
          yAxisIndex: item.position == 'left' ? 0 : 1,
          areaStyle: {
            opacity: '0.1'
          },
          formatter: item.formatter,
          smooth: true,
          data: item.data
        }
        series.push(seriesItem)
      }
    } else {
      series = []
    }
  } else if (type == 'bar') {
    if (option.series && option.series.length == 1) {
      // console.log(option.series)
      option.series.map((item, index) => {
        let seriesItem = {}
        seriesItem = {
          name: option.legend[index],
          type: type,
          barWidth: option.series[0].data.length < 8 ? '10%' : '20px', // 获取到的数据不足请求的数据
          // barWidth: '20px',
          barCategoryGap: '42px',
          // barGap: index > 1 ? '-100%' : '2%',
          barGap: '42px',
          formatter: item.formatter,
          data: item.data
        }
        series.push(seriesItem)
      })
    } else if (option.series && option.series.length > 1) {
      // 多数据柱状图数据处理
      // console.log('option.legend', option.legend, option.series)
      option.series.map((item, index) => {
        let seriesItem = {}
        seriesItem = {
          name: option.legend[index],
          type: type,
          barWidth: '20px',
          barCategoryGap: '42px',
          barGap: '-100%',
          formatter: item.formatter,
          data: item.data
        }
        series.push(seriesItem)
      })
    } else {
      series = []
    }
  }
  return series
}

export function setBarData(targit, res, type) {
  let series = setOptionData(res, type)
  let yAxis = setyAxis(res.yAxis)
  let showlegend = targit._dom.id // 项目异常情况legend参数
  let barData = {
    title: {
      text: res.title,
      subtext: res.subtext,
      link: res.title === '项目异常情况' ? '#/dashboard/index/exceptionPage' : null,
      target: 'self',
      top: '3%',
      left: '3%',
      textStyle: {
        color: '#fff',
        // fontWeight: 'normal',
        fontSize: '18'
      },
      subtextStyle: {
        color: '#4E9ED8'
      }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
      }
      // formatter: (data) => {
      //     console.log(data)
      // }
    },
    legend: {
      show: showlegend == 'warnChart',
      data: res.legend,
      top: '10%',
      orient: 'horizontal', // 'vertical'
      x: '91%', // 'center' | 'left' | {number},
      y: 'top', // 'center' | 'bottom' | {number}
      textStyle: {
        color: '#C1E5FF'
      },
      icon: 'rect',
      itemWidth: 5,
      itemHeight: 5
    },
    grid: {
      left: '3%',
      right: '3%',
      bottom: '3%',
      top: '22%',
      containLabel: true
    },
    color: res.color,
    xAxis: [
      {
        type: 'category',
        data: res.xAxis,
        splitLine: {
          lineStyle: {
            color: '#5170DA',
            opacity: 0.1
          }
        },
        axisLabel: {
          // X轴倾斜显示
          // interval: 0,
          rotate: 20
          // width: 40
        },
        axisLine: {
          lineStyle: {
            color: '#5170DA',
            opacity: 0.1
          }
        }
      }
    ],

    yAxis: yAxis,
    series: series
  }
  // console.log(barData)
  setOption(targit, barData)
}

export function setOption(targit, optionData) {
  targit.setOption(optionData, true)
}

export function setXData(xAxisData, format) {
  let xAxis = []
  xAxisData.map(item => {
    // xAxis.push(date.date(item).format(format))
    xAxis.push(item)
  })
  return xAxis
}

// 节流函数 处理图标自适应
export function debounce(func, wait, immediate) {
  let timeout, args, context, timestamp, result

  const later = function() {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp

    // 上次被包装函数被调用时间间隔last小于设定时间间隔wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last)
    } else {
      timeout = null
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, args)
        if (!timeout) context = args = null
      }
    }
  }

  return function(...args) {
    context = this
    timestamp = +new Date()
    const callNow = immediate && !timeout
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait)
    if (callNow) {
      result = func.apply(context, args)
      context = args = null
    }

    return result
  }
}

function tolerateDateFault(data) {
  // var minimum = 0
  // var seriesArr = data.series
  // seriesArr.forEach((item, index) => {
  //   if (index === 0) {
  //     minimum = item.data.length
  //   } else {
  //     if (item.data.length < minimum) {
  //       minimum = item.data.length
  //     }
  //   }
  // })
  // seriesArr.forEach((item) => {
  //   item.data = item.data.slice(0, minimum)
  // })
  // data.xAxis = data.xAxis.slice(0, minimum)
  let seriesArr = data.series
  let dataLength = data.xAxis.length
  seriesArr.forEach((item, index) => {
    if (item.data.length < dataLength) {
      let concatArr = []
      let concatNum = dataLength - item.data.length
      for (let i = 0; i < concatNum; i++) {
        concatArr.push(0)
      }
      item.data = item.data.concat(concatArr)
    } else if (item.data.length > dataLength) {
      item.data = item.data.slice(0, dataLength)
    }
    // console.log('seriesArr=', seriesArr)
  })
}
