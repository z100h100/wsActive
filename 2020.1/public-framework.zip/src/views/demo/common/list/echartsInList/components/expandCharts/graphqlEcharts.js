/** "use strict"; **/
/**
 * Author:liyy;
 * CreateTime:2019-11-20 16:00;
 * Description:
 **/
import moment from 'moment'

// 根据开始结束时间和 step 获取传参格式
export function getDuration(duration) {
  let { start, end, step } = duration
  let newDuration = {}
  newDuration.start = formatDate(start, step)
  newDuration.end = formatDate(end, step)
  newDuration.step = step
  return newDuration
}

export function formatDate(data, step) {
  let newData
  data = Number(data)
  let format = 'YYYY-MM-DD HH:mm:ss'
  if (step == 'MINUTE') {
    format = 'YYYY-MM-DD HHmm'
    newData = moment(data).format(format)
  } else if (step == 'HOUR') {
    /* 2019-11-19 18 */
    format = 'YYYY-MM-DD HH'
    newData = moment(data).format(format)
  } else if (step == 'DAY') {
    format = 'YYYY-MM-DD'
    newData = moment(data).format(format)
  } else if (step == 'MONTH') {
    format = 'YYYY-MM'
    newData = moment(data).format(format)
  }
  return newData
}

export function formatXAxis(data, step) {
  let newData
  data = Number(data)
  let format = 'YYYY-MM-DD HH:mm:ss'
  if (step == 'MINUTE') {
    format = 'MM-DD HH:mm'
    newData = moment(data).format(format)
  } else if (step == 'HOUR') {
    format = 'MM-DD HH'
    newData = moment(data).format(format)
  } else if (step == 'DAY') {
    format = 'MM-DD'
    newData = moment(data).format(format)
  } else if (step == 'MONTH') {
    format = 'YYYY-MM'
    newData = moment(data).format(format)
  }
  return newData
}

// 根据step 获取不通的x 轴数据
export function getXAxis(ops) {
  if (!ops || !ops.step) {
    return
  }
  let space = ''
  let format = 'YYYY-MM-DD HH:mm:ss'
  if (ops.step == 'MINUTE') {
    space = 60000
    format = 'HH:mm'
  } else if (ops.step == 'HOUR') {
    space = 3600000
    format = 'HH:mm'
  } else if (ops.step == 'DAY') {
    space = 86400000
    format = 'MM-DD'
  } else if (ops.step == 'MONTH') {
    space = 2592000000
    format = 'YYYY-MM'
  }
  let params = {
    start: ops.start,
    end: ops.end,
    space: space,
    step: ops.step,
    format: format
  }
  return getTimeArray(params)
}

export const getTimeArray = params => {
  if (!params.start || !params.end || !params.step || !params.space || !params.format) {
    return
  }
  let startTime = Number(params.start)
  let endTime = Number(params.end)
  let timeArray = []
  // 获取x轴坐标数组
  while (startTime < endTime) {
    timeArray.push(moment(new Date(startTime)).format(params.format))
    startTime = startTime + params.space
  }
  // console.log('timeArray=', timeArray)
  // this.timeArray = timeArray
  return timeArray
}

export function getOptions(res, ops) {
  // console.log('res=', res)
  // console.log('lists=', ops)
  let op = {
    title: '',
    series: [],
    xAxis: [],
    yAxis: [],
    legendOps: []
  }
  op.title = ops.title
  op.series = setSeries(res, ops.data)
  op.xAxis = ops.xAxis
  op.yAxis = setyAxis(ops.yAxis)
  op.grid = ops.grid
  op.legendOps = ops.legendOps || {}
  op.noNeedContainLabel = ops.noNeedContainLabel
  op.tooltipPosition = ops.tooltipPosition
  return op
}

function setSeries(res, data) {
  let series = []
  if (!data.length) {
    series = []
    return
  }
  console.log('data=', data)
  data.forEach(item => {
    series.push({
      name: item.name,
      data: res[item.key].values,
      position: item.position,
      borderType: item.borderType || 'solid',
      // itemStyle: {
      //   color: item.color
      // },
      // lineStyle: {
      //   color: item.color
      // },
      // areaStyle: {
      //   color: item.color,
      //   // opacity: i >= 2 ? '0' : '0.1' // 第三条数据，没有区域颜色
      //   opacity: 0 // 第三条数据，没有区域颜色
      // },
      // symbol: 'none',
      // symbolSize: 1,
      showSymbol: false,
      // formatter: item.formatter,
      smooth: true
    })
  })
  return series
}

function setyAxis(yAxis) {
  let newYAxis = []
  yAxis.forEach((item, index) => {
    let yAxisItem = {
      // min: 'dataMin',
      minInterval: 1,
      name: hackForYname(item.name, item.position),
      splitLine: {
        // 网格线 y轴对应的是否显示
        show: true,
        lineStyle: {
          color: ['#F3F5FA']
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        // formatter: item.formatter,
        color: '#9097A5'
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: '#DCDFE6'
        }
      },
      nameTextStyle: {
        color: '#9097A5',
        // width: '100%'
        align: 'left'
      },
      nameLocation: 'end',
      position: index == 0 ? 'left' : 'right'
      // boundaryGap: ['20%', '20%']
      // nameLocation: 'center',
      // nameGap: 100
      // nameRotate: 90
    }
    newYAxis.push(yAxisItem)
  })
  return newYAxis
}

function hackForYname(name, position) {
  let len = 0
  for (let i = 0; i < name.length; i++) {
    var c = name.charCodeAt(i)
    // 单字节加1
    if ((c >= 0x0001 && c <= 0x007e) || (c >= 0xff60 && c <= 0xff9f)) {
      len++
    } else {
      len += 2
    }
  }
  if (len > 6) {
    let a = ((len - 6) / 2).toFixed(0)
    let space = ''
    for (let i = 0; i < a; i++) {
      space += '\u3000'
    }
    if (position == 'left') {
      name = space + name
    } else {
      name = name + space
    }
  }
  // console.log('name=', name)
  return name
}

export function checkData(dom, hasData, option) {
  let newEl = document.createElement('div')
  // console.log(dom, hasData)
  newEl.className = 'echarts-empty'
  let con = `<div class="echarts__empty-text"><div class="charts-title">${(option &&
    option.title.text) ||
    ''}</div> <div class="content">暂无数据</div> </div>`
  newEl.innerHTML = con
  let el = dom._dom.childNodes
  let len = el.length
  let hasEmpty = false
  for (let i = 0; i < len; i++) {
    let item = el[i]
    // console.log('item.classList.contains(\'echarts-empty\')=', item.classList.contains('echarts-empty'))
    if (item.classList.contains('echarts-empty')) {
      hasEmpty = true
      break
    }
  }
  if (hasEmpty && hasData) {
    let emptyDom = dom._dom.getElementsByClassName('echarts-empty')[0]
    dom._dom.removeChild(emptyDom)
  }
  if (!hasEmpty && !hasData) {
    // console.log('没占位符 没数据就')
    dom._dom.appendChild(newEl)
    return false
  }
}
