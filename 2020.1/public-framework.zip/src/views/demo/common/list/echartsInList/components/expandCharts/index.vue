<template>
  <el-row :gutter="20" class="expanded">
    <el-col :span="8">
      <div class="chart_item">
        <div class="title">
          接口耗时分布
        </div>
        <div class="charts" v-loading="chartsLoading">
          <!--        <Charts :optctions="delay"></Charts>-->
          <tableExpandChart ref="timeDistribution"></tableExpandChart>
        </div>
      </div>
    </el-col>
    <el-col :span="8">
      <div class="chart_item">
        <div class="title">
          访问量分布
        </div>
        <div class="charts" v-loading="chartsLoading">
          <tableExpandChart ref="requestsNum"></tableExpandChart>
        </div>
      </div>
    </el-col>
    <el-col :span="8">
      <div class="chart_item">
        <div class="title">
          错误分布
        </div>
        <div class="charts" v-loading="chartsLoading">
          <tableExpandChart ref="erorrNumChart"></tableExpandChart>
        </div>
      </div>
    </el-col>
  </el-row>
</template>

<script>
import tableExpandChart from './tableExpandChart'

export default {
  name: 'index',
  data() {
    return {
      chartsData: {},
      timeArray: [],
      delay: {},
      non_heap: {},
      GC: {},
      GCcount: [],
      chartsLoading: false,
      duration: {},
      timeout: null
    }
  },
  props: {},
  watch: {},
  components: {
    tableExpandChart
  },
  mounted() {},
  methods: {
    setPrams(params) {
      this.$refs.timeDistribution.setPrams(params)
      this.$refs.requestsNum.setPrams(params)
      this.$refs.erorrNumChart.setPrams(params)
    }
  }
}
</script>

<style scoped lang="scss">
.expanded {
  /*display: flex;*/
  /*justify-content: space-between;*/
  .chart_item {
    background: #fff;
    height: 290px;

    .title {
      padding: 10px 20px 0 20px;
      line-height: 30px;
    }
  }
}

/*.charts {*/
/*  padding-bottom: 0;*/

/*  &:nth-child(2n) {*/
/*    border-left: 1px dashed #eeeeee;*/
/*  }*/
/*}*/
</style>
