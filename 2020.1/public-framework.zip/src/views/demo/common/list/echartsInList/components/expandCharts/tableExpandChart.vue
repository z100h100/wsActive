<template>
  <div class="provideService chartsPanel">
    <!--<div class="title">
      耗时直方图
    </div>-->
    <div class="con full provide">
      <div class="charts" v-loading="chartsLoading">
        <Charts :optctions="delay"></Charts>
      </div>
    </div>
  </div>
</template>

<script>
import { getDuration, getXAxis } from './graphqlEcharts'
import Charts from './Charts.vue'

export default {
  name: 'timeConsum',
  data() {
    return {
      chartsData: {},
      timeArray: [],
      delay: {},
      non_heap: {},
      GC: {},
      GCcount: [],
      chartsLoading: false,
      duration: {},
      timeout: null
    }
  },
  props: {},
  watch: {},
  components: {
    Charts
  },
  mounted() {},
  methods: {
    setPrams(params) {
      let newParams = {
        step: params.step,
        start: params.startTime,
        end: params.endTime
      }
      this.timeArray = getXAxis(newParams)
      this.duration = getDuration(newParams)
      this.getGraphData(params)
    },
    getGraphData(ops) {
      this.chartsLoading = true
      this.chartsLoading = false
      let res = {
        interfaceLatencyDistributionHistogram: {
          values: [
            {
              id: '0-1',
              value: 0
            },
            { id: '1-2', value: 0 },
            { id: '2-4', value: 0 },
            { id: '4-8', value: 0 },
            {
              id: '8-16',
              value: 0
            },
            { id: '16-32', value: 22 },
            { id: '32-64', value: 82 },
            {
              id: '64-128',
              value: 347
            },
            { id: '128-256', value: 459 },
            { id: '256-512', value: 360 },
            {
              id: '512-1024',
              value: 172
            },
            { id: '1024-2048', value: 1 },
            { id: '2048-4096', value: 0 },
            {
              id: '4096-8192',
              value: 0
            },
            { id: '8192-16384', value: 0 },
            { id: '16384-32768', value: 0 },
            { id: '32768-65536', value: 0 }
          ]
        }
      }
      this.setChartsData(JSON.parse(JSON.stringify(res)))
    },
    setChartsData(resData) {
      let chartsData = {}
      // chartsData.title = ''
      chartsData.series = []
      chartsData.yAxis = []
      chartsData.xAxis = []
      chartsData.chartsType = ['bar']
      chartsData.legendHide = true
      let data = resData.interfaceLatencyDistributionHistogram.values
      let seriesArr = [{ name: 'Duration (ms)', data: [], position: 'left' }]
      data.forEach((item, index) => {
        seriesArr[0].data.push({ value: item.value, range: item.id })
        if (index < data.length - 1) {
          chartsData.xAxis.push(item.id.split('-')[1])
        } else {
          chartsData.xAxis.push(item.id.split('-')[1] + 'ms')
        }
      })
      chartsData.series = seriesArr
      chartsData.grid = {
        left: '20',
        right: '20',
        bottom: '20',
        top: '30',
        containLabel: true
      }
      chartsData.yAxis = [{ name: '次' }]
      chartsData.Xinterval = 2
      chartsData.tooltipFormatter = params => {
        let range = ''
        let items = `${params[0].data.range} ms`
        params.forEach(item => {
          items += `<div>次数: ${item.value}</div>`
        })
        let tooltip = ``
        tooltip = `${range} ${items}`
        return tooltip
      }
      this.delay = chartsData
    }
  }
}
</script>

<style scoped lang="scss">
/deep/ {
  .tableChart {
    height: 250px;
  }
  .charts {
    padding-top: 0 !important;
  }
}

.full {
  padding: 0;
}
</style>
