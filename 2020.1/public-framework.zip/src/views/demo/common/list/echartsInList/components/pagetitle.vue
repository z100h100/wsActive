<template>
  <page-title>
    <template slot="left-area">
      <el-input
        placeholder="请输入需要查询的接口名称"
        style="width: 420px"
        size="small"
        clearable
        v-model="partialEndpointName"
      >
        <el-button slot="append" icon="el-icon-search"></el-button>
      </el-input>
    </template>
    <template slot="right-area">
      <GrafanaDatePicker
        ref="grafanaDatePicker"
        :hasRefresh="true"
        :timer="refreshTimer"
        @change="grafanaDateChange"
        :quick="quick"
        :lastDate="lastDate"
        :defaultValue="defaultValue"
      ></GrafanaDatePicker>
    </template>
  </page-title>
</template>

<script>
import GrafanaDatePicker from '@/components/GrafanaDatePicker'

export default {
  name: 'pagetitle',
  components: {
    GrafanaDatePicker
  },
  props: {
    lastDate: {
      type: Object
    },
    showInstance: {
      type: [String, Boolean],
      default: true
    }
  },
  data() {
    return {
      quick: 'true',
      refreshTimer: '',
      defaultValue: '30',
      name: '',
      searchDate: {
        dateRange: []
      },
      selectType: '',
      time_ms: '',
      partialEndpointName: ''
    }
  },
  created() {
    if (this.$route.query.start && this.$route.query.end) {
      this.getdateRange()
    }
  },
  mounted() {
    this.name = this.$route.query.name ? this.$route.query.name : this.$route.query.mark
  },
  methods: {
    getdateRange() {
      this.$set(this.searchDate.dateRange, '0', this.$route.query.start)
      this.$set(this.searchDate.dateRange, '1', this.$route.query.end)
      this.quick = this.$route.query.quick
      this.refreshTimer = this.$route.query.timer
    },
    grafanaDateChange(value) {
      this.refreshTimer = value.timer
      this.step = value.step
      this.time = [(value.dateRange[0] / 1000).toFixed(0), (value.dateRange[1] / 1000).toFixed(0)]
      this.time_ms = [value.dateRange[0], value.dateRange[1]]
      this.quick = value.quick
      this.$emit('setGrafanaDate', value)
    }
  }
}
</script>

<style lang="scss" scoped>
.page-tit {
  display: flex;
  align-items: center;
  justify-content: space-between;
  .mark {
    border-color: #f5fcff;
    background: #f5fcff;
    color: #00b0ff;
    font-size: 14px;
    font-weight: bold;
    height: 32px;
    line-height: 32px;
    padding: 0 15px;
    border-radius: 3px;
    min-width: 200px;
  }
  .right {
    display: flex;
    .info {
      margin-right: 10px;
    }
  }
}
</style>
