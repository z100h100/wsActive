<template>
  <div>
    <pagetitle :lastDate="searchDate" :showInstance="false" @setGrafanaDate="grafanaDateChange">
    </pagetitle>
    <list-panel :showHead="false" style="padding-top: 20px">
      <template slot="header">
        <span class="header__title">{{ $t('route.callChains') }}</span>
      </template>
      <template slot="main">
        <el-table
          :data="instanceList"
          v-loading="dataLoading"
          highlight-current-row
          @sort-change="sortChange"
          @expand-change="expandChange"
          style="width: 100%"
          :row-key="getRowKeys"
          :expand-row-keys="expandKey"
        >
          <el-table-column type="expand">
            <template slot-scope="props">
              <expandCharts ref="expandCharts"></expandCharts>
            </template>
          </el-table-column>
          <el-table-column prop="url" min-width="120" label="接口名称">
            <template slot-scope="scope">
              <a @click="getDetail(scope.row)" v-if="scope.row.url">
                <table-popover :content="scope.row.url" :line="2"></table-popover>
              </a>
            </template>
          </el-table-column>
          <el-table-column prop="count" sortable min-width="80" label="调用数"> </el-table-column>
          <el-table-column prop="errorNum" min-width="80" sortable="" label="错误数">
          </el-table-column>
          <el-table-column prop="errorRate" min-width="80" sortable="" label="失败率">
            <template slot-scope="scope">
              <span v-if="scope.row.errorRate">
                {{ `${Number(scope.row.errorRate * 100).toFixed(2)}%` }}
              </span>
              <span v-else>0%</span>
            </template>
          </el-table-column>
          <el-table-column prop="latencyMax" min-width="120" sortable="" label="最大最小耗时">
            <template slot-scope="scope">
              <div>{{ scope.row.latencyMax }}{{ 'ms' }}</div>
              <div>{{ scope.row.latencyMin }}{{ 'ms' }}</div>
            </template>
          </el-table-column>
          <el-table-column prop="latencyP99" min-width="80" label="99线">
            <template slot-scope="scope">
              {{ Number(scope.row.latencyP99).toFixed(2) }}{{ 'ms' }}
            </template>
          </el-table-column>
          <el-table-column prop="latencyP95" min-width="80" label="95线">
            <template slot-scope="scope">
              {{ Number(scope.row.latencyP95).toFixed(2) }}{{ 'ms' }}
            </template>
          </el-table-column>
          <el-table-column prop="latencyP90" min-width="80" label="90线">
            <template slot-scope="scope">
              {{ Number(scope.row.latencyP90).toFixed(2) }}{{ 'ms' }}
            </template>
          </el-table-column>
          <el-table-column prop="latencyAvg" min-width="120" sortable="" label="平均响应时间">
            <template slot-scope="scope">
              {{ Number(scope.row.latencyAvg).toFixed(2) }}{{ 'ms' }}
            </template>
          </el-table-column>
          <el-table-column min-width="100" label="调用链追踪">
            <template slot-scope="scope">
              <a @click="getTranceDetail(scope.row)">详情</a>
            </template>
          </el-table-column>
        </el-table>
      </template>
      <template slot="pagination">
        <el-pagination
          background
          v-if="!dataLoading && paging.total != 0"
          :page-size="paging.pageSize"
          :total="paging.total"
          :current-page="paging.pageNo"
          class="pagination"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        >
        </el-pagination>
      </template>
    </list-panel>
    <!--<traceIdDialog ref="traceIdDialog"></traceIdDialog>-->
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import pagetitle from './components/pagetitle'
import expandCharts from './components/expandCharts'
import TablePopover from '@/components/TablePopover'

export default {
  name: 'index',
  components: {
    pagetitle,
    expandCharts,
    TablePopover
  },
  data() {
    return {
      dataLoading: false,
      // /////
      time: '',
      searchDate: {
        dateRange: []
      },
      activeTab: 'overview',
      time_ms: [],
      project: {
        mark: ''
      },
      step: '',
      instance: '', // 选中的实例
      url: this.$route.query.api, // 选中的api url
      quick: 'true',
      refreshTimer: '',
      instanceList: [],
      selfInstanceNum: '',
      endpointId: '',
      fields: '',
      sorts: '',
      partialEndpointName: '',
      paging: {
        pageSize: 10,
        pageNo: 0,
        total: 0
      },
      expandKey: []
    }
  },
  created() {},
  computed: {},
  mounted() {
    this.partialEndpointName = this.$route.query.api
    // this.getInstanceList()
    // this.getData()
  },
  methods: {
    ...mapActions(['getEchartsInList']),
    getRowKeys(row) {
      return row.url
    },
    getExpandKey() {
      this.expandKey = [this.instanceList[0].url]
      this.expandChange(this.instanceList[0], [this.instanceList[0]])
    },
    getData(type) {
      // console.log('getData (type)')
      let params = {
        startTime: this.time_ms[0],
        endTime: this.time_ms[1],
        serviceCode: this.$route.query.mark,
        instanceId: this.$route.query.instance,
        partialEndpointName: this.partialEndpointName,
        step: this.step,
        fields: this.fields,
        sorts: this.sorts,
        pageNo: this.paging.pageNo,
        pageSize: this.paging.pageSize
      }
      this.dataLoading = true
      this.getEchartsInList(params)
        .then(res => {
          if (res && res.code == '0') {
            this.selfInstanceNum = res.result.length || ''
            this.instanceList = res.result.interfaceInfoList
            this.$set(this.paging, 'total', res.result.total)
            // this.$nextTick(() => {
            //   this.paging.total = res.result.total
            //   console.log('this.paging.total=', this.paging.total)
            // })
            this.getExpandKey()
          } else {
            this.instanceList = []
          }
          this.dataLoading = false
        })
        .catch(() => {
          this.dataLoading = false
        })
    },
    grafanaDateChange(value) {
      this.step = value.step
      this.time = [(value.dateRange[0] / 1000).toFixed(0), (value.dateRange[1] / 1000).toFixed(0)]
      this.time_ms = [value.dateRange[0], value.dateRange[1]]
      this.refreshTimer = value.timer
      this.getData()
      this.changeRouter({
        timer: value.timer,
        start: value.dateRange[0],
        end: value.dateRange[1],
        quick: value.quick
      })
    },
    changeInstance(value) {
      this.instance = value
      this.getData()
      this.changeRouter({ instance: value })
    },
    changeRouter(ops) {
      // let defaultQuery = {
      //   baseImageType: this.$route.query.baseImageType,
      //   deployEnv: this.project.deployEnv,
      //   mark: this.$route.query.mark,
      //   name: this.$route.query.name,
      //   start: this.$route.query.start,
      //   end: this.$route.query.end,
      //   quick: this.$route.query.quick,
      //   timer: this.$route.query.timer,
      //   instance: this.$route.query.instance,
      //   serviceId: this.$route.query.serviceId,
      //   tabName: this.$route.query.tabName,
      //   api: this.url,
      //   endpointId: this.endpointId,
      //   orderField: this.$route.query.orderField
      // }
      // let query = {
      //   ...defaultQuery,
      //   ...ops
      // }
      // this.$router.replace({
      //   name: 'interfaceMgt',
      //   query: {
      //     ...query
      //   }
      // })
    },
    // /////////
    handleSizeChange(pageSize) {
      this.paging.pageSize = pageSize
      this.paging.pageNo = 0
      this.getData()
    },
    handlePageChange(pageNo) {
      this.paging.pageNo = pageNo
      this.getData()
    },
    initSort() {
      let orderField = this.$route.query.orderField
      let fields = ''
      if (orderField === 'count') {
        fields = 'start_time_count'
      } else if (orderField === 'latencyAvg') {
        fields = 'latency_avg'
      } else if (orderField === 'errorNum') {
        fields = 'errorNum'
      }
      this.fields = fields
      this.sorts = 'desc'
    },
    sortChange(column, prop, order) {
      let fields = ''
      let sorts = ''
      fields = column.prop
      if (column.prop === 'latencyMax') {
        fields = 'latency_max'
      }
      if (column.prop === 'latencyAvg') {
        fields = 'latency_avg'
      }
      if (column.prop === 'count') {
        fields = 'start_time_count'
      }
      // if (column.prop === 'errorNum') {
      //   fields = 'start_time_count'
      // }
      if (column.order === 'descending') {
        sorts = 'desc'
      } else if (column.order === 'ascending') {
        sorts = 'asc'
      }
      if (this.fields !== fields || this.sorts !== sorts) {
        this.fields = fields
        this.sorts = sorts
        this.getData()
      }
    },
    getDetail(row) {
      // this.$router.push({
      //   name: 'interfaceDetail',
      //   query: {
      //     api: row.url,
      //     endpointId: row.endpointId
      //   }
      // })
    },
    expandChange(row, expandedRows) {
      let params = {
        startTime: this.time_ms[0],
        endTime: this.time_ms[1],
        serviceCode: this.$route.query.mark,
        step: this.step,
        interfaceName: this.$route.query.api || '',
        instanceId: this.$route.query.instance || '',
        serviceId: this.$route.query.serviceId || '',
        endpointId: row.endpointId || ''
      }
      expandedRows.forEach(item => {
        if (item.endpointId == row.endpointId) {
          this.$nextTick(() => {
            this.$refs.expandCharts.setPrams(params)
          })
        }
      })
    },
    getTranceDetail(row) {
      // this.$refs.traceIdDialog.openDialog(row)
      // console.log('row=', row)
      // this.uri = row.url
      // this.traceIdDialogVisible = true
    }
  }
}
</script>

<style lang="scss" scoped>
/deep/ .el-tabs__content {
  overflow: scroll;
  height: calc(100vh - 200px);
}

.page-tit-selection /deep/ {
  .el-select__caret {
    display: none;
  }

  .el-input__inner {
    cursor: auto !important;
  }
}

.leftWrap {
  padding: 0;

  .LRcolumns {
    height: calc(100vh - 130px);
  }
}

.rightWrap {
  padding-right: 0;
}

/*{*/
/*}*/

/deep/ .el-tabs__header {
  padding-bottom: 20px;
}

/deep/ .chartsPanel .con .charts {
  padding-top: 20px;
}

/deep/ {
  .el-table__expanded-cell,
  .el-table__expanded-cell:hover {
    background: #f8f9fc !important;
    padding: 20px;
  }
}
</style>
