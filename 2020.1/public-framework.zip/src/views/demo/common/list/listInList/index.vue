<template>
  <div>
    <div class="topTitle">
      <div>
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="未处理" name="unresolved"> </el-tab-pane>
          <el-tab-pane label="已处理" name="resolved"></el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <el-table :data="tableData" :show-header="false" style="width: 100%;padding: 0 20px">
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-table :data="innerTableData" class="collapse-table">
            <el-table-column type="selection"></el-table-column>
            <el-table-column align="left" width="40">
              <template slot="header" slot-scope="scope">
                <el-dropdown
                  trigger="click"
                  placement="bottom-start"
                  class-name="table-header-dropdown"
                >
                  <i class="iconfont icon-gengduo" style="color: #757E8A"></i>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>批量处理</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </template>
            </el-table-column>
            <el-table-column prop="date" label="告警号" min-width="200"> </el-table-column>
            <el-table-column prop="name" label="annotations" min-width="300"> </el-table-column>
            <el-table-column prop="address" label="告警时间" min-width="300"> </el-table-column>
            <el-table-column :label="$t('common.operateLabel')" width="100">
              <template slot-scope="scope">
                <a>处理</a>
              </template>
            </el-table-column>
          </el-table>
        </template>
      </el-table-column>
      <el-table-column prop="name" label="告警名称">
        <template slot-scope="scope">
          <span>告警名称：{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="labels" label="labels">
        <template slot-scope="scope">
          <span
            >Labels：
            <span class="label" v-for="label in scope.row.labels">{{ label }}</span>
          </span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeName: 'unresolved',
      tableData: [
        {
          name: 'KAFKA健康检查-TEST',
          labels: ['业务', '混合云mysql业务', 'dev集群']
        },
        {
          name: 'KAFKA健康检查-TEST',
          labels: ['业务', '混合云mysql业务', 'dev集群']
        },
        {
          name: 'KAFKA健康检查-TEST',
          labels: ['业务', '混合云mysql业务', 'dev集群']
        },
        {
          name: 'KAFKA健康检查-TEST',
          labels: ['业务', '混合云mysql业务', 'dev集群']
        },
        {
          name: 'KAFKA健康检查-TEST',
          labels: ['业务', '混合云mysql业务', 'dev集群']
        },
        {
          name: 'KAFKA健康检查-TEST',
          labels: ['业务', '混合云mysql业务', 'dev集群']
        }
      ],
      innerTableData: [
        {
          date: '2019-12-11 10:23:43',
          name: 'dev环境的ES有分片未分配：5',
          address: '78218273'
        },
        {
          date: '2019-12-11 10:23:43',
          name: 'dev环境的ES有分片未分配：5',
          address: '78218273'
        },
        {
          date: '2019-12-11 10:23:43',
          name: 'dev环境的ES有分片未分配：5',
          address: '78218273'
        }
      ]
    }
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event)
    }
  }
}
</script>

<style scoped lang="scss">
.topTitle {
  background: #fff;
  padding: 0px;
  border-bottom: 1px #edf0f4 solid;
  div {
    padding: 0 10px;
  }
}
.label {
  color: #494f5c;
  line-height: 24px;
  background: #f8f9fc;
  border: 1px #e8edf1 solid;
  border-radius: 12px;
  padding: 0px 10px;
  margin-left: 10px;
  display: inline-block;
  font-family: PingFangSC-Regular;
  font-size: 12px;
  letter-spacing: 0;
}

/deep/ {
  .el-table__expanded-cell {
    background: #f7f8fc;
    border-left: 1px solid #e7eaeb;
    border-right: 1px solid #e7eaeb;
    border-bottom: 1px solid #e7eaeb;
  }
  .el-table__expanded-cell,
  .el-table__expanded-cell:hover {
    background: #f7f8fc !important;
    padding: 20px;
  }
}

.collapse-table {
  width: calc(100% - 40px);
}
// 折叠面板的table样式重置
.collapse-table /deep/ {
  th {
    background: #edeff4;
  }

  td {
    background: #f8f9fc;
  }

  // table_body限制最大高度
  .el-table__body-wrapper {
    max-height: calc(100vh - 200px); // 使得可滚动区域尽可能大
    overflow-y: auto;
  }
}

.el-dropdown-menu {
  padding: 0;
  .el-dropdown-menu__item {
    font-family: PingFangSC-Medium;
    font-size: 13px;
    color: #494f5c;
    letter-spacing: 0;
    &:hover {
      color: #11b2ff;
    }
  }
}
</style>
