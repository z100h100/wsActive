<template>
  <div class="map-tree-box">
    <el-tree
      ref="tree"
      :highlight-current="true"
      :default-expand-all="isExpandAll"
      node-key="id"
      :key="searchState"
      :data="treeData"
      :props="defaultProps"
      :expand-on-click-node="expandOnClickNode"
      :default-expanded-keys="expandKeys"
      :default-checked-keys="defaultCheckedKeys"
      @node-click="getListByPerson"
      @check="handleCheckChange"
      :indent="10"
      v-loading="treeTools.treeLoading"
      show-checkbox
    >
      <span slot-scope="{ node, data }">
        <template v-if="data.orgType === 'DEPT'">
          <span
            :class="{
              'dept-name': true,
              'is-empty-people': data.isEmpty,
              is_selected: data.isSelected
            }"
            :title="node.label"
            >{{ node.label }}</span
          >
          <span style="margin-left: 5px;">
            <span class="online-number">{{ data.onlineNum || 0 }}</span
            ><span class="total-number">/{{ data.totalNum || 0 }}</span>
          </span>
        </template>
        <template v-else="data.orgType === 'PERSON'">
          <span v-if="!data.isEmpty">
            <!--status 是否在线-->
            <i v-if="data.deviceLineStatus === 1" class="icon iconfont icon-location"></i>
            <i v-else class="icon iconfont icon-location wifi-down-line"></i>
          </span>
          <span class="tree-person-name" :title="node.label">{{ node.label }}</span>
        </template>
      </span>
    </el-tree>
  </div>
</template>

<script>
import { mapActions } from 'vuex'

export default {
  name: 'staffTree',
  props: {
    treeHeight: String,
    showVideoBtn: {
      default: false
    },
    expandOnClickNode: {
      default: true
    },
    // 展开第几级
    showLevel: {
      default: 1
    },
    equipmentList: {
      default: false
    },
    filterText: String
  },
  data() {
    return {
      searchState: 2, // 1表示动态加载，2表示全量加载
      showCases: '',
      key: 1,
      treeData: [],
      treeTools: {
        refreshTree: false,
        treeLoading: true
      },
      defaultProps: {
        children: 'children',
        label: 'name'
      },
      isExpandAll: false,
      playedId: '',
      treeInterval: '',
      loadPeopleDepIds: [],
      expandKeys: [],
      nowLoadedPeople: [],
      defaultCheckedKeys: [],
      lineStatus: '',
      deptCodeList: []
    }
  },
  computed: {},
  watch: {
    filterText(val) {
      this.search()
    }
  },
  beforeDestroy() {
    clearInterval(this.treeInterval)
  },
  mounted() {
    this.initDynamicTree()
    // this.timer = setInterval(() => {
    // this.filterText = ''
    // }, 60000)
  },
  destroyed() {
    // if (this.timer) {
    //   clearInterval(this.timer)
    // }
  },
  methods: {
    ...mapActions(['get_tree']),
    // 输入框中按下回车键
    search() {
      if (this.filterText.trim() === '') {
        this.isExpandAll = false
        this.searchState = 1
        this.treeTools.treeLoading = true
        this.nowLoadedPeople = [] // 清空loadedPeople
        this.initDynamicTree()
      } else {
        this.isExpandAll = false
        this.searchState = 2
        this.treeTools.treeLoading = true
        let text = this.filterText
        this.getTreeData(text).then(() => {
          // 获取已加载人员数据
          // 对没有加载数据的部门加入一列空数据
          if (this.treeData.length > 0) {
            this.nowLoadedPeople.push(this.getFirstLoadedPeople())
            this.expandKeys = this.treeData.map(node => {
              if (!(node.children.length === 1 && node.children[0].isEmpty)) {
                return node.id
              }
            })
            this.$nextTick(() => {
              this.expandKeys.forEach(id => {
                const node = this.$refs.tree.getNode(id)
                if (node) {
                  node.loadedPeople = true
                }
              })
            })
          }
        })
      }
    },
    initDynamicTree() {
      this.getTreeData()
        .then(() => {
          // 获取已加载人员数据
          // 对没有加载数据的部门加入一列空数据
          if (this.treeData.length > 0) {
            this.expandKeys = this.getLoadPeopleDepIds(this.showLevel)
            this.defaultCheckedKeys = this.getDefaultCheckedKeys(this.showLevel)
            this.nowLoadedPeople.push(this.getFirstLoadedPeople())
            this.hidePersonCheckBox()
          }
        })
        .then(() => {
          setTimeout(() => {
            let deptCodeList = []
            let selectedValue = this.$refs.tree.getCheckedNodes()
            selectedValue.forEach(item => {
              if (item.orgType === 'DEPT') {
                deptCodeList.push(item.code)
              }
            })
            this.deptCodeList = deptCodeList
          }, 2000)
        })
    },
    getPeopleArray(loadedPeople, data) {
      data.forEach(val => {
        if (val.orgType === 'PERSON') {
          loadedPeople.push(val)
        }
        if (val.orgType === 'DEPT') {
          if (val.children.length === 0) {
            // console.log(val)
            val.children.push({
              children: [],
              code: '0',
              id: val.id + 'people',
              level: 0,
              name: '没人',
              orgType: 'PERSON',
              parent: null,
              parentId: '',
              path: '',
              isEmpty: true
            })
          }
        }
        if (val.children.length > 0) {
          this.getPeopleArray(loadedPeople, val.children)
        }
      })
    },
    getFirstLoadedPeople() {
      let loadedPeople = []
      this.getPeopleArray(loadedPeople, this.treeData)
      return loadedPeople
    },
    getPeopleByDepIds() {
      return this.$apis.map.GET_PERSON_LIST_BY_DEPARTMENT({
        'f_in_department.id': this.loadPeopleDepIds.join(',')
      })
    },
    getIds(data, level, keysArray, include = false) {
      data.forEach((val, index) => {
        if (include) {
          if (level >= val.level) {
            keysArray.push(val.id)
          }
          if (val.children && val.children.length > 0 && val.level !== level) {
            this.getIds(val.children, level, keysArray, include)
          }
        } else {
          if (val.level === level) {
            keysArray.push(val.id)
          } else if (val.children && val.children.length > 0) {
            this.getIds(val.children, level, keysArray, include)
          }
        }
      })
    },
    getExpandKey(data, keysArray) {
      data.forEach((val, index) => {
        if (val.orgType === 'DEPT') {
          keysArray.push(val.id)
        }
        if (val.children && val.children.length > 0) {
          this.getExpandKey(val.children, keysArray)
        }
      })
    },
    getExpandKeys(level) {
      let keysArray = []
      this.getIds(this.treeData, level, keysArray)
      return keysArray
    },
    getLoadPeopleDepIds(level) {
      let PeopleDepIds = []
      let expandLevel = this.treeData[0].level + level - 1
      this.getIds(this.treeData, expandLevel, PeopleDepIds, true)
      return PeopleDepIds
    },
    /**
     * 获取数据列表 树形结构原生回掉函数
     * 通过侧边栏点击设备获取相应的列表信息
     * @param  {[type]} obj  [对象数据]
     * @param  {[type]} node [节点node]
     * @param  {[type]} curr [节点]
     * @return {[type]}      [description]
     */
    getListByPerson(obj, node, curr) {
      // console.log('node.data=>', node.data)
      // if (obj.nodeType && obj.nodeType === 'person') {
      //   this.$emit('clickPerson', obj)
      // }
      if (obj.isEmpty) {
        return
      }
      if (obj.orgType === 'PERSON') {
        this.$emit('clickPerson', obj)
      }
      // this.isSelected = obj.id
      // this.$refs.tree.setCurrentKey(obj.id)
    },
    getTreeData(val) {
      let param = {}
      if (val && val.trim() !== '') {
        param['f_like_name_or_code'] = val
      } else {
        param['level'] = this.showLevel
      }
      param['f_eq_status'] = 1
      param['lineStatus'] = this.lineStatus
      return this.get_tree(param)
        .then(response => {
          // console.log(response)
          // var treeData = this.getTrees(response, null)
          // this.treeData = treeData
          this.treeData = response
          // this.treeTools.defaultExpandedKeys = response.data.expandList
          this.treeTools.treeLoading = false
          this.hidePersonCheckBox()
          return response
        })
        .catch(() => {
          this.treeTools.treeLoading = false
        })
    },
    getChildDeptByParentDeptCode(deptCode) {
      return this.get_tree({
        deptParentCode: deptCode,
        f_eq_status: 1,
        paging: false,
        pageSize: 1000
      }).then(response => {
        return response
      })
    },
    hidePersonCheckBox() {
      this.$nextTick(() => {
        let childTreeNode = document.getElementsByClassName('tree-person-name')
        for (let item = 0; item < childTreeNode.length; item++) {
          childTreeNode[item].parentElement.parentElement.children[1].style.display = 'none'
        }
      })
    },
    getDefaultCheckedKeys() {
      return this.treeData.map(node => {
        return node.id
      })
    },
    handleCheckChange() {
      // 每次变动就把数据清除
      let deptCodeList = []
      let selectedValue = this.$refs.tree.getCheckedNodes()
      selectedValue.forEach(item => {
        if (item.orgType === 'DEPT') {
          deptCodeList.push(item.code)
        }
      })
      this.deptCodeList = deptCodeList
      this.$emit('personTreeCheck', this.deptCodeList)
    }
  }
}
</script>

<style lang="scss" scoped>
.map-tree-box {
  min-height: 400px;
  max-height: calc(100vh - 192px);
  overflow-y: auto;
  overflow-x: hidden;
  background-color: #fff;
  .el-tree-node__content:after {
    // top: 14px!important;
  }
  .el-tree-node.is-current > .el-tree-node__content > .custom-tree-node {
    color: #11b2ff !important;
  }
  .dept-name {
    font-family: PingFangSC-Medium;
    font-size: 13px;
    color: #333333;
    letter-spacing: 0;
  }
  .is-empty-people {
    color: #c3c2c2;
  }
  .is_selected {
    color: #11b2ff !important;
  }
  .iconfont {
    font-size: 12px;
    margin-right: 5px;
    color: #17c232;
  }

  .wifi-down-line {
    color: #cccccc;
  }

  .tree-person-name {
    font-family: PingFangSC-Medium;
    font-size: 13px;
    color: #333333;
    letter-spacing: 0;
    text-align: left;
  }

  .el-tree-node__content {
    height: 30px;
  }
  /*.el-tree-node.is-current .el-tree-node__content{*/
  /*background-color: #fff;*/
  /*}*/
  .el-tree--highlight-current .el-tree-node.is-current {
    // position: relative;
  }
  .el-tree--highlight-current .el-tree-node.is-current > .el-tree-node__content {
    // position: relative;
    // background: none;

    // &:before{
    //   content:'';
    //   position: absolute;
    //   left:0;
    //   top:0;
    //   width:2px;
    //   height:100%;
    // }
  }
  .el-tree--highlight-current .el-tree-node.is-current > .el-tree-node__content .name {
    color: #1d66dc;
  }

  .online-number,
  .total-number {
    font-family: PingFangSC-Regular;
    font-size: 12px;
    color: #999999;
    letter-spacing: 0;
  }
  .online-number {
    color: #17c232;
  }
}
</style>

<style>
.custom-fold-tree-style
  .el-tree-node__content
  > .el-checkbox
  .el-checkbox__input.is-checked
  .el-checkbox__inner,
.custom-fold-tree-style
  .el-tree-node__content
  > .el-checkbox
  .el-checkbox__input.is-indeterminate
  .el-checkbox__inner {
  background-color: #11b2ff;
  border-color: #11b2ff;
}
</style>
