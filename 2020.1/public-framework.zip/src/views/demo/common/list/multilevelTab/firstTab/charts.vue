<template>
  <div>
    <div :id="echarts" class="chartsItem"></div>
  </div>
</template>

<script>
import echarts from 'echarts'
import { mapGetters } from 'vuex'
export default {
  name: 'charts',
  data() {
    return {
      chartColor: [
        '16,131,132',
        '166,122,16',
        '162,41,41',
        '33,102,167',
        '12,135,103',
        '101,17,159'
      ],
      charts: null,
      commonData: {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            axis: 'x',
            type: 'line',
            label: {
              backgroundColor: '#D8D8D8'
            }
          },
          showContent: true,
          textStyle: {
            fontSize: 12
          }
        },
        legend: {
          // padding: [5, 0, 0, 0],
          data: [
            {
              name: 'HTTP入口',
              textStyle: {
                color: '#494F5C',
                fontSize: 12
              }
            }
          ],
          bottom: '10%'
          // itemWidth: 8,
          // itemHeight: 8
        },
        grid: {
          top: '18%',
          left: '5%',
          right: '5%',
          bottom: '18%',
          containLabel: true
        },
        xAxis: [
          {
            show: false,
            type: 'category',
            boundaryGap: false,
            axisTick: {
              show: false
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#9097A5',
                fontWeight: 100,
                fontSize: 12
              }
            },
            axisLine: {
              lineStyle: {
                color: '#EEF1F2',
                width: 1,
                type: 'solid'
              }
            },
            data: ['17:00', '21:00', '01:00', '05:00', '09:00', '13:00', '17:00']
          }
        ],
        yAxis: [
          {
            type: 'value',
            name: '单位：次',
            nameTextStyle: {
              color: '#9097A5',
              fontWeight: 100,
              fontSize: 12
            },
            axisLine: {
              show: false
              // lineStyle: {
              //   color: '#EEF1F2',
              //   width: 1,
              //   type: 'solid'
              // }
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#9097A5',
                fontWeight: 100,
                fontSize: 12
              }
            },
            splitLine: {
              show: true,
              lineStyle: {
                color: '#EEF1F2',
                width: 1,
                type: 'solid'
              }
            },
            axisTick: {
              show: false
            }
          }
        ],
        series: [
          {
            name: 'HTTP入口',
            type: 'line',
            stack: '总量',
            color: '#3399FF',
            areaStyle: {
              opacity: '0.1'
            },
            symbol: 'none',
            smooth: true,
            data: [150, 232, 201, 154, 190, 230, 110]
          }
        ]
      },
      opectionsObj: {
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: 'line' // 默认为直线，可选为：'line' | 'shadow'
          },
          backgroundColor: '#fff',
          textStyle: {
            color: '#666',
            fontSize: '12'
          },
          padding: [15, 15],
          // formatter: '{c}%',
          extraCssText: 'box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);',
          position: function(point, params, dom, rect, size) {
            // 提示框位置
            let x = 0 // x坐标位置
            let y = 0 // y坐标位置
            let offect = 10
            // 当前鼠标位置
            let pointX = point[0]
            let pointY = point[1]
            // 提示框大小
            let boxWidth = size.contentSize[0]
            let boxHeight = size.contentSize[1]
            // boxWidth > pointX 说明鼠标左边放不下提示框
            // if (boxWidth > pointX) {
            //   x = 5
            // } else { // 左边放的下
            //   x = pointX - boxWidth
            // }
            x = pointX - boxWidth - offect
            // boxHeight > pointY 说明鼠标上边放不下提示框
            // if (boxHeight > pointY) {
            //   y = 5
            // } else { // 上边放得下
            //   y = pointY - boxHeight
            // }
            y = pointY - boxHeight - offect
            return [x, y]
          }
        },
        legend: {
          show: false,
          // padding: [5, 0, 0, 0],
          data: [
            {
              // name: 'HTTP入口',
              textStyle: {
                color: '#494F5C',
                fontSize: 12
              }
            }
          ],
          bottom: 0
          // itemWidth: 8,
          // itemHeight: 8
        },
        grid: {
          top: 5,
          left: 5,
          right: 5,
          bottom: 5,
          containLabel: false
        },
        xAxis: [
          {
            show: false,
            type: 'category',
            boundaryGap: false,
            axisTick: {
              show: false
            },
            axisLabel: {
              show: true,
              textStyle: {
                color: '#9097A5',
                fontWeight: 100,
                fontSize: 12
              }
            },
            splitLine: { show: false },
            axisLine: {
              show: false,
              lineStyle: {
                color: '#EEF1F2',
                width: 1,
                type: 'solid'
              }
            },
            data: ['17:00', '21:00', '01:00', '05:00', '09:00', '13:00', '17:00']
          }
        ],
        yAxis: [],
        series: []
      }
    }
  },
  props: ['optctions'],
  watch: {
    optctions: {
      handler(val, oldval) {
        // console.log('watch optctions=', val)
        this.chartsSetData()
      },
      deep: true
    },
    sidebar: {
      handler(val, oldval) {
        this.chartsresize()
      },
      deep: true
    }
  },
  computed: {
    ...mapGetters(['sidebar']),
    echarts() {
      return 'echarts' + new Date().getTime() + Math.random() * 100000
    }
  },
  mounted() {
    this.charts = echarts.init(document.getElementById(this.echarts))
    window.addEventListener('resize', this.chartsresize, false)
    this.chartsSetData()
  },
  methods: {
    // setOptction () {
    //   let res = this.optctions
    //   this.opectionsObj.yAxis = []
    //   if (res && res.series && res.series.length > 0) {
    //     this.opectionsObj.legend.data = []
    //     this.opectionsObj.series = []
    //     this.opectionsObj.xAxis[0].data = res.xAxis
    //     this.opectionsObj.yAxis.push(
    //       {
    //         type: 'value',
    //         // name: res.yAxis.length > 0 ? `单位(${res.yAxis[0].name})` : '单位：(%)',
    //         nameTextStyle: {
    //           color: 'rgba(240,253,255, 0.7)',
    //           fontWeight: 100,
    //           fontSize: 12
    //         },
    //         axisLine: {
    //           lineStyle: {
    //             color: 'rgba(216,216,216, 0.1)',
    //             width: 1,
    //             type: 'solid'
    //           }
    //         },
    //         axisLabel: {
    //           show: true,
    //           textStyle: {
    //             color: 'rgba(240,253,255, 0.7)',
    //             fontWeight: 100,
    //             fontSize: 12
    //           }
    //         },
    //         splitLine: {
    //           show: false
    //           // lineStyle: {
    //           //   color: 'rgba(216,216,216, 0.1)',
    //           //   width: 1,
    //           //   type: 'solid'
    //           // }
    //         },
    //         axisTick: {
    //           show: false
    //         }
    //       },
    //       {
    //         type: 'value',
    //         // name: res.yAxis.length > 1 ? `单位(${res.yAxis[1].name})` : '',
    //         nameTextStyle: {
    //           color: 'rgba(240,253,255, 0.7)',
    //           fontWeight: 100,
    //           fontSize: 12
    //         },
    //         axisLine: {
    //           lineStyle: {
    //             color: 'rgba(216,216,216, 0.1)',
    //             width: 1,
    //             type: 'solid'
    //           }
    //         },
    //         axisLabel: {
    //           show: true,
    //           textStyle: {
    //             color: 'rgba(240,253,255, 0.7)',
    //             fontWeight: 100,
    //             fontSize: 12
    //           }
    //         },
    //         splitLine: {
    //           show: true,
    //           lineStyle: {
    //             color: 'rgba(216,216,216, 0.1)',
    //             width: 1,
    //             type: 'solid'
    //           }
    //         },
    //         axisTick: {
    //           show: true
    //         }
    //       }
    //     )
    //     res.series.map((item, index) => {
    //       this.opectionsObj.legend.data.push(
    //         {
    //           name: item.name,
    //           icon: 'circle',
    //           textStyle: {
    //             color: 'rgba(240,253,255, 0.5)',
    //             fontSize: 12
    //           }
    //         }
    //       )
    //       this.opectionsObj.series.push({
    //         name: item.name,
    //         type: 'line',
    //         stack: item.name,
    //         color: '#3DCCA6',
    //         areaStyle: {
    //           opacity: '0.1'
    //         },
    //         // symbol: 'none',
    //         // symbolSize: 1,
    //         showSymbol: false,
    //         smooth: true,
    //         itemStyle: {
    //           // opacity: 0
    //         },
    //         data: item.data
    //       })
    //       this.chartsSetData()
    //     })
    //   } else {
    //     // this.clear()
    //   }
    // },
    chartsSetData() {
      // this.charts.setOption(this.opectionsObj)
      this.charts.setOption(this.commonData)
    },
    chartsresize() {
      if (this.charts) this.charts.resize()
    },
    destroy() {
      this.charts = null
    }
  },
  destroyed() {
    window.removeEventListener('resize', this.chartsresize, false)
    this.destroy()
  }
}
</script>

<style lang="scss" scoped>
.chartsItem {
  height: 300px;
}
</style>
