<template>
  <div class="LRcolumns">
    <div class="leftWrap">
      <left></left>
    </div>
    <div class="rightWrap">
      <right></right>
    </div>
  </div>
</template>

<script>
import left from './left'
import right from './right'
export default {
  name: 'index',
  data() {
    return {}
  },
  components: {
    left,
    right
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
.LRcolumns {
  display: flex;
  .leftWrap {
    padding: 0 20px;
    border-right: 2px solid #e8edf1;
    background: #fff;
    width: 380px;
    min-height: calc(100vh - 130px);
    /deep/ {
      .el-tabs__content {
        display: none;
        padding: 0;
      }
      .el-tabs__header {
        position: relative !important;
        left: 0 !important;
        margin: 15px 0 20px;
        background: #fff;
        border-top: 1px solid transparent;
        .el-tabs__nav-wrap {
        }
        .el-tabs__item {
          padding: 0 20px;
          color: $base-font-color;
          border-top: 3px solid transparent;
          height: 32px;
          line-height: 27px;
          font-size: 14px;
          margin-left: 0;
        }
        .el-tabs__item.is-active {
          border-top-color: $primary-color;
          color: $primary-color;
        }
      }
      th {
        display: none;
      }
    }
  }
  .rightWrap {
    padding: 0 20px;
    background: #fff;
    width: calc(100% - 380px);
  }
}
</style>
