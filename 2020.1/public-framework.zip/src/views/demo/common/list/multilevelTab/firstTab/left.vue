<template>
  <div>
    <el-tabs type="border-card" v-model="AcName" @tab-click="handleClick">
      <el-tab-pane label="成功率" name="success"></el-tab-pane>
      <el-tab-pane label="Msg聚类" name="msg"></el-tab-pane>
    </el-tabs>
    <el-input
      style="margin-bottom: 15px;"
      class="tableSearch"
      :placeholder="$t('monitFrontendDetail.page_placehold')"
      @click.stop.native
      clearable
      size="small"
      @change="handleClick"
      v-model="searchHostData"
    >
      <el-button @click="handleClick" slot="append">
        <i class="iconfont icon-ic-search"></i>
      </el-button>
      <!--<el-button slot="append" icon="el-icon-search"></el-button>-->
    </el-input>
    <el-table
      highlight-current-row
      ref="singleTable"
      :data="hostData"
      class="headerSearch list"
      v-loading="dataLoading"
      @current-change="handleCurrentChange"
      style="width: 100%"
    >
      <el-table-column prop="time">
        <template slot="header" slot-scope="scope"> </template>
        <template slot-scope="scope">
          <div class="list">
            <div class="name">
              <span v-if="scope.row.page">{{ scope.row.page }}</span>
              <span v-else>-</span>
            </div>
            <div class="time">
              <span v-if="scope.row.rate">{{ scope.row.rate }}</span>
              <span v-else>-</span>
              <i class="el-icon-arrow-right"></i>
            </div>
          </div>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  name: 'left',
  data() {
    return {
      AcName: 'success',
      dataLoading: false,
      searchHostData: '',
      hostData: [{ page: '123', rate: '10' }]
    }
  },
  methods: {
    handleClick(val) {},
    handleCurrentChange() {}
  }
}
</script>

<style lang="scss" scoped>
.tableSearch {
  .el-input-group__append {
    .el-button {
      padding: 0 13.5px;
    }
  }
}
</style>
