<template>
  <div class="multilevelTab">
    <div class="page-tit">
      <div class="left">
        <i class="left-arrow el-icon-arrow-left" />
        <span class="split-tag">|</span>
        <!--<span class="page-tit-txt">新增设备</span>-->
      </div>
      <div class="right">
        <TimeSelect
          clearable
          :position="'right'"
          :pickerOptions="options"
          :hasRefresh="true"
          :lastDate="searchDate"
          :defaultValue="defaultValue"
          size="small"
          @change="TimeSelectChange"
        ></TimeSelect>
      </div>
    </div>
    <el-tabs v-model="activeTab" class="headTab">
      <el-tab-pane lazy label="访问速度" name="tab1">
        <firstTab></firstTab>
      </el-tab-pane>
      <el-tab-pane lazy label="JS错误率" name="tab2">
        <secondTab></secondTab>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import TimeSelect from '@/components/TimeSelect/index-ops'
import firstTab from './firstTab'
import secondTab from './secondTab'
export default {
  name: 'index',
  data() {
    return {
      timeProp: {
        label: 'name',
        value: 'code'
      },
      defaultValue: '300',
      searchDate: {
        dateRange: []
      },
      options: [
        { label: '2小时前', value: '120' },
        { label: '5小时前', value: '300' },
        { label: '1天前', value: '1400' }
      ],
      activeTab: 'tab1'
    }
  },
  components: {
    TimeSelect,
    firstTab,
    secondTab
  },
  methods: {
    TimeSelectChange(val) {
      console.log(val)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
.multilevelTab {
  position: relative;
}
.headTab /deep/ {
  .el-tabs__header {
    position: absolute;
    top: 2px;
    margin-left: 0;
    &:first-child {
      position: absolute;
      top: 2px;
      margin-left: 75px;
    }
  }
  .el-tabs__content {
    .el-tabs__header {
      position: relative;
      left: 0;
      margin-left: 0;
    }
    .rightTopTab {
      width: 100%;
      .el-tabs__content {
        padding: 0;
      }
      .el-tabs__header {
        position: absolute;
        right: 0;
        width: auto;
        background: transparent;
        border: 0;
        top: 10px;
      }
      .el-tabs__item {
        height: 32px;
        line-height: 32px;
        /*border-radius: 3px;*/
        overflow: hidden;
        border: 0;
        color: $base-font-color;
        background: $base-bg-color;
        margin-left: 10px;
        padding: 0 20px !important;
        font-family: PingFangSC-Regular;
        font-size: 13px;
        letter-spacing: 0;
        &.is-active {
          background: $primary-color;
          color: #fff !important;
        }
      }
      .el-tabs__nav {
        float: right;
      }
    }
  }
}
</style>
