<template>
  <div class="code-wrapper">
    <code-mirror
      :outForm="outForm"
      :outTips="outForm.tips"
      ref="code"
      v-on:update:config="handleUpdateConfig"
      style="width:100%;border: solid 1px #dcdfe6;"
    />
  </div>
</template>

<script>
import CodeMirror from '@/components/CodeMirror/code'
export default {
  components: {
    'code-mirror': CodeMirror
  },
  data() {
    return {
      outForm: {
        activeConfig: '',
        tips: []
      }
    }
  },
  methods: {
    handleUpdateConfig(value) {
      this.outForm.activeConfig = value
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
.code-wrapper {
  overflow-x: hidden;
  position: relative;
  border-radius: 4px;
  border: solid 1px #dcdfe6;
  border-left: solid 6px #60a7ef;
}
</style>
