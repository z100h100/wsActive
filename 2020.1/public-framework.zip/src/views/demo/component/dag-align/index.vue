<template>
  <div class="relation-wrap" v-loading="isLoading">
    <com-relation
      :modules="modules"
      ref="relation"
      v-on:update:isAtrrEditing="handleAtrrEditing"
      :refreshModule="refresh"
    ></com-relation>
  </div>
</template>
<script>
import ComRelation from './relation'
export default {
  name: 'stepThree',
  components: {
    'com-relation': ComRelation
  },
  data() {
    return {
      disabled: false,
      scheduleId: '',
      isLoading: false,
      isAttrEditing: false,
      modules: [
        {
          sonInfo: [
            {
              requestNum: 289331,
              latencyAvg: 71.71393981321341,
              serviceCode: '1111',
              errorType: '',
              layer: 'Database'
            }
          ],
          fatherInfo: [
            {
              requestNum: 2891,
              latencyAvg: 71.71393981321341,
              serviceCode: '1111',
              errorType: '',
              layer: 'Database'
            },
            {
              requestNum: 1084,
              latencyAvg: 245.6771217712177,
              serviceCode: '222',
              errorType: '',
              layer: 'Http'
            },
            {
              requestNum: 40,
              latencyAvg: 2.375,
              serviceCode: '333',
              errorType: '',
              layer: 'Cache'
            }
          ]
        }
      ]
    }
  },
  mounted() {
    this.refresh()
  },
  computed: {},
  methods: {
    // 重置组件树
    refresh() {},
    // 上一步
    handleCancel() {
      const { scheduleId } = this
      this.$router.replace({ name: 'stepTwo', query: { scheduleId } })
    },
    // 更新组件编辑状态
    handleAtrrEditing(flag) {
      this.isAttrEditing = flag
    }
  }
}
</script>
<style lang="scss" scoped>
.relation-wrap {
  background: transparent !important;
  position: relative;
  height: calc(100vh - 80px);
  background-color: #f9fbfd;
}
</style>
