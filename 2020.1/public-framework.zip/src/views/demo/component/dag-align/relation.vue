<template>
  <div style="background-color:transparent;">
    <div :class="{ 'tree-wrap': true }" id="treeWrap">
      <div id="tree"></div>
    </div>
  </div>
</template>
<script>
import { isEmpty } from '@/utils'
import echarts from 'echarts'

// import mysqlImg from './images/mysql.png'
// import redisImg from './images/redis.png'
import userImg from './images/user.png'

export default {
  name: 'ComRelation',
  props: {
    modules: {
      type: Array
    },
    refreshModule: {
      type: Function
    }
  },
  data() {
    return {
      showMoreAttr: false,
      currentModule: {},
      isLoading: false,
      myChart: null,
      option: {
        title: {
          text: ''
        },
        tooltip: { trigger: 'none' },
        animationDurationUpdate: 1500,
        animationEasingUpdate: 'quinticInOut',
        series: [
          {
            type: 'graph',
            layout: 'none',
            symbolSize: 80,
            // symbol 的位置
            symbolOffset: ['0', '0'],
            roam: true,
            // focus 时没有关联的消失
            focusNodeAdjacency: true,
            label: {
              normal: {
                show: true,
                fontWeight: '600',
                fontSize: 18,
                color: '#49505C',
                position: 'bottom'
              }
            },
            edgeSymbol: ['none', 'arrow'],
            edgeSymbolSize: [2, 8],
            data: [],
            links: [],
            lineStyle: {
              normal: {
                color: '#A3D4FF',
                opacity: 0.9,
                width: 2,
                curveness: 0
              }
            }
          }
        ]
      }
    }
  },
  mounted() {
    this.myChart = echarts.init(document.getElementById('tree'))
    this.$nextTick(() => {
      this.generateOption()
    })
  },
  methods: {
    // 根据组件集合生成 option data links
    generateOption() {
      const { modules, option, myChart } = this
      const levelObj = {}
      const yInterval = 300
      const xInterval = 400
      const data = []
      const links = []
      let levels = []
      const imgMap = {
        user: userImg,
        mysql: userImg,
        redis: userImg
      }
      if (isEmpty(modules)) {
        return
      }
      // 按照 level 分组
      const sonArr = modules[0].sonInfo
      const fatherArr = modules[0].fatherInfo
      const fatherIdArr = []
      sonArr.forEach((item, index) => {
        item['level'] = 1
        item['id'] = `son${index}`
        item['dependencies'] = [
          {
            id: 'self',
            requestNum: item.requestNum,
            latencyAvg: item.latencyAvg
          }
        ]
      })
      fatherArr.forEach((item, index) => {
        item['level'] = 3
        item['id'] = `father${index}`
        fatherIdArr.push({
          id: `father${index}`,
          requestNum: item.requestNum,
          latencyAvg: item.latencyAvg
        })
      })
      levelObj['1'] = sonArr
      levelObj['2'] = [{ id: 'self', dependencies: fatherIdArr }]
      levelObj['3'] = fatherArr

      // modules.forEach(module => {
      //   levels = Object.keys(levelObj)
      //   if (!isEmpty(levels) && module.level && levels.includes(module.level.toString())) {
      //     levelObj[module.level].push(module)
      //   } else {
      //     levelObj[module.level] = [module]
      //   }
      // })

      // levels 排序
      levels = Object.keys(levelObj)
      levels = levels.sort((a, b) => {
        return a - b
      })
      // 封装 data
      // 找出子元素最多的层数
      const levelModules = Object.values(levelObj)
      const maxItemNum = Math.max.apply(
        Math,
        levelModules.map(o => {
          return o.length
        })
      )
      levels.forEach(level => {
        const arr = levelObj[level]
        const interval = (xInterval * maxItemNum) / (arr.length + 1)
        let symbol = `image://${userImg}`
        const isChk = level % 2 === 0
        arr.forEach((item, index) => {
          let x = interval * (index + 1)
          // 层级
          x = isChk ? interval * (index + 1) : interval * (index + 1)
          symbol = imgMap[item.layer] ? imgMap[item.layer] : symbol
          data.push({
            id: item.id,
            value: item,
            name: item.serviceCode ? item.serviceCode : '',
            x: yInterval * level,
            y: x,
            symbolSize: 60,
            symbol,
            symbolOffset: ['5%', '0'],
            label: {
              fontSize: '12',
              color: '#49505C',
              fontWeight: 'normal'
            },
            tooltip: {
              show: false
            }
          })
        })
      })
      // 封装 links
      if (!isEmpty(data)) {
        data.forEach((dataItem, index) => {
          const dependencies =
            dataItem.value && !isEmpty(dataItem.value.dependencies)
              ? dataItem.value.dependencies
              : []
          dependencies.forEach(dependency => {
            const dependencyIndex = data.findIndex(obj => {
              return obj.id === dependency.id
            })
            if (dependencyIndex !== -1) {
              links.push({
                source: index,
                target: dependency.id,
                lineStyle: {
                  color: '#3DCCA6'
                },
                label: {
                  show: true,
                  padding: [0, 5, 5, 5],
                  color: '#D8D8D8',
                  backgroundColor: '#fff',
                  verticalAlign: 'top',
                  formatter: [
                    `{a|${dependency.requestNum ? dependency.requestNum.toFixed(2) : ''}}`,
                    `平均${dependency.latencyAvg ? dependency.latencyAvg.toFixed(2) : ''}`
                  ].join('\n'),
                  rich: {
                    a: {
                      display: 'inline-block',
                      color: '#D8D8D8'
                    }
                  }
                }
              })
            }
          })
        })
      }
      // 设置参数
      option.series[0].data = data
      option.series[0].links = links
      this.option = option
      myChart && myChart.setOption(option)
    }
  }
}
</script>
<style lang="scss">
#tree {
  width: 100%;
  height: 100%;
  div:first-child {
    width: 100% !important;
    height: 100% !important;
    canvas {
      width: 100% !important;
      height: 100% !important;
    }
  }
}
</style>
<style lang="scss" scoped>
.tree-wrap {
  overflow-x: hidden;
  position: relative;
  height: calc(100vh - 80px);
  #tree {
    width: 100%;
    height: 100%;
    background-color: #fff;
  }
}
</style>
