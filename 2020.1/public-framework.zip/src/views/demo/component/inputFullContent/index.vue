<template>
  <div>
    <div style="height: 45px;line-height: 45px;margin-bottom: 5px">
      <inputFullContent :options="options" clearable filterable v-model="value"></inputFullContent>
    </div>

    <!--    <search-panel :searchCriteria="searchCriteria" style="background: #016ad5">-->
    <!--      <template slot="form-area">-->
    <!--        <el-form-item label-width="0">-->
    <!--          <inputFullContent-->
    <!--            :options="options"-->
    <!--            clearable-->
    <!--            filterable-->
    <!--            v-model="value"></inputFullContent>-->
    <!--        </el-form-item>-->
    <!--      </template>-->
    <!--      <template slot="oper-area">-->
    <!--        <el-button type="primary" icon="iconfont icon-ic-search" @click="getList()"-->
    <!--        >{{ $t('common.searchButton') }}-->
    <!--        </el-button>-->
    <!--        <el-button @click="reset" class="el-button-gray">{{ $t('common.resetButton') }}</el-button>-->
    <!--      </template>-->
    <!--    </search-panel>-->
    <list-panel>
      <!-- header start -->
      <!--<template slot="header">
        <span class="header__title">{{ $t('demo.demoListTitle') }}</span>
        <el-button class="list-btn-w  iconfont icon-ic-new">{{ $t('demo.addButton') }}</el-button>
      </template>-->
      <!-- header end -->

      <!-- main start -->
      <template slot="main">
        <el-table :data="list" highlight-current-row style="width: 100%">
          <el-table-column prop="name" :label="$t('demo.nameLabel')"></el-table-column>
          <el-table-column prop="code" :label="$t('demo.codeLabel')"></el-table-column>
          <el-table-column prop="date" :label="$t('demo.dateLabel')"></el-table-column>
          <el-table-column :label="$t('common.operateLabel')" :width="165">
            <template slot-scope="scope">
              <a class="tableActionStyle" @click="handleGoDetail(scope.row)" href="javascript:;">{{
                $t('demo.showDetailButton')
              }}</a>
            </template>
          </el-table-column>
        </el-table>
      </template>
      <!-- main end -->

      <!-- pagination start -->
      <template slot="pagination">
        <el-pagination
          background
          v-if="paging.total !== 0"
          :page-size="paging.pageSize"
          :total="paging.total"
          :current-page="paging.pageNo + 1"
          class="pagination"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        >
        </el-pagination>
      </template>
      <!-- pagination end -->
    </list-panel>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import inputFullContent from '@/components/inputFullContent'
export default {
  components: {
    inputFullContent
  },
  data() {
    return {
      isLoading: false,
      isPageSizeChanging: false,
      value: '1',
      loading: false,
      options: [
        { name: '2小时前', code: '0' },
        {
          name:
            '5小时前5小时前5小时前5小时前5小时前5小时前5小时前5小时前5小时前5小时前5小时前5小时前5小时前',
          code: '1'
        },
        { name: '1天前', code: '2' }
      ]
    }
  },
  mounted() {
    this.getList()
  },
  computed: {
    ...mapState({
      list: state => state.demo.list,
      paging: state => state.demo.paging,
      searchCriteria: state => state.demo.searchCriteria
    })
  },
  methods: {
    aaa() {
      this.loading = true
      setTimeout(() => {
        this.options = []
        this.loading = false
      }, 1000)
    },
    ...mapActions(['getDemoList', 'resetSearchCriteria']),
    getList(pageSize = 10, pageNo = 0) {
      const { searchCriteria } = this
      let params = {
        ...searchCriteria,
        pageNo,
        pageSize
      }
      this.getDemoList(params)
    },
    reset() {
      this.resetSearchCriteria()
      this.getList()
    },
    handleSizeChange(pageSize) {
      this.isPageSizeChanging = true
      this.getList(pageSize)
    },
    handlePageChange(pageNo) {
      const { paging, isPageSizeChanging } = this
      if (!isPageSizeChanging) {
        this.getList(paging.pageSize, pageNo - 1)
      }
    },
    handleGoDetail() {}
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
</style>
