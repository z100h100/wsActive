<template>
  <div>
    <list-panel :showHead="true">
      <template slot="header">
        <span class="header__title">{{ $t('route.tablePopover') }}</span>
      </template>

      <template slot="main">
        <el-table :data="tableData" style="width: 100%">
          <el-table-column prop="date" label="日期" width="180"> </el-table-column>
          <el-table-column prop="name" width="100" label="姓名"> </el-table-column>
          <el-table-column width="100" prop="line" label="显示行数"> </el-table-column>
          <el-table-column label="地址">
            <template slot-scope="scope">
              <table-popover
                v-if="scope.row.line == 1"
                :content="scope.row.address"
                :line="1"
                :width="200"
              ></table-popover>
              <table-popover
                v-if="scope.row.line == 2"
                :content="scope.row.address"
                :line="2"
                :width="200"
                :placement="'left'"
              ></table-popover>
              <table-popover
                v-if="scope.row.line == 3"
                :content="scope.row.address"
                :line="3"
              ></table-popover>
              <table-popover
                v-if="scope.row.line == 4"
                :content="scope.row.address"
                :line="4"
                :placement="'bottom'"
              ></table-popover>
            </template>
          </el-table-column>
        </el-table>
      </template>
      <!-- pagination start -->
    </list-panel>
  </div>
</template>

<script>
import TablePopover from '@/components/TablePopover'
export default {
  components: {
    TablePopover
  },
  data() {
    return {
      tableData: [
        {
          date: '2019-07-12',
          line: '1',
          name: '穆林',
          address: '地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地'
        },
        {
          date: '2019-07-12',
          line: '1',
          name: '穆林',
          address:
            '地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址'
        },
        {
          date: '2019-07-12',
          line: '2',
          name: '穆林',
          address:
            '地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址'
        },
        {
          date: '2019-07-12',
          line: '3',
          name: '穆林',
          address:
            '地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址'
        },
        {
          date: '2019-07-12',
          line: '4',
          name: '穆林',
          address:
            '地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址地址'
        }
      ]
    }
  },
  mounted() {},
  computed: {},
  methods: {}
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
</style>
