<template>
  <div class="slide-wrap">
    <div :class="{ 'slide-panel-container': true, 'show-panel': isShow }">
      <div class="slide-panel-mask"></div>
      <div class="slide-panels">
        <div :class="{ 'slide-panel': true, active: isShow, hidden: !isShow }">
          <div class="slide-panel-content">
            <div class="panel-header">
              <h5>Slide</h5>
              <a class="panel-close">
                <i class="el-icon-close" @click="handleCloseSlide" style="font-size:20px"></i>
              </a>
            </div>
            <div class="panel-body">
              <div class="panel-body-content">
                <div class="selectedValue" @click="handleDatePickerOpen" style="margin-top:20px;">
                  <i class="el-icon-time" />
                  <span v-if="selectedDate">{{ selectedDate.displayText }}</span>
                  <span v-else>请选择</span>
                  <i class="el-icon-caret-bottom" />
                </div>
                <time-range-slide
                  ref="timeRangeSlide"
                  :selectedValue="selectedDate"
                  v-on:update:value="handleUpdateTime"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="btns">
      <div class="section">
        <el-button size="mini" @click="handleOpenDate">时间选择控件</el-button>
        <div class="selectedValue" @click="handleOpenDate">
          <i class="el-icon-time" />
          <span v-if="selectedDateCom">{{ selectedDateCom.displayText }}</span>
          <span v-else>请选择</span>
          <i class="el-icon-caret-bottom" />
        </div>
        <time-range-slide
          ref="timeRangeSlide1"
          :selectedValue="selectedDateCom"
          :showCustom="false"
          v-on:update:value="handleUpdateTimeCom"
        />
      </div>
      <el-button size="mini" @click="handleOpenSlide">右侧dialog</el-button>
    </div>
  </div>
</template>
<script>
import TimeRangeSlide from '@/components/TimeRangeSlide/picker'
export default {
  components: {
    'time-range-slide': TimeRangeSlide
  },
  data() {
    return {
      selectedDate: null,
      selectedDateCom: {
        text: '本月',
        queryTimeType: 25,
        type: 'now',
        gap: 'thismonth',
        startTime: '2019-06-01 00:00:00',
        endTime: '2019-06-28 16:15:41',
        displayText: '本月（相对）'
      },
      isShow: false
    }
  },
  methods: {
    handleDatePickerOpen() {
      this.$refs.timeRangeSlide.handleOpen()
    },
    handleUpdateTime(val) {
      this.selectedDate = val
    },
    handleOpenDate() {
      this.$refs.timeRangeSlide1.handleOpen()
    },
    handleUpdateTimeCom(val) {
      this.selectedDateCom = val
    },
    handleCloseSlide() {
      this.isShow = false
    },
    handleOpenSlide() {
      this.isShow = true
    }
  }
}
</script>
<style lang="scss" scoped>
@import '~@/styles/common';
.selectedValue {
  display: inline-block;
  padding: 0 10px;
  height: 36px;
  line-height: 36px;
  cursor: pointer;
  background-color: $primary-color;
  color: #fff;
  border-radius: 2px;
  span {
    display: inline-block;
    padding: 0 5px;
  }
}
.slide-wrap {
  background-color: #fff;
  > .slide-panel-container {
    .slide-panel {
      width: 600px;
    }
  }
}
.btns {
  padding: 20px;
  .section {
    margin-bottom: 20px;
    .el-button {
      margin-right: 30px;
    }
  }
}
</style>
