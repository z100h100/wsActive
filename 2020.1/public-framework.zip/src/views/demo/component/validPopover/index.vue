<template>
  <div>
    <list-panel :showHead="true">
      <template slot="header">
        <span class="header__title">气泡验证</span>
        <el-button @click="addStore()" class="list-btn-w  iconfont icon-ic-new">{{
          $t('demo.addButton')
        }}</el-button>
      </template>

      <template slot="main"> </template>
    </list-panel>

    <el-dialog :title="title" :visible="addStoreVisible" width="40%" :before-close="closeAddStore">
      <el-form
        label-position="top"
        :model="storeForm"
        label-width="80px"
        :inline="true"
        :rules="rules"
        ref="storeRules"
      >
        <el-form-item class="full" prop="num" ref="item">
          <template slot="label">
            <span class="label-tit">
              采集站编号
            </span>
            <span class="label-sub-tit">您真实姓名，用于核查信息</span>
          </template>
          <validPopover :prop="this.numRules" :message="this.message" :value="storeForm.num">
            <template slot="reference-area">
              <el-input v-model="storeForm.num" ref="" />
            </template>
          </validPopover>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="closeAddStore">取消</el-button>
        <el-button type="primary" @click="sbumitStore">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import validPopover from '@/components/validPopover'
export default {
  data() {
    var validateRule = (rule, value, callback, source, options) => {
      var errors = []
      let reg2 = /^[a-z0-9_\-]*$/
      let reg3 = /^([a-z0-9]([\s\S]*[a-z0-9])?)?$/
      if (!value) {
        if (rule.required === true) {
        }
      } else {
        if (value.length < 4 || value.length > 64) {
          errors.push('长度为3-64个字符')
        }
        if (!reg3.test(value)) {
          errors.push('只能以小写字母和数字开头和结尾')
        }
        if (!reg2.test(value)) {
          errors.push('仅支持小写字母、数字、连字符( - )和下划线( _ )')
        }
        callback(errors)
      }
    }
    return {
      addStoreVisible: false,
      storeForm: {
        num: ''
      },
      rules: {
        num: [
          { required: true, message: '请输入活动名称', trigger: 'blur' },
          { validator: validateRule, trigger: 'blur' }
        ]
      },
      title: '',
      numRules: [{ validator: validateRule }],
      message: [
        { msg: '长度为3-64个字符', state: null },
        { msg: '仅支持小写字母、数字、连字符( - )和下划线( _ )', state: null },
        { msg: '只能以小写字母和数字开头和结尾', state: null }
      ]
    }
  },
  components: {
    validPopover
  },
  mounted() {},
  computed: {},
  methods: {
    addStore() {
      this.openEditDialog(this.$t('common.add'))
    },
    openEditDialog(value) {
      this.title = value
      this.addStoreVisible = true
    },
    closeAddStore() {
      this.$refs.storeRules.resetFields()
      this.addStoreVisible = false
    },
    sbumitStore() {
      this.$refs.storeRules.validate(valid => {
        if (valid) {
          console.log('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
      // this.closeAddStore()
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/styles/common.scss';
</style>
