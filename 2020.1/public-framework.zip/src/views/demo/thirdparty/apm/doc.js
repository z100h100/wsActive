const doc = `// 在 main.js 中引入以下代码
; (function (c, b, d, a) {
  var js = b.createElement('script')
  c[a] || (c[a] = {})
  c[a].config = {
    pid: 'gg-cfront',
    imgUrl: '/monitor/frontEnd/info/collect?',
    enableLinkTrace: true,
    sendResource: true,
    enableSPA: true,
    useFmp: true
  }
  js.setAttribute('crossorigin', '')
  js.setAttribute('src', d)
  b.body.insertBefore(js, b.body.firstChild)
})(window, document, 'static/apm/report.js', '__bl')

// 上述代码中配置说明如下
// pid           海豚平台项目标识
// imgUrl         arms 信息上报地址
// enableLinkTrace   设置为 true 后，将进行前后端链路追踪
// sendResource     设置为 true 后，在页面onload时会上报页面加载的静态资源
// enableSPA       设置为 true 后,适用于SPA应用场景，会监听页面事件并自动上报PV
// useFmp         设置为 true 后，将采集首屏FMP数据

// ps: 配置上报接口时请确保不会存在跨域问题 

// 引入上报接口后诸如按钮、链接、输入框等点击事件会自动上报，但有的时候需要根据业务上报自定义的信息配置如下：
// 方式一：
<el-button 
  type="primary" 
  data-track-action="CustomEvent" 
  data-track-category="ApmSearch" 
  data-track-label="label" 
  data-track-value="value" 
  icon="iconfont icon-ic-search" 
  @click="handleSearch()"
  >{{ $t('common.searchButton') }}
</el-button>
// data-track-action     CustomEvent（默认）
// data-track-category    事件类型配置
// data-track-label      事件 label
// data-track-value      事件 value
// 方式二：
window.__bl.uaTool.track({
  action: 'CustomEvent',
  category: 'ApmDetail',
  label: 'label',
  value: 'value'
})
// action、category、label、value 设置与方式一相同

// 使用 track - ignore 属性添加到元素标签上可以忽略 sdk 上报
<el-button @click="reset" track-ignore="1">{{ $t('common.resetButton') }}</el-button>
`

export default doc
