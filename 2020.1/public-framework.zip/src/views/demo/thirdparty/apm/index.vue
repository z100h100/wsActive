<template>
  <div class="wrap">
    <div class="card-list split horizontal">
      <div class="cart-item" style="width:40%;border-right:solid 1px #eceef3;">
        <div class="cart-tit">接入说明</div>
        <div class="cart-con">
          <div class="code-wrapper">
            <code-mirror
              :outForm="outForm"
              ref="code"
              :readOnlyFlag="true"
              v-on:update:config="handleUpdateConfig"
              style="height: calc(100vh - 250px);"
            />
          </div>
        </div>
      </div>
      <div class="cart-item" style="width:60%;">
        <div class="cart-tit">实例演示</div>
        <div class="cart-con">
          <search-panel :searchCriteria="searchForm">
            <template slot="form-area">
              <el-form-item label="host:" label-width="60px">
                <el-input
                  v-model="searchForm.host"
                  @keyup.enter.native="getList()"
                  :placeholder="$t('demo.namePlaceholder')"
                ></el-input>
              </el-form-item>
              <el-form-item label="port:" label-width="60px">
                <el-input
                  v-model="searchForm.port"
                  @keyup.enter.native="getList()"
                  :placeholder="$t('demo.namePlaceholder')"
                ></el-input>
              </el-form-item>
            </template>
            <template slot="oper-area">
              <el-button
                type="primary"
                data-track-action="CustomEvent"
                data-track-category="ApmSearch"
                data-track-label="label"
                data-track-value="value"
                icon="iconfont icon-ic-search"
                @click="handleSearch()"
                >{{ $t('common.searchButton') }}
              </el-button>
              <el-button @click="reset" track-ignore="1">{{ $t('common.resetButton') }}</el-button>
            </template>
          </search-panel>
          <list-panel :showHead="false">
            <template slot="main">
              <el-table
                stripe
                ref="multipleTable"
                :data="list"
                tooltip-effect="dark"
                show-overflow-tooltip="true"
                :highlight-current-row="true"
              >
                <el-table-column prop="ID" label="ID">
                  <template slot-scope="scope">
                    {{ scope.row.serialNumber ? scope.row.serialNumber : '—' }}
                  </template>
                </el-table-column>
                <el-table-column prop="probeType" label="检查项">
                  <template slot-scope="scope">
                    {{ scope.row.probeType ? scope.row.probeType : '—' }}
                  </template>
                </el-table-column>
                <el-table-column prop="probeLevel" label="检查结果">
                  <template slot-scope="scope">
                    <span :class="classMap[scope.row.probeLevel]">
                      {{ scope.row.probeLevel ? scope.row.probeLevel : '—' }}</span
                    >
                  </template>
                </el-table-column>
                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <a href="javascript:;" @click="handleDetail(scope.row)">详情</a>
                  </template>
                </el-table-column>
              </el-table>
            </template>
          </list-panel>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import codeMirror from '@/components/CodeMirror/code'
import doc from './doc'
export default {
  name: 'APM-DEMO',
  components: {
    codeMirror
  },
  data() {
    return {
      searchForm: {
        host: '',
        port: ''
      },
      list: [
        {
          serialNumber: 1,
          probeType: 'GREEN'
        },
        {
          serialNumber: 1,
          probeType: 'YELLOW'
        }
      ],
      rules: {
        host: [{ required: true, message: '请输入IP地址', trigger: 'blur' }],
        port: [{ required: true, message: '请输入端口', trigger: 'blur' }]
      },
      classMap: {
        GREEN: 'green',
        YELLOW: 'yellow',
        RED: 'red'
      },
      outForm: {
        activeConfig: doc
      }
    }
  },
  methods: {
    handleSearch() {
      this.getList()
    },
    getList() {
      this.list.push({
        serialNumber: 1,
        probeType: 'RED'
      })
    },
    handleDetail(row) {
      // 自定义事件
      window.__bl.uaTool.track({
        action: 'CustomEvent',
        category: 'ApmDetail',
        label: 'label',
        value: 'value'
      })
    },
    handleUpdateConfig(value) {
      this.outForm.activeConfig = value
    },
    reset() {
      this.searchForm = {
        host: '',
        port: ''
      }
      this.list = [
        {
          serialNumber: 1,
          probeType: 'GREEN'
        },
        {
          serialNumber: 1,
          probeType: 'YELLOW'
        }
      ]
    }
  }
}
</script>
<style lang="scss" scoped>
.wrap {
  height: calc(100vh - 80px);
  background-color: #fff;
}

.cart-item {
  overflow-y: auto;
  height: calc(100vh - 80px) !important;
  /deep/ .el-form-item {
    width: 33% !important;
    .el-form-item__label {
      line-height: 32px !important;
    }
  }
}
.green {
  color: #0dcf5f;
}

.yellow {
  color: #fcae19;
}

.red {
  color: #fc5555;
}
.code-wrapper {
  position: relative;
  border-radius: 4px;
  border: solid 1px #dcdfe6;
  border-left: solid 6px #60a7ef;
  height: calc(100vh - 250px);
}
</style>
