let canvas = document.createElement('canvas')

export default {
  playRate(kmedia, el) {
    self.playRate = 1
    let rates = el.querySelectorAll(`.control-bar .tool-part span`)
    // 添加倍速
    const rateBase = document.createElement('div')
    rateBase.classList.add('beishu')
    rateBase.innerHTML = `1X<i title="倍速" class="iconfont icon-ic-arrow-up-02 i-fontSize"></i>`
    rates[rates.length - 1].childNodes[0].parentNode.insertBefore(
      rateBase,
      rates[rates.length - 1].childNodes[0]
    )
    // 添加videoControl
    let videoControl = el.querySelector(`.control-bar`)
    const videoControlBase = document.createElement('div')
    videoControlBase.style.display = 'none'
    videoControlBase.classList.add('video_control')
    videoControlBase.innerHTML = `<span>
        <span class="control" style="border-top-left-radius:5px;border-top-right-radius:5px;"><p>4X</p></span>
        <span class="control"><p>2X</p></span>
        <span class="control"><p>1X</p></span>
        <span class="control" style="border-bottom-left-radius:5px;border-bottom-right-radius:5px;margin-right:10px;"><p>0.5X</p></span>
      </span>`
    videoControl.appendChild(videoControlBase)
    /**
     * 点击事件：点击播放速率列表中的数值
     */
    let ratesControl = el.querySelectorAll('.video_control .control')
    for (let index = 0, len = ratesControl.length; index < len; index++) {
      ratesControl[index].onclick = function(e) {
        el.querySelector('.video_control').style.display = 'none' // 隐藏播放速率列表
        el.querySelector('.beishu').innerHTML =
          e.target.innerText + '<i class="iconfont icon-ic-arrow-up-02 i-fontSize"></i>' // 速率文本替换为当前点击的数值
        let rate = e.target.innerText.replace('X', '')
        if (rate < 1) {
          kmedia.playbackRate('slow', 1 / rate)
          self.playRate = parseInt(rate)
        } else {
          kmedia.playbackRate('fast', rate)
          self.playRate = parseInt(rate)
        }
      }
    }
    el.querySelector('.beishu').onclick = function(e) {
      let iDom = el.querySelector('.i-fontSize')
      if (iDom.classList.value.indexOf('icon-ic-arrow-up-02') > -1) {
        iDom.classList.replace('icon-ic-arrow-up-02', 'icon-ic-arrow-down')
      } else {
        iDom.classList.replace('icon-ic-arrow-down', 'icon-ic-arrow-up-02')
      }
      let videocontrol = el.querySelector('.video_control')
      if (videocontrol.style.display === 'inline-block') {
        videocontrol.style.display = 'none'
      } else {
        videocontrol.style.display = 'inline-block'
      }
    }
  },
  // 截图
  snapshot(instance, el) {
    let elements = el.querySelectorAll(` .control-bar .tool-part span`)
    let video = el.getElementsByTagName('video')[0]
    const $snapshot = document.createElement('i')
    $snapshot.className = 'iconfont icon-ic-camera'
    $snapshot.title = '截图'
    elements[0].appendChild($snapshot)
    $snapshot.onclick = function() {
      canvas = document.createElement('canvas')
      let canvasCtx = canvas.getContext('2d')
      let videoWidth = video.videoWidth
      let videoHeight = video.videoHeight
      canvas.width = videoWidth
      canvas.height = videoHeight
      canvasCtx.drawImage(video, 0, 0, videoWidth, videoHeight, 0, 0, videoWidth, videoHeight)
      downloadFile(canvas.toDataURL('image/png'), 'screenshot')
    }
  },
  // 上一个、下一个视频切换
  addLastAndNextButton(el, lastCallback, nextCallback) {
    // 只有左右箭头不存在时才添加
    if (el.querySelector('.km-container .km-cs-main .km-cs .icon-s-zuojiantou') === null) {
      const playLast = document.createElement('div')
      playLast.classList = 'km-slot-item km-cs-tooltip slotLeft'
      playLast.setAttribute('data-title', '上一个')
      playLast.innerHTML = `<span data-title="上一个" class="icon iconfont icon-s-zuojiantou km-tooltip" style="font-size: 17px"></span>`
      // 添加下一个按钮
      const playNext = document.createElement('div')
      playNext.classList = 'km-slot-item km-cs-tooltip slotLeft'
      playNext.setAttribute('data-title', '下一个')
      playNext.innerHTML = `<span data-title="下一个" class="icon iconfont icon-ic-forward km-tooltip" style="font-size: 17px"></span>`
      let controlBar = el.querySelector('.km-container .km-cs-main .km-cs')
      let frameBack = el.querySelector('.km-container .km-cs-main .km-cs .icon-media_frameback')
        .parentElement
      let frameIn = el.querySelector('.km-container .km-cs-main .km-cs .km-timings').parentElement
      controlBar.insertBefore(playLast, frameBack)
      controlBar.insertBefore(playNext, frameIn)
      /**
       * 点击事件：点击上一个按钮
       */
      document.querySelector('.icon-s-zuojiantou').addEventListener('click', function() {
        lastCallback()
      })
      /**
       * 点击事件：点击下一个按钮
       */
      document.querySelector('.icon-ic-forward').addEventListener('click', function() {
        nextCallback()
      })
    }
  },
  addFramePlayButton(el, lastCallback, nextCallback) {
    // 添加上一个按钮
    const playLast = document.createElement('div')
    playLast.classList.add('aa')
    playLast.innerHTML = `<i title="上一帧" class="iconfont icon-ic-previous-frame"></i>`
    // 添加下一个按钮
    const playNext = document.createElement('div')
    playNext.classList.add('aa')
    playNext.innerHTML = `<i title="下一帧" class="iconfont icon-ic-next-frame"></i>`
    let centerControl = el.querySelectorAll('.control-bar .tool-part span')[1]
    centerControl.insertBefore(playLast, centerControl.childNodes[0])
    centerControl.appendChild(playNext)
    /**
     * 点击事件：点击上一帧按钮
     */
    document.querySelector('.icon-ic-previous-frame').addEventListener('click', function() {
      lastCallback()
    })
    /**
     * 点击事件：点击下一帧按钮
     */
    document.querySelector('.icon-ic-next-frame').addEventListener('click', function() {
      nextCallback()
    })
  },
  // 视频顺序循环播放按钮
  addLoopPlay(el, defaultLoop, callback) {
    const loopPlay = document.createElement('div')
    loopPlay.classList.add('aa')
    loopPlay.innerHTML = `<i title="单个循环播放" class="iconfont icon-ic-refresh-"></i>`
    let centerControl = el.querySelectorAll('.control-bar .tool-part span')[2]
    centerControl.insertBefore(loopPlay, centerControl.childNodes[0])
    let loopIcon = el.querySelector('.icon-ic-refresh-')
    if (defaultLoop) {
      loopIcon.style.color = '#3B7EEA'
    }
    loopIcon.addEventListener('click', function() {
      let isLoop = callback()
      if (isLoop) {
        loopIcon.style.color = '#3B7EEA'
      } else {
        loopIcon.style.color = ''
      }
    })
  }
}
function downloadFile(content, fileName) {
  let $a = document.createElement('a')
  $a.setAttribute('href', content)
  $a.setAttribute('download', fileName)
  let evObj = document.createEvent('MouseEvents')
  evObj.initMouseEvent(
    'click',
    false,
    false,
    window,
    0,
    0,
    0,
    0,
    0,
    true,
    false,
    true,
    false,
    0,
    null
  )
  $a.dispatchEvent(evObj)
}
