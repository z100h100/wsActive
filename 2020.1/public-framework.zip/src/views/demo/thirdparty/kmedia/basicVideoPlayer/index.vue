<template>
  <div class="basic-video-player-wrapper">
    <div ref="videoPlayer" class="basic-video-player" :class="playerClass"></div>
    <div class="play-error" v-if="playError">
      <!--    <div class="play-error">-->
      <i
        v-if="topControl && topControl.indexOf('close') > -1"
        @click="closeWindow"
        title="关闭播放器"
        class="iconfont icon-ic-delete1"
      ></i>
      <div class="wrap">
        <div>
          <!--          {{errorCode[playError.errCode] || playError.errMsg|| '播放失败'}}-->
          {{ videoType === 'liveStream' ? '直播已断开' : '播放失败' }}
        </div>
        <div>
          <span>错误码：{{ playError.errCode || '无' }}&nbsp&nbsp&nbsp</span>
          <span @click="refreshPlayer" class="refresh">刷新</span>
        </div>
      </div>
    </div>
    <div class="top-tool-bar" v-else>
      <!--    <div class="top-tool-bar">-->
      <div class="left-part">
        <i class="iconfont icon-ic-zfy"></i>
        <span v-if="videoType === 'liveStream'" class="play-type-tip">{{
          $t('videoPlayer.IS_PLAY_INLINE_VIDEO')
        }}</span>
        <span v-else-if="fileType === 'VIDEO'" class="play-type-tip">{{
          $t('videoPlayer.HISTORY_VIDEO')
        }}</span>
        <span v-else-if="fileType === 'AUDIO'" class="play-type-tip">{{
          $t('videoPlayer.HISTORY_AUDIO')
        }}</span>
      </div>
      <div class="right-part">
        <!--语音对讲,配置后仅直播生效-->
        <template
          v-if="videoType === 'liveStream' && topControl && topControl.indexOf('voice') > -1"
        >
          <i
            v-if="isMicrophone"
            @click="closeMicrophone"
            title="正在语音对讲"
            class="iconfont icon-ic-audio"
          ></i>
          <i
            v-if="!isMicrophone"
            @click="openMicrophone"
            title="语音对讲关闭"
            class="iconfont icon-ic-microphone"
          ></i>
        </template>
        <!--直播、历史视频切换-->
        <template v-if="topControl && topControl.indexOf('switch') > -1">
          <i
            v-if="videoType === 'liveStream'"
            @click="switchHistoryVideo"
            title="历史视频"
            class="iconfont icon-ic-history-video"
          ></i>
          <i v-else @click="switchOnlineVideo" title="直播" class="iconfont icon-ic-livevideo"></i>
        </template>
        <!--下载为通用功能，无需topControl控制-->
        <i
          v-if="videoType !== 'liveStream'"
          @click="download"
          title="视频下载"
          class="iconfont icon-ic-loading"
        ></i>
        <!--关闭窗口，目前只有首页多路播放使用-->
        <i
          v-if="topControl && topControl.indexOf('close') > -1"
          @click="closeWindow"
          title="关闭播放器"
          class="iconfont icon-ic-delete1"
        ></i>
      </div>
    </div>
  </div>
</template>

<script>
import kmediaCustom from './basicVideoTools'
import { errorCode } from './errorCode'
export default {
  name: 'basicVideoPlay',
  props: {
    playerClass: String,
    videoType: {
      // singleFile, multipleFile, liveStream, singleFileArray
      default: 'singleFile'
    },
    videoData: Object,
    topControl: String,
    // 是否默认开启反向语音
    microphone: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      errorCode,
      player: null,
      isSingleLoopPlay: false,
      // 单文件数组情况下，控制播放哪一个视频
      defaultIndex: this.videoData.defaultIndex || 0,
      fileType: '',
      isMicrophone: false,
      playError: null,
      refreshTimer: null
    }
  },
  mounted() {
    this.loadMapScript()
  },
  watch: {
    videoData: {
      handler(val, oldVal) {
        this.refreshPlayer()
      },
      deep: true
    }
  },
  computed: {},
  beforeDestroy() {
    this.closeMedia()
    this.removeMapScript()
  },
  methods: {
    loadMapScript() {
      let x = document.body.getElementsByTagName('script')[0]
      // load kmedia-service global config
      let kmediaService = document.getElementById('kmedia-service')
      if (kmediaService) {
        document.body.removeChild(kmediaService)
      }
      let kmediaServiceScript = document.createElement('script')
      kmediaServiceScript.id = 'kmedia-service'
      kmediaServiceScript.async = true
      kmediaServiceScript.src = 'static/kmedia/kmedia-service.js'
      x.parentNode.insertBefore(kmediaServiceScript, x)
      // load kmedia.js
      let kmediaScript = document.getElementById('kmedia-script')
      if (kmediaScript) {
        document.body.removeChild(kmediaScript)
      }
      let script = document.createElement('script')
      script.id = 'kmedia-script'
      script.async = true
      script.src = 'static/kmedia/kmedia_v2.2.2.js'
      x.parentNode.insertBefore(script, x)
      // onload不兼容IE 如果需要兼容IE 得兼容 onreadystatechange 事件
      script.onload = () => {
        this.initPlayer()
      }
    },
    removeMapScript() {
      let kmediaServiceScript = document.getElementById('kmedia-service')
      if (kmediaServiceScript) {
        document.body.removeChild(kmediaServiceScript)
      }
      let kmediaScript = document.getElementById('kmedia-script')
      if (kmediaScript) {
        document.body.removeChild(kmediaScript)
      }
    },
    play() {
      this.player.play()
    },
    handleError(e) {
      console.log('流媒体播放错误', e)
      let tipCode = [13, 4002, 3002]
      // 三方告知 错误 30013 重新刷新
      if (e.errCode === 30013) {
        if (this.refreshTimer) return
        this.refreshTimer = setTimeout(() => {
          this.refreshTimer = null
          this.refreshPlayer()
        }, 1500)
      }
      if (tipCode.some(code => code === e.errCode)) this.playError = e
    },
    initPlayer() {
      this.playError = null
      // let videoPlayer = this.$refs.videoPlayer
      let config = this.getVideoConfig()
      console.log(config)
      this.player = new window.KMedia(config)
      this.player.error(this.handleError)
      if (this.player) {
        this.player.volume(50)
      }
      if (this.player && this.videoType === 'liveStream' && this.microphone) {
        this.openMicrophone()
      }
      this.player.error(() => {
        console.error('load error')
      })
      this.player.ended(() => {
        if (this.videoType === 'singleFileArray' && !this.player.loop()) {
          this.autoPlayNext()
        }
      })
      // 单文件、多文件拼接、多文件数组添加跨域头，截图功能必须添加否则canvas报错
      // if (((this.videoType === 'multipleFile' || this.videoType === 'singleFile') && !this.videoData.storageLocation) ||
      //   (this.videoType === 'singleFileArray' && !this.videoData.videoUrls[this.defaultIndex].storageLocation)) {
      //   let video = document.getElementsByTagName('video')[0]
      //   video.setAttribute('crossOrigin', 'Anonymous')
      // }
    },
    refreshPlayer() {
      this.playError = null
      let srcConfig = {}
      if (this.videoType === 'singleFile') {
        srcConfig = {
          src: this.videoData.videoUrl,
          type: window.KConfig.FILE
        }
      } else if (this.videoType === 'multipleFile') {
        srcConfig = {
          src: this.videoData.list[0].url,
          type: window.KConfig.FILE,
          mode: window.KConfig.MERGE,
          videoUrls: this.videoData.list
        }
      } else if (this.videoType === 'liveStream') {
        srcConfig = {
          src: this.videoData.gbId,
          type: 'liveStreaming'
        }
      } else if (this.videoType === 'singleFileArray') {
        srcConfig = {
          src: this.videoData.videoUrls[this.defaultIndex].url || 'http',
          type: window.KConfig.FILE
        }
      }
      // 内部释放资源，重新加载新的资源
      this.player.src(srcConfig)
    },
    getVideoConfig() {
      let config = {
        // serviceUrl: 'static/kmedia/kmedia-config.json',
        selector: '.' + this.playerClass, // 必填项，用户容器区域的css选择器
        theme: window.KConfig.BLUETHEME,
        // control: window.KConfig.BASIC,
        // tools: [window.KConfig.FRMAEBACKPLAY, window.KConfig.FRMAEFORWARDPLAY]
        loading: window.KConfig.ROTATELOADING,
        tools: {
          slotLeft: [
            window.KConfig.FRMAEBACKPLAY,
            window.KConfig.PLAY,
            window.KConfig.FRMAEFORWARDPLAY
          ],
          slotCenter: [window.KConfig.TIMEINGS],
          slotRight: [
            window.KConfig.FASTPLAY,
            window.KConfig.IMGSTRENGTH,
            window.KConfig.SNAPSHOT,
            window.KConfig.CIRCLEPLAY,
            window.KConfig.VOLUME,
            window.KConfig.FULLSCREEN
          ]
        },
        mediaInfo: {
          file: {},
          liveStreaming: {},
          nonLiveStreaming: {}
        }
      }
      if (this.videoType === 'singleFile') {
        config = this.getSingleFileConfig(config)
      } else if (this.videoType === 'multipleFile') {
        config = this.getMultipleFileConfig(config)
      } else if (this.videoType === 'liveStream') {
        config = this.getLiveStreamConfig(config)
      } else if (this.videoType === 'singleFileArray') {
        config = this.getSingleFileArrayConfig(config)
      }
      return config
    },
    // 单文件播放
    getSingleFileConfig(config) {
      // let videoPlayer = this.$refs.videoPlayer
      config.playType = window.KConfig.FILE
      config.progressDisplayTime = true
      // 单个视频url为空
      config.mediaUrl = this.videoData.videoUrl || 'http'
      config.mediaType = 'video'
      this.fileType = this.getFileType(this.videoData.videoUrl)
      config.onload = () => {
        // 添加截图功能，采集站不可截图
        // if (!this.videoData.storageLocation) {
        //   kmediaCustom.snapshot(this.player, videoPlayer)
        // }
        // 添加循环播放功能
        // kmediaCustom.addLoopPlay(videoPlayer, this.isSingleLoopPlay, this.handleLoopPlay)
        // 添加倍速功能
        // kmediaCustom.playRate(this.player, videoPlayer)
        // 添加逐帧播放功能
        // kmediaCustom.addFramePlayButton(videoPlayer, this.playLastFrame, this.playNextFrame)
        this.play()
      }
      return config
    },
    // 多文件拼接播放
    getMultipleFileConfig(config) {
      // let videoPlayer = this.$refs.videoPlayer
      if (this.videoData.list.length === 1) {
        config.playType = window.KConfig.FILE
        config.progressDisplayTime = true
        config.mediaUrl = this.videoData.list[0].url
      } else {
        config.playType = window.KConfig.FILE
        config.progressDisplayTime = true
        config.mediaUrl = this.videoData.list[0].url
        config.mediaInfo = {
          file: {
            mode: window.KConfig.MERGE,
            videoUrls: this.videoData.list
          }
        }
        config.tools = {
          slotLeft: [
            window.KConfig.FRMAEBACKPLAY,
            window.KConfig.PLAY,
            window.KConfig.FRMAEFORWARDPLAY
          ],
          slotCenter: [window.KConfig.TIMEINGS],
          slotRight: [
            window.KConfig.FASTPLAY,
            window.KConfig.IMGSTRENGTH,
            window.KConfig.SNAPSHOT,
            window.KConfig.VOLUME,
            window.KConfig.FULLSCREEN
          ]
        }
      }
      this.fileType = this.getFileType(this.videoData.list[0].url)
      config.onload = () => {
        this.play()
      }
      return config
    },
    // 直播
    getLiveStreamConfig(config) {
      config.playType = window.KConfig.LIVESTREAMING
      config.mediaType = window.KConfig.VIDEO
      config.realtime = window.KConfig.ALL
      // config.mediaUrl = this.videoData.videoUrl
      config.mediaInfo = {
        liveStreaming: {
          devId: this.videoData.gbId,
          stunService: window.Kservice.stunService || ''
        }
      }
      // 是否开启语音对讲
      // config.microphone = this.videoData.microphone ? this.videoData.microphone : false
      config.mute = this.videoData.mute ? this.videoData.mute : false
      config.realtime = window.KConfig.ALL
      config.tools = {
        slotLeft: [window.KConfig.PLAY, window.KConfig.TIMEINGS],
        slotCenter: [],
        slotRight: [
          window.KConfig.IMGSTRENGTH,
          window.KConfig.SNAPSHOT,
          window.KConfig.VOLUME,
          window.KConfig.FULLSCREEN
        ]
      }
      return config
    },
    // 单文件列表，目前只有视图资源使用，实现功能，1、切换上一个、下一个视频
    getSingleFileArrayConfig(config) {
      let videoPlayer = this.$refs.videoPlayer
      config.playType = window.KConfig.FILE
      config.progressDisplayTime = true
      // 单个视频url为空
      config.mediaUrl = this.videoData.videoUrls[this.defaultIndex].url || 'http'
      config.mediaType = this.getMediaType(this.videoData.videoUrls[this.defaultIndex].url)
      this.fileType = this.getFileType(this.videoData.videoUrls[this.defaultIndex].url)
      config.onload = () => {
        // 添加上一个下一个功能
        if (this.videoData.videoUrls && this.videoData.videoUrls.length > 1) {
          kmediaCustom.addLastAndNextButton(videoPlayer, this.playLastVideo, this.playNextVideo)
        }
        this.addIconToolTip()
        this.play()
      }
      return config
    },
    // 点击上一个按钮
    playLastVideo() {
      if (this.defaultIndex > 0) {
        this.defaultIndex = this.defaultIndex - 1
        this.refreshPlayer()
      } else {
        this.$message.warning(this.$t('videoPlayer.THE_FIRST_ONE'))
      }
    },
    // 点击下一个按钮
    playNextVideo() {
      if (this.defaultIndex < this.videoData.videoUrls.length - 1) {
        this.defaultIndex = this.defaultIndex + 1
        this.refreshPlayer()
      } else {
        this.$message.warning(this.$t('videoPlayer.THE_LAST_ONE'))
      }
    },
    // 自动循环播放
    autoPlayNext() {
      if (this.defaultIndex < this.videoData.videoUrls.length - 1) {
        this.defaultIndex = this.defaultIndex + 1
        this.refreshPlayer()
      }
    },
    download() {
      let video = this.$el.getElementsByTagName('video')[0]
      let url = video.currentSrc
      this.downloadFile(
        url,
        url
          .split('?')[0]
          .split('/')
          .reverse()[0]
      )
    },
    getMediaType(url) {
      let fileExt = this.getFileExtFromFileName(url)
      if (fileExt === 'm4a') {
        return window.KConfig.AUDIO
      } else {
        return window.KConfig.VIDEO
      }
    },
    addIconToolTip() {
      let icons = this.$el.querySelectorAll('.controls-main .controls .control-item')
      icons.forEach(icon => {
        if (!icon.dataset.title) {
          if (icon.children[0].className.indexOf('icon-media_voice') > -1) {
            icon.setAttribute('data-title', this.$t('videoPlayer.MEDIA_VOLUME'))
          } else if (
            icon.children[0].className.indexOf('icon-media_play') > -1 ||
            icon.children[0].className.indexOf('icon-media_stop') > -1
          ) {
            icon.setAttribute('data-title', this.$t('videoPlayer.MEDIA_PLAY'))
          } else if (icon.children[0].className.indexOf('icon-media_loop') > -1) {
            icon.setAttribute('data-title', this.$t('videoPlayer.MEDIA_LOOP'))
          }
        }
      })
    },
    getFileType(url) {
      let fileExt = this.getFileExtFromFileName(url)
      if (fileExt === 'm4a') {
        return 'AUDIO'
      } else {
        return 'VIDEO'
      }
    },
    openMicrophone() {
      this.isMicrophone = true
      this.player.startVoiceCall()
    },
    closeMicrophone() {
      this.isMicrophone = false
      this.player.stopVoiceCall()
    },
    closeMedia() {
      if (this.player) {
        if (this.player.pause) {
          this.player.pause()
        }
        let el = this.$el.querySelector('video') || this.$el.querySelector('audio')
        el.src = null
        this.player.closeMedia()
        this.player = null
        this.playError = null
      }
    },
    closeWindow() {
      this.$emit('closeVideoWindow', this.videoData)
      this.closeMedia()
    },
    switchOnlineVideo() {
      this.$emit('switchOnlineVideo', this.videoData)
    },
    switchHistoryVideo() {
      this.$emit('switchHistoryVideo', this.videoData)
    },
    getFileExtFromFileName(fileName) {
      if (fileName) {
        return fileName
          .split('.')
          .splice(-1)
          .join('')
          .toLowerCase()
      }
      return ''
    },
    downloadFile(fileName, content) {
      let $a = document.createElement('a')
      $a.setAttribute('href', fileName)
      $a.setAttribute('download', content)
      let evObj = document.createEvent('MouseEvents')
      evObj.initMouseEvent(
        'click',
        false,
        false,
        window,
        0,
        0,
        0,
        0,
        0,
        true,
        false,
        true,
        false,
        0,
        null
      )
      $a.dispatchEvent(evObj)
    }
  }
}
</script>

<style lang="scss">
.basic-video-player-wrapper {
  width: 100%;
  position: relative;
  min-height: 350px;
  height: 100%;
  .play-error {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0px;
    left: 0px;
    color: white;
    background: black;
    .icon-ic-delete1 {
      position: absolute;
      top: 8px;
      right: 10px;
      cursor: pointer;
    }
    .wrap {
      width: 200px;
      height: 60px;
      position: absolute;
      left: 50%;
      top: 45%;
      transform: translate(-100px, -30px);
      > div {
        width: 100%;
        height: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        .refresh {
          color: #fca802;
          cursor: pointer;
        }
      }
    }
  }
  .basic-video-player {
    height: 100%;
    .km-container .progress_current {
      background-color: #47d076 !important;
    }
    .km-container .control-bar .range-vol > div {
      background-color: #47d076 !important;
    }
    .begin-time {
      font-size: 0.6rem;
      margin-right: 0.5rem;
      color: #fff;
      float: left;
    }
    // 倍速
    .progress-part:after {
      content: ' ';
      display: block;
      clear: both;
      height: 0;
    }
    .beishu {
      font-size: 14px;
      width: 62px;
      height: 20px;
      border: 1px solid #999999;
      border-radius: 87.41px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #ffffff;
      cursor: pointer;
      margin: 0 0.5rem;
      &:hover {
        background: #ffffff;
        color: #47d076;
        letter-spacing: 0;
      }
    }
    .i-fontSize {
      font-size: 10px !important;
      margin: 0 !important;
    }
    .video_control {
      position: absolute;
      height: 100px;
      width: 68px;
      right: 70px;
      bottom: 100px;
      display: none;
      z-index: 66;
      border-radius: 5px;
    }
    .video_control .control {
      display: inline-block;
      color: white;
      background: rgba(0, 0, 0, 0.6);
      width: 70px;
      height: 26px;
      text-align: center;
      padding-top: 10px;
    }

    .toolbar_contanier .beishu {
      color: white;
      font-size: 14px;
      position: relative;
      border-radius: 15px;
      padding: 5px 10px;
      display: inline-block;
      width: 50px;
      margin: 0 0.5rem;
    }

    .video_control .control i {
      font-size: 20px;
    }
    .video_control .control p {
      font-size: 14px;
    }

    .video_control > span {
      align-self: center;
    }

    // 截图
    .icon-ic-cut {
      font-size: 20px;
    }
  }
  .top-tool-bar {
    height: 36px;
    width: 100%;
    background-color: rgba(0, 0, 0, 0.3);
    position: absolute;
    z-index: 1000;
    top: 0;
    left: 0;
    display: none;
    align-items: center;
    flex-direction: row;
    justify-content: space-between;
    //padding: 0 10px;
    .left-part {
      .icon-ic-zfy {
        color: #ffaa00;
        font-size: 16px;
        margin-left: 10px;
      }
      .play-type-tip {
        font-family: PingFangSC-Medium;
        font-size: 12.7px;
        color: #ffffff;
        letter-spacing: 0.91px;
      }
    }
    .right-part {
      .iconfont {
        color: #ffffff;
        font-size: 18px;
        margin-right: 10px;
        cursor: pointer;
      }
      .icon-ic-microphone {
        color: #fb4747;
      }
    }
  }
  &:hover .top-tool-bar {
    display: flex;
  }
}

// 复写icon
.km-container .controls-main .controls i {
  font-family: 'iconfont' !important;
  font-size: 22px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  &.icon-media_decrease,
  &.icon-media_increase {
    display: none;
  }
  &.icon-media_fullscreen:before {
    content: '\eb4d';
  }
  &.icon-media_exit:before {
    content: '\eb4f';
  }
  &.icon-media_stop:before {
    content: '\eb50';
  }
  &.icon-media_play:before {
    content: '\eb51';
  }
  &.icon-media_frameback:before {
    content: '\ede5';
  }
  &.icon-media_framein:before {
    content: '\ede3';
  }
  &.icon-media_voice:before {
    content: '\efe3';
  }
  &.icon-media_novoice:before {
    content: '\efe2';
  }
  &.icon-media_screenshot:before {
    content: '\efeb';
  }
  &.icon-media_imageenhancem1:before {
    content: '\efea';
  }
  &.icon-media_loop:before {
    content: '\eb53';
  }
}

// 控制controls布局
.km-container .controls-main .controls {
  .slot-left {
    justify-content: flex-start !important;
    width: auto !important;
    .control-item {
      padding-left: 10px;
    }
  }
  .slot-center {
    justify-content: flex-start !important;
    width: 50% !important;
  }
  .slot-right {
    justify-content: flex-end !important;
    width: 50% !important;
    .control-item {
      padding-right: 10px;
    }
  }
}

.video-title {
  height: 30px;
  line-height: 30px;
  background: #000000;
  color: #ffffff;
  padding-left: 5px;
}

.km-app-container .theme_blue .progress-display-view .display-part .content {
  width: max-content;
}
</style>
