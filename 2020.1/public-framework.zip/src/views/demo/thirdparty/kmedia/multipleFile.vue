<template>
  <div class="multiple-file-video-player">
    <div class="code-mirror" v-if="!isCollapsed">
      <code-mirror
        :outForm="outForm"
        :outTips="outForm.tips"
        ref="code"
        v-on:update:config="handleUpdateConfig"
      />
    </div>
    <img
      v-if="isCollapsed"
      src="@/assets/images/collapsed-btn.png"
      class="collapsed-btn"
      @click="handleCollapse"
    />
    <img v-else src="@/assets/images/opened-btn.png" class="opened-btn" @click="handleCollapse" />
    <div class="video-player">
      <basic-video-player
        ref="mapVideoPlayer"
        :video-type="dataSource.videoType"
        :video-data="dataSource.videoData"
        player-class="map-video-player"
      >
      </basic-video-player>
    </div>
  </div>
</template>

<script>
import BasicVideoPlayer from './basicVideoPlayer/index'
import CodeMirror from '@/components/CodeMirror/code'
export default {
  components: {
    BasicVideoPlayer,
    CodeMirror
  },
  data() {
    return {
      dataSource: {
        videoType: 'multipleFile',
        videoData: {
          list: [
            {
              url: './static/kmedia/video2.mp4',
              duration: 60,
              beginTime: '',
              endTime: ''
            },
            {
              url: './static/kmedia/video1.mp4',
              duration: 60,
              beginTime: '',
              endTime: ''
            }
          ]
        }
      },
      isCollapsed: false,
      outForm: {
        activeConfig:
          '<template>\n' +
          '  <div class="video-player">\n' +
          '    <basic-video-player\n' +
          '      ref="mapVideoPlayer"\n' +
          '      :video-type="dataSource.videoType"\n' +
          '      :video-data="dataSource.videoData"\n' +
          '      player-class="map-video-player"\n' +
          '    >\n' +
          '    </basic-video-player>\n' +
          '  </div>\n' +
          '</template>\n' +
          '\n' +
          "import BasicVideoPlayer from './basicVideoPlayer/index'\n" +
          'export default {\n' +
          '  components: {\n' +
          '    BasicVideoPlayer\n' +
          '  },\n' +
          '  data() {\n' +
          '    return {\n' +
          '      dataSource: {\n' +
          "        videoType: 'multipleFile',\n" +
          '        videoData: {\n' +
          '          list: [\n' +
          '            {\n' +
          "              url: './static/kmedia/video2.mp4',\n" +
          '              duration: 60,\n' +
          "              beginTime: '',\n" +
          "              endTime: ''\n" +
          '            },\n' +
          '            {\n' +
          "              url: './static/kmedia/video1.mp4',\n" +
          '              duration: 60,\n' +
          "              beginTime: '',\n" +
          "              endTime: ''\n" +
          '            }\n' +
          '          ]\n' +
          '        }\n' +
          '      }\n' +
          '    }\n' +
          '  }\n' +
          '}\n',
        tips: []
      }
    }
  },
  methods: {
    handleUpdateConfig(value) {
      this.outForm.activeConfig = value
    },
    handleCollapse() {
      this.isCollapsed = !this.isCollapsed
    }
  }
}
</script>

<style scoped lang="scss">
.multiple-file-video-player {
  display: flex;
  align-items: flex-start;
  background: #ffffff;
  .code-mirror {
    width: 500px;
    background: #ffffff;
    position: relative;
    height: calc(100vh - 80px);
    border-radius: 4px;
    border-left: solid 6px #60a7ef;
    #cm-resize-frame {
      width: 500px;
      height: calc(100vh - 80px);
      border: solid 1px #dcdfe6;
    }
  }
  .video-player {
    width: calc(100%);
    height: 700px;
    padding: 20px;
    background: #ffffff;
  }
  .collapsed-btn,
  .opened-btn {
    position: absolute;
    z-index: 5;
    height: 75px;
    width: 75px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .collapsed-btn {
    top: 50%;
    left: -20px;
  }
  .opened-btn {
    top: 50%;
    left: 483px;
  }
  .video-player {
    width: calc(100%);
    height: 700px;
    padding: 20px;
    background: #ffffff;
  }
}
</style>
