<template>
  <div id="map" class="map"></div>
</template>

<script>
export default {
  data() {
    return {
      kmap: {},
      kmapConfig: {
        configUrl: 'static/kmap/nwekmap.config.json',
        containerId: 'map',
        zoom: 10,
        style: 'static/kmap/autonavi.json',
        onLoadMap: this.onLoadMap
      }
    }
  },
  mounted() {
    this.loadMapScript()
  },
  beforeDestroy() {
    this.removeMapScript()
  },
  methods: {
    onLoadMap() {
      console.log('onLoadMap')
    },
    loadMapScript() {
      let kmapScript = document.getElementById('new-kmap-script')
      if (kmapScript) {
        document.body.removeChild(kmapScript)
      }
      let script = document.createElement('script')
      script.id = 'new-kmap-script'
      script.async = true
      script.src = 'static/kmap/kmap-service-main-v2.5.0.js'
      let x = document.body.getElementsByTagName('script')[0]
      x.parentNode.insertBefore(script, x)
      // onload不兼容IE 如果需要兼容IE 得兼容 onreadystatechange 事件
      script.onload = () => {
        this.kmap = new window.KMap(this.kmapConfig)
      }
    },
    removeMapScript() {
      let kmapScript = document.getElementById('new-kmap-script')
      if (kmapScript) {
        document.body.removeChild(kmapScript)
      }
    }
  }
}
</script>

<style scoped lang="scss">
.map {
  width: 100%;
  height: calc(100vh - 80px);
}
</style>
