<template>
  <div class="keda-new-map">
    <div class="code-mirror" v-if="!isCollapsed">
      <code-mirror
        :outForm="outForm"
        :outTips="outForm.tips"
        ref="code"
        v-on:update:config="handleUpdateConfig"
      />
    </div>
    <img
      v-if="isCollapsed"
      src="@/assets/images/collapsed-btn.png"
      class="collapsed-btn"
      @click="handleCollapse"
    />
    <img v-else src="@/assets/images/opened-btn.png" class="opened-btn" @click="handleCollapse" />
    <div id="map" class="map">
      <map-tools v-if="mapLoaded" :map="kmap" version="2.5.0"></map-tools>
    </div>
  </div>
</template>

<script>
import MapTools from './mapTools'
import CodeMirror from '@/components/CodeMirror/code'
import { mapGetters } from 'vuex'
export default {
  components: {
    MapTools,
    CodeMirror
  },
  data() {
    return {
      kmap: {},
      kmapConfig: {
        configUrl: 'static/kmap/nwekmap.config.json',
        containerId: 'map',
        zoom: 10,
        onLoadMap: this.onLoadMap
      },
      mapLoaded: false,
      isCollapsed: false,
      outForm: {
        activeConfig:
          '<template>\n' +
          '  <div id="map" class="map">\n' +
          '    <map-tools v-if="mapLoaded" :map="kmap" version="2.5.0"></map-tools>\n' +
          '  </div>\n' +
          '</template>\n' +
          '\n' +
          "import MapTools from './mapTools'\n" +
          'export default {\n' +
          '  components: {\n' +
          '    MapTools\n' +
          '  },\n' +
          '  data() {\n' +
          '    return {\n' +
          '      kmap: {},\n' +
          '      kmapConfig: {\n' +
          "        configUrl: 'static/kmap/nwekmap.config.json',\n" +
          "        containerId: 'map',\n" +
          '        zoom: 10,\n' +
          '        onLoadMap: this.onLoadMap\n' +
          '      },\n' +
          '      mapLoaded: false\n' +
          '    }\n' +
          '  },\n' +
          '  mounted() {\n' +
          '    this.loadMapScript()\n' +
          '  },\n' +
          '  beforeDestroy() {\n' +
          '    this.removeMapScript()\n' +
          '  },\n' +
          '  methods: {\n' +
          '    onLoadMap() {\n' +
          '      this.mapLoaded = true\n' +
          '      this.kmap.history()\n' +
          '    },\n' +
          '    loadMapScript() {\n' +
          "      let kmapScript = document.getElementById('new-kmap-script')\n" +
          '      if (kmapScript) {\n' +
          '        document.body.removeChild(kmapScript)\n' +
          '      }\n' +
          "      let script = document.createElement('script')\n" +
          "      script.id = 'new-kmap-script'\n" +
          '      script.async = true\n' +
          "      script.src = 'static/kmap/kmap-service-main-v2.5.0.js'\n" +
          "      let x = document.body.getElementsByTagName('script')[0]\n" +
          '      x.parentNode.insertBefore(script, x)\n' +
          '      // onload不兼容IE 如果需要兼容IE 得兼容 onreadystatechange 事件\n' +
          '      script.onload = () => {\n' +
          '        this.kmap = new window.KMap(this.kmapConfig)\n' +
          '      }\n' +
          '    },\n' +
          '    removeMapScript() {\n' +
          "      let kmapScript = document.getElementById('new-kmap-script')\n" +
          '      if (kmapScript) {\n' +
          '        document.body.removeChild(kmapScript)\n' +
          '      }\n' +
          '    }\n' +
          '  }\n' +
          '}\n',
        tips: []
      }
    }
  },
  computed: {
    ...mapGetters(['sidebar'])
  },
  watch: {
    sidebar: {
      handler(val, oldval) {
        this.refreshMap()
      },
      deep: true
    }
  },
  mounted() {
    this.loadMapScript()
  },
  beforeDestroy() {
    this.removeMapScript()
    this.kmap.destroy({
      ended: function(res) {
        if (res.status === 10) {
          console.log('地图已销毁')
        }
      }
    })
  },
  methods: {
    onLoadMap() {
      this.mapLoaded = true
      this.kmap.history()
    },
    loadMapScript() {
      let kmapScript = document.getElementById('new-kmap-script')
      if (kmapScript) {
        document.body.removeChild(kmapScript)
      }
      let script = document.createElement('script')
      script.id = 'new-kmap-script'
      script.async = true
      script.src = 'static/kmap/kmap-service-main-v2.5.0.js'
      let x = document.body.getElementsByTagName('script')[0]
      x.parentNode.insertBefore(script, x)
      // onload不兼容IE 如果需要兼容IE 得兼容 onreadystatechange 事件
      script.onload = () => {
        this.kmap = new window.KMap(this.kmapConfig)
      }
    },
    removeMapScript() {
      let kmapScript = document.getElementById('new-kmap-script')
      if (kmapScript) {
        document.body.removeChild(kmapScript)
      }
    },
    handleUpdateConfig(value) {
      this.outForm.activeConfig = value
    },
    handleCollapse() {
      this.isCollapsed = !this.isCollapsed
      this.refreshMap()
    },
    // 地图销毁重绘
    refreshMap() {
      this.kmap.destroy()
      this.kmap = null
      this.kmap = new window.KMap(this.kmapConfig)
    }
  }
}
</script>

<style scoped lang="scss">
.map {
  width: 100vh;
  height: calc(100vh - 80px);
}
.keda-new-map {
  display: flex;
  align-items: flex-start;
  .code-mirror {
    width: 500px;
    background: #ffffff;
    position: relative;
    height: calc(100vh - 80px);
    border-radius: 4px;
    border-left: solid 6px #60a7ef;
    #cm-resize-frame {
      width: 500px;
      height: calc(100vh - 80px);
      border: solid 1px #dcdfe6;
    }
  }
  .collapsed-btn,
  .opened-btn {
    position: absolute;
    z-index: 5;
    height: 75px;
    width: 75px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .collapsed-btn {
    top: 50%;
    left: -20px;
  }
  .opened-btn {
    top: 50%;
    left: 483px;
  }
}
</style>
