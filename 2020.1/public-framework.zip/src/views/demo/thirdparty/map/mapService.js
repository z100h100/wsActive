/* eslint-disable */
// 地图点位定位 自定义图层 图标 偏移量, el为 Object调用创建自定义覆盖物函数，el为DOM时候直接用
export function definedMapAddMarker(map, position, level, el, offset) {
  if (level) {
    map.moveTolnglat({
      type: 2,
      zoom: level,
      point: position
    })
  }
  el = el || 'zfjly-online'
  offset = offset || [-16, -35]
  let element
  // typeof el === 'object' && !isDOM(el)
  if (isDOM(el)) {
    element = el
  } else if (typeof el === 'object') {
    // element = getElementByDevice(map, el, level, true)
  } else {
    element = document.createElement('div')
    element.className = 'map-device-overlay'
    element.innerHTML = `<div class="${el}"></div>`
  }
  return new Promise((resolve, reject) => {
    map.addCustomOverlays({
      data: [
        {
          point: position,
          element: element
        }
      ],
      offset,
      ended: function(res) {
        if (res.status === 10) {
          resolve(res.data)
        }
      }
    })
  })
}

function isDOM(obj) {
  return typeof HTMLElement === 'object'
    ? obj instanceof HTMLElement
    : !!(
        obj &&
        typeof obj === 'object' &&
        (obj.nodeType === 1 || obj.nodeType === 9) &&
        typeof obj.nodeName === 'string'
      )
}
