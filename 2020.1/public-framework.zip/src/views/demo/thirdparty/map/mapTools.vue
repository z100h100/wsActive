<template>
  <div class="map-tool">
    <a id="download" download="jietu.png" href="" style="display: none">下载截图</a>
    <el-button @click="moveUp">上移</el-button>
    <el-button @click="moveDown">下移</el-button>
    <el-button @click="moveLeft">左移</el-button>
    <el-button @click="moveRight">右移</el-button>
    <el-button @click="reset">复位</el-button>
    <el-button @click="zoomIn">放大</el-button>
    <el-button @click="zoomOut">缩小</el-button>
    <el-button @click="forward">前进</el-button>
    <el-button @click="goBack">后退</el-button>
    <el-button @click="eagle">鹰眼</el-button>
    <el-button @click="closeEagle">关闭鹰眼</el-button>
    <el-button @click="scale">比例尺</el-button>
    <el-button @click="closeScale">关闭比例尺</el-button>
    <el-button @click="screenshot">截图</el-button>
    <el-button v-if="version === '2.5.0'" @click="measureDistance">绘图测距</el-button>
    <el-button v-if="version === '2.5.0'" @click="clearMeasureDistance">清除测距</el-button>
    <el-button v-if="version === '2.5.0'" @click="measureArea">绘图测面积</el-button>
    <el-button v-if="version === '2.5.0'" @click="clearMeasureArea">清除测面积</el-button>
    <el-button @click="addMarkers">添加mark</el-button>
    <el-button @click="removeMarkers">移除mark</el-button>
    <el-button @click="addCustomOverlays">添加自定义覆盖物</el-button>
    <el-button @click="removeCustomOverlays">移除自定义覆盖物</el-button>
    <el-button v-if="version === '2.5.0'" @click="addPopup">添加图文窗体</el-button>
    <el-button v-if="version === '2.5.0'" @click="removePopup">移除图文窗体</el-button>
    <el-button v-if="version === '2.5.0'" @click="addLayer">添加地理围栏</el-button>
    <el-button v-if="version === '2.5.0'" @click="removeLayer">移除地理围栏</el-button>
  </div>
</template>

<script>
import police from '@/assets/images/police.png'
import pointImg from '@/assets/images/point.png'
export default {
  props: ['map', 'version'],
  data() {
    return {
      layerIds: [],
      areaLayerIds: [],
      groupName: '',
      overlaysType: '',
      picturePopup: '',
      timer: null,
      LayerId: '',
      layerGroupName: '',
      circleData: {
        type: 'Feature',
        properties: {},
        geometry: {
          type: 'Polygon',
          coordinates: [
            [
              [120.54986306098057, 31.305593163757642],
              [120.55019372554035, 31.305578356955845],
              [120.55052076696109, 31.30553409879078],
              [120.55084060181306, 31.305460874205146],
              [120.5511497256497, 31.30535948552921],
              [120.55144475141464, 31.305231043687314],
              [120.55172244656134, 31.305076956022535],
              [120.55197976847734, 31.30489891087281],
              [120.5522138978253, 31.304698859067873],
              [120.55242226943511, 31.304478992549882],
              [120.55260260040843, 31.30424172035221],
              [120.55275291512777, 31.30398964219994],
              [120.55287156689617, 31.303725520021416],
              [120.55295725597098, 31.30345224768329],
              [120.55300904379371, 31.303172819280814],
              [120.55302636326165, 31.30289029633105],
              [120.55300902492792, 31.3026077742284],
              [120.55295721906391, 31.302328348330246],
              [120.55287151356085, 31.3020550800442],
              [120.55275284769516, 31.301790963288433],
              [120.55260252182573, 31.301538891692577],
              [120.55242218313673, 31.30130162689844],
              [120.5522138075829, 31.301081768307526],
              [120.55197967823493, 31.300881724606757],
              [120.55172236026297, 31.300703687384114],
              [120.55144467283193, 31.30054960712286],
              [120.55114965821708, 31.300421171837378],
              [120.55084054847772, 31.30031978858419],
              [120.55052073005402, 31.300246568050646],
              [120.55019370667456, 31.300202312389906],
              [120.54986306098057, 31.300187506435226],
              [120.54953241528659, 31.300202312389906],
              [120.54920539190712, 31.300246568050646],
              [120.54888557348343, 31.30031978858419],
              [120.54857646374406, 31.300421171837378],
              [120.5482814491292, 31.30054960712286],
              [120.54800376169817, 31.300703687384114],
              [120.5477464437262, 31.300881724606757],
              [120.54751231437825, 31.301081768307526],
              [120.54730393882441, 31.30130162689844],
              [120.54712360013542, 31.301538891692577],
              [120.54697327426597, 31.301790963288433],
              [120.54685460840031, 31.3020550800442],
              [120.54676890289723, 31.302328348330246],
              [120.54671709703322, 31.3026077742284],
              [120.5466997586995, 31.30289029633105],
              [120.54671707816743, 31.303172819280814],
              [120.54676886599016, 31.30345224768329],
              [120.54685455506497, 31.303725520021416],
              [120.54697320683339, 31.30398964219994],
              [120.5471235215527, 31.30424172035221],
              [120.54730385252604, 31.304478992549882],
              [120.54751222413583, 31.304698859067873],
              [120.5477463534838, 31.30489891087281],
              [120.5480036753998, 31.305076956022535],
              [120.5482813705465, 31.305231043687314],
              [120.54857639631146, 31.30535948552921],
              [120.54888552014809, 31.305460874205146],
              [120.54920535500005, 31.30553409879078],
              [120.54953239642079, 31.305578356955845],
              [120.54986306098057, 31.305593163757642]
            ]
          ]
        }
      }
    }
  },
  beforeDestroy() {
    this.closeEagle()
  },
  methods: {
    moveUp() {
      this.map.moveBy({
        type: 0,
        skewing: 'top'
      })
    },
    moveDown() {
      this.map.moveBy({
        type: 0,
        skewing: 'bottom'
      })
    },
    moveLeft() {
      this.map.moveBy({
        type: 0,
        skewing: 'left'
      })
    },
    moveRight() {
      this.map.moveBy({
        type: 0,
        skewing: 'right'
      })
    },
    reset() {
      this.map.reset()
    },
    zoomIn() {
      this.map.zoomIn()
    },
    zoomOut() {
      this.map.zoomOut()
    },
    forward() {
      this.map.forward()
    },
    goBack() {
      this.map.goBack()
    },
    eagle() {
      this.map.eagle({
        flag: true
      })
    },
    closeEagle() {
      this.map.eagle({
        flag: false
      })
    },
    scale() {
      this.map.scale({
        flag: true,
        anchor: 'bottom-left'
      })
    },
    closeScale() {
      this.map.scale({
        flag: false,
        anchor: 'bottom-left'
      })
    },
    screenshot() {
      this.map.screenshot({
        callback: function(res) {
          console.log(res.data) // 返回64位编码图片
          var a = confirm('下载截图？')
          if (a) {
            document.getElementById('download').setAttribute('href', res.data)
            document.getElementById('download').click()
          }
        }
      })
    },
    measureDistance() {
      this.map.measureDistance({
        units: 'kilometers',
        callback: res => {
          let sClass = this.map.mapType === 'AG' ? 'ag-popup-tools' : 'mm-popup-tools'
          let result = res.data
          if (!result.isEnd) {
            if (result.isStart) {
              this.map.addTexts({
                points: [
                  {
                    point: result.point,
                    htmlText: '起点',
                    class: sClass
                  }
                ],
                anchor: 'left',
                ended: function(res) {
                  console.log(res)
                  this.layerIds.push(res.data)
                }
              })
            } else {
              this.map.addTexts({
                points: [
                  {
                    point: result.point,
                    htmlText: result.distance.toFixed(4) + 'km',
                    class: sClass
                  }
                ],
                anchor: 'left',
                ended: function(res) {
                  console.log(res)
                  this.layerIds.push(res.data)
                }
              })
            }
          } else {
            if (result.index >= 1) {
              if (result.isFailure) {
                this.layerIds.forEach(layerId => {
                  this.map.removeTextsByType({
                    textType: layerId
                  })
                })
                return
              }
              this.layerIds.push(result.layerId)
              if (this.map.mapType === 'BM') {
                this.map.addTexts({
                  points: [
                    {
                      point: result.point,
                      htmlText: '总距离：' + result.distance.toFixed(4) + 'km',
                      class: sClass
                    }
                  ],
                  anchor: 'left',
                  ended: function(res) {
                    console.log(res)
                    this.layerIds.push(res.data)
                  }
                })
              }
            } else {
              this.layerIds.forEach(layerId => {
                this.map.removeTextsByType({
                  textType: layerId
                })
              })
            }
          }
        }
      })
    },
    clearMeasureDistance() {
      this.map.clear()
      for (let i in this.layerIds) {
        this.map.removeTextsByType({
          textType: this.layerIds[i]
        })
      }
      this.layerIds = []
    },
    measureArea() {
      this.map.measureArea({
        units: 'meters',
        callback: res => {
          let areaText = null
          let sClass = this.map.mapType === 'AG' ? 'ag-popup-tools' : 'mm-popup-tools'
          let result = res.data
          if (!result.isEnd) {
            if (result.index >= 2) {
              if (areaText) {
                this.map.removeTextsByType({
                  textType: areaText.data
                })
              }
              let that = this
              this.map.addTexts({
                points: [
                  {
                    point: result.point,
                    htmlText: result.area + '平方米',
                    class: sClass
                  }
                ],
                anchor: 'left',
                ended: function(res) {
                  console.log(res)
                  that.areaLayerIds.push(res.data)
                  areaText = res
                }
              })
            }
          } else {
            if (result.index >= 2) {
              if (result.isFailure) {
                this.areaLayerIds.forEach(layerId => {
                  this.map.removeTextsByType({
                    textType: layerId
                  })
                })
                return
              }
              this.areaLayerIds.push(result.layerId)
              if (this.map.mapType === 'BM') {
                if (areaText) {
                  this.map.removeTextByType({
                    textType: areaText
                  })
                }
                let that = this
                this.map.addTexts({
                  points: [
                    {
                      point: result.point,
                      htmlText: '总面积：' + result.area + '平方米',
                      class: sClass
                    }
                  ],
                  anchor: 'left',
                  ended: function(res) {
                    that.areaLayerIds.push(res.data)
                    areaText = res
                  }
                })
              }
            }
          }
        }
      })
    },
    clearMeasureArea() {
      this.map.clear()
      for (let i in this.areaLayerIds) {
        this.map.removeTextsByType({
          textType: this.areaLayerIds[i]
        })
      }
      this.areaLayerIds = []
    },
    addMarkers() {
      let points = [
        {
          point: [120.58, 31.29],
          customProps: {
            username: '警察1'
          }
        },
        {
          point: [120.59, 31.29],
          customProps: {
            username: '警察2'
          }
        },
        {
          point: [120.59, 31.3],
          customProps: {
            username: '警察3'
          }
        },
        {
          point: [120.6, 31.3],
          customProps: {
            username: '警察4'
          }
        },
        {
          point: [120.6, 31.31],
          customProps: {
            username: '警察5'
          }
        },
        {
          point: [120.57320160811832, 31.2988224269333],
          customProps: {
            username: '警察6'
          }
        }
      ]
      let that = this
      this.map.addMarkers({
        data: points,
        url: police,
        markerType: '__testMarkerType__',
        style: 'width:50px;height:50px;background-repeat:no-repeat;background-position:center;',
        ended: function(markerType) {
          that.groupName = markerType.data
        }
      })
    },
    removeMarkers() {
      this.map.removeMarkersByType({
        markerType: this.groupName
      })
    },
    addCustomOverlays() {
      let element = document.createElement('div')
      element.className = 'addByIdClass'
      element.innerHTML = '自定义覆盖物'
      element.style.width = '200px'
      element.style.height = '50px'
      element.style =
        'font-size: 30px;\n' +
        '    background-color: yellow;\n' +
        '    color: red;\n' +
        '    line-height: 30px;\n' +
        '    padding: 5px;\n' +
        '    border-radius: 3px;\n' +
        '    border: 1px solid red;\n' +
        '    position: relative;\n' +
        '    left: 0;\n' +
        '    top: 10px;'
      let that = this
      that.map.addCustomOverlays({
        data: [
          {
            point: [
              120.4598370360851 + Math.random() * 0.00001,
              31.327252693143436 + Math.random() * 0.00001
            ],
            element: element,
            customProps: '通过type添加的自定义属性1'
          },
          {
            point: [120.89929016109369, 31.38588847078431],
            element: element,
            customProps: '通过type添加的自定义属性2'
          }
        ],
        ended: function(res) {
          that.overlaysType = res.data
          that.map.getCustomOverlaysByType({
            customOverlaysType: 'addByType',
            callback: function(res) {
              console.log(res)
            }
          })
        },
        customOverlaysType: 'addByType'
      })
    },
    removeCustomOverlays() {
      this.map.removeCustomOverlaysByType({
        customOverlaysType: this.overlaysType
      })
    },
    addPopup() {
      var html =
        `<h4 style="margin:0 0 5px 0;padding:0.2em 0">事故现场</h4>` +
        `<p style='margin:0;line-height:1.5;font-size:13px;text-indent:2em'>警员110在苏州科技大学江枫校区附近，发现一桩交通事故，正在紧急处理...</p>` +
        `</div>`
      this.map.addPopup({
        htmlText: html,
        title: 'test',
        closeButton: true,
        closeOnClick: false,
        anchor: 'top',
        point: [120.55985690229573, 31.304152411378453],
        ended: function(popup) {
          this.picturePopup = popup.data
        }
      })
    },
    removePopup() {
      this.map.removeAllPopups()
    },
    addLayer() {
      // removeAll();
      let point = [120.5495989323, 31.3005274325]
      this.map.moveTolnglat({
        type: 2,
        zoom: 14,
        point
      })

      this.LayerId = this.map.addGeometryLayer({
        layerId: 'circle-geo-layer',
        sourceId: 'circle-geo-source',
        data: JSON.parse(JSON.stringify(this.circleData))
      })
      let that = this
      that.map.addMarker({
        point: point,
        url: pointImg,
        ended: function(res) {
          that.layerGroupName = res.data
        }
      })

      const isPointInPolygon = () => {
        point = [
          point[0] + (Math.random() - 0.5) * 0.0015,
          point[1] + (Math.random() - 0.5) * 0.0015
        ]
        let that = this
        that.map.pointInPolygon({
          point: point,
          polygon: this.circleData.geometry.coordinates[0],
          callback: res => {
            that.map.setMarkerProperty({
              type: 'id',
              id: that.layerGroupName,
              point: point
            })
            if (res.status === 10) {
              if (res.data) {
                console.log('目标未出界')
                // alerts.innerHTML = '目标未出界';
                // alerts.style.color = 'black';
              } else {
                console.log('目标出界了')
                // alerts.innerHTML = '目标出界了';
                // alerts.style.color = 'red';
              }
            }
          }
        })
      }

      setInterval(function() {
        isPointInPolygon()
      }, 1000)
    },
    removeLayer() {
      this.map.removeLayer({
        layerId: this.LayerId
      })
      this.map.removeMarkersById({
        id: this.layerGroupName
      })
      clearInterval(this.timer)
      this.timer = null
    }
  }
}
</script>

<style scoped lang="scss">
.map-tool {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  background: transparent;
  z-index: 100;
  .el-button {
    margin-top: 10px;
    margin-left: 10px !important;
  }

  .el-button + .el-button {
    margin-left: 0;
  }
}
</style>
