<template>
  <div class="mapcontrol" id="mapcontrol">
    <span
      v-for="item in controlList"
      v-if="item.show"
      @click="menuSelect(item.index)"
      :class="{ active: activeIndex === item.index || item.icon === 'icon-dianziweilan' }"
      :style="{ cursor: 'pointer', 'border-right': item.noBorder ? 'none' : '1px solid #eeeeee' }"
      :title="item.title"
    >
      <i
        class="iconfont ic-reset"
        :class="{ [item.icon]: true, [item.class]: item.class }"
        @mouseenter="
          item.icon === 'icon-celiang' ? (showMeasureRange = true) : (showMeasureRange = false)
        "
      >
        <div
          v-if="item.icon === 'icon-celiang'"
          id="measureRange"
          class="measureRange"
          v-show="showMeasureRange"
        >
          <span class="title">{{ $t('map.MEASURE_RANGE') }}</span>
          <span>{{ $t('map.END_MEASURE_RANGE') }}</span>
          <div></div>
        </div>
      </i>
    </span>
  </div>
</template>

<script>
import screenfull from 'screenfull'
import * as MapService from './mapService'

export default {
  name: 'mapmenus',
  props: ['kmap', 'mapId', 'type', 'bufferRadius'], // type 0 地图 1 电子围栏
  data() {
    return {
      map: null,
      activeIndex: 0,
      railActiveIndex: 0,
      showInput: false,
      searchText: '',
      index: -1, // 渲染选中的样式
      wrapId: 'wrapId' + Math.random(), // 动态赋值id 以防止组件复用的时候绑定事件BUG
      pointList: [], // 存放所有搜索结果
      showIndex: 3, // 显示多少个
      searchLoading: false, // 地址搜索的loading状态
      startSearch: false, // 搜索是否完毕
      showFindResult: false, // 搜索结果收起来 显示的内容
      custom: [], // 存储覆盖物
      rail: false, // 是否显示电子围栏绘画框
      starAndEndType: [], // 存放测距开始结束的覆盖物 方便测完移除覆盖物
      layerIds: [], // 存放测距画的线段id 方便测完移除
      fullScreen: false, // 是否全屏
      lineId: undefined, // 测距画的线ID 用于清除
      showMeasureRange: false, // 测距使用提示 防止点击测距 测距的提示消失
      controlList: [
        { title: '复位', index: 3, icon: 'icon-ic-jiqun', show: true },
        // {title: this.$t('CHOSE_MAP'), index: 6, icon: 'icon-pic-selected', show: this.type === 0},
        // { title: '测距', index: 7, icon: 'icon-quanping', show: this.type === 0, noBorder: false },
        { title: '全屏', index: 8, icon: 'icon-quanping', show: this.type === 0, noBorder: true } // 最后一个无右边框
      ]
    }
  },
  watch: {
    kmap: {
      handler(val) {
        console.log(val)
        this.map = Object.assign({}, val)
      },
      immediate: true
    }
  },
  created() {},
  mounted() {
    this.init()
  },
  beforeDestroy() {
    document.removeEventListener('click', this.documentEvent)
    document.removeEventListener('resize', this.screenStatus)
    this.map.destroy()
  },
  methods: {
    init() {
      this.addDocumentEvent()
      window.addEventListener('resize', this.screenStatus)
    },
    menuSelect(index) {
      this.activeIndex = index
      this.railActiveIndex = 0 // 取消电阻围栏的绘画的选中状态
      this.map.removeAllGeometries() // 删除所有几何图形 目的是终止绘画状态
      this.clearRange(index)
      if (index !== 5) this.rail = false
      if (this.activeIndex === 2) {
        this.showInput = !this.showInput
        this.rail = false
        if (this.showInput) {
          this.$nextTick(() => {
            if (this.$refs.searchInput) {
              this.$refs.searchInput.focus()
            }
          })
        }
      }
      // 复位
      if (this.activeIndex === 3) {
        this.map.reset()
      }
      // 清除历史轨迹
      if (this.activeIndex === 4) {
        this.clear()
        // MapService.clear(this.map)
        this.$emit('mapReset')
      }
      // 新增围栏 并计算围栏详情弹窗出现的位置
      if (this.activeIndex === 5) {
        let regulateRight = this.type === 0 ? 95 : 145 // 计算下拉框位置用 地图：114，电子围栏：160 都是慢慢试出来的数字
        let el = document.getElementById('mapcontrol').getElementsByClassName('hasSelect')[0]
        let right = this.utils().getElementRight(el)
        let rail = document.getElementById('mapcontrolRail')
        rail.style.right = right - regulateRight + 'px' // 114是慢慢试出来的数字
        this.rail = !this.rail
        this.showInput = false
      }
      // 地图选择
      if (this.activeIndex === 6) {
        console.log('地图选择')
      }
      // 测距
      if (this.activeIndex === 7) {
        this.computeRange()
      }
      // 全屏
      if (this.activeIndex === 8) {
        screenfull.toggle(document.getElementById(this.mapId))
      }
    },
    /**
     *  1.矩形
     *  2.圆形
     *  3.不规则区域
     *  4.线缓冲区域
     *  5.缓冲大小设置
     * */
    drawRail(index) {
      this.railActiveIndex = index
      this.$emit('mapReset') // 电子围栏设置 增加围栏的时候触清除掉页面的几何图形
      switch (index) {
        case 1:
          this.drawFn('drawRectangle').then(res => {
            this.$emit('drawOver', res, index)
          })
          break
        case 2:
          this.drawFn('drawCircular').then(res => {
            this.$emit('drawOver', res, index)
          })
          break
        case 3:
          this.drawFn('drawPolygon').then(res => {
            this.$emit('drawOver', res, index)
          })
          break
        case 4:
          this.drawFn('drawLine').then(res => {
            this.lineToBuffer(res, index)
          })
          break
        case 5:
          this.$emit('setBuffer')
          break
        default:
          break
      }
      this.rail = false
    },
    // 线缓冲区域绘制
    lineToBuffer(data, index) {
      this.map.lineToBuffer({
        polyline: data.coordinates,
        radius: parseFloat(this.bufferRadius),
        units: 'meters',
        callback: res => {
          console.log(res)
          if (res.status === 10) {
            this.map.updatePolygonToEdit({
              type: 'polygon',
              coordinates: res.data.geometry.coordinates
            })
            data.coordinates[0] = res.data.geometry.coordinates[0]
            this.$emit('drawOver', data, index)
          }
        }
      })
    },
    // 绘画区域函数
    drawFn(key) {
      return new Promise((resolve, reject) => {
        this.map[key]({
          callback: res => {
            if (res.status === 10) {
              let obj = res.data
              this.map.getZoom({
                callback: zoomRes => {
                  obj.level = Math.round(zoomRes.data)
                  resolve(obj)
                }
              })
            } else {
              reject(new Error())
            }
          }
        })
      })
    },
    toDes(list) {
      // this.map.moveTolnglat({
      //   type: 2,
      //   point: item.geometry.type === 'linestring' ? c : item.geometry.coordinates
      // })
      let firstItem = list[0]
      if (firstItem.geometry.type === 'linestring') {
        // TODO 是一条路，绘制轨迹 item.geometry.coordinates
      } else {
        list.forEach((item, index) => {
          let id = 'customId' + index
          this.custom.push(id)
          let element = document.createElement('div')
          element.addEventListener('click', () => {
            this.goPoint(item.geometry.coordinates, index)
          })
          element.className = 'pub-map-device-overlay'
          // element.innerHTML = `<div class="location-03">${index + 1}</div>`
          element.innerHTML = `<div adminId="${item.adminId}" kindcode="${
            item.kindcode
          }" class="location" index="${index}">
                                  <div class="pub-location-topTip" index="${index}" title="${
            item.name
          }">${item.name}</div>
                                  <div class="pub-location-arrow" index="${index}"></div>
                                  <div class="pub-location-03" index="${index}">${index + 1}</div>
                                 </div>`
          this.map.addCustomOverlays({
            data: [
              {
                id,
                point: item.geometry.coordinates,
                element: element
              }
            ],
            ended: function(res) {}
          })
        })
        this.goPoint(firstItem.geometry.coordinates, 0)
      }
    },
    // 定位到某一个点
    goPoint(point, index) {
      this.index = index
      this.map.moveTolnglat({
        type: 2,
        zoom: 15,
        point: point
      })
      this.handleTipStyle(index)
    },
    // 显示悬浮框 并加样式
    handleTipStyle(index) {
      let location3 = Array.prototype.slice.call(document.querySelectorAll('.pub-location-03'))
      location3.forEach(node => {
        let arrow = node.previousElementSibling
        let tip = node.previousElementSibling.previousElementSibling
        let i = node.getAttribute('index')
        if (Number(i) === index) {
          node.parentNode.parentNode.parentNode.parentNode.style.zIndex = 1 // 防止图标覆盖住tip
          // 箭头样式
          arrow.style.display = 'inline-block'
          // tip样式
          tip.style.display = 'inline-block'
          let width = parseFloat(window.getComputedStyle(tip).width)
          tip.style.left = -(width / 2 + 12) + 'px' // 让弹框居中 图标宽度24 所以加上12（图标宽度一半）
          // 图标样式
          node.style.width = '26.4px'
          node.style.height = '38.5px'
          node.style.backgroundImage =
            'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAApCAYAAAAmukmKAAAAAXNSR0IArs4c6QAAA61JREFUWAm1WF1IFFEUPufOapsi7ihUaj0EZlRST4aIRUJPvWgPkdSbVNpDP5TZjwRCGPmX9FAP9dBDSNGTvSVFST8mmEGiri6WQWUEoaj5u+rtnHFnm52Znd1sHFjvPd/5zvftvTP3zl0R4rhyLo7tgkUoIepeAJlFbWaobAQAv1P/FSjQGqhTP4bwqA1GzVBia+VY8RLI6yBhuxMvnEPoF4BXBhvVJ2HM1LE1zK2e3jQ/N9cipdxj4scVIuLrxDVrjvbWJn01F1gMt1WN5y8sLrXS1K03k/8txp8eRZT461M7jXURhprZ0uJLmkKvkbTiPsKsRyhFRtOwYU71dBbMznZJgIwVG9gUksEP8HrzArVJ/HCBCHNm5x64bcbamiZp6z6aYc6F8QMSZJEOut2yNnuw7vII5VKt2yYWvZAH7jg/uX0egn0WwioAiZCwQwQxWLwK2raS7CWkxFW7d2ZX9hKIcqM5sVoxe/EIXV13Tl+WvfgpXetEcjWH0isQ5C9XRZ3FftHbBL45c9zLosQRMsQO9yRjKAl4KwTIFzForqXZS2xIVp/Sjq7t5K4p2wghwkhyttom2mtwgXbUOzYcdyGE293lGNQ27/QMtZmOBcPuOvxVQ8AvXqneYkQzfHcOZ4QiTtIJjF5f7l+Kgid6GnGKlZdfT9QZqEttQwE33bZDgc3+et8zXTdsyEBKtu8yTW2XnvzflrTeJyT7Lhl1Igz5poIHS4kwYSStsD+RiFjaV4PzxvoIQ04Ebvg+CxTHjaSV9BGV8t4G3ydzrcWQCYONvse0Nu+ayfHGtObuBRpTH9nxbQ2ZmJ6lnqV9tteuKAbWl56pnonGoYFEv7TzDga76KyXFJ1lyCBMJ8qEvL6mlH4DGtGNOkJmcSEdCU5FVDgEAsRpJzMudRyhrr2lcrSFRnlEj+1aEnoYaEpz5HCd4wh1YSHUCvpuQ3psbXEIFbXciluRuAwH63HSI/AwLeSINcVyjCmApcyxyluRuAy5zN/g+0CPe5VZgrGBJl+3GY8Wx2VIP0yVjo6OQ/cP+gtz103/1sW4zxjnmKPjTm3Mh4bE0kiMf0IXstBUUIGrzzdrmtf2D0NywqLWpz9vaHqLCwoKRnXArvXYgUaMRI6RoWbGOBtU7F4+IBjMOFXIXGrrOYh2xWM4aC7OSZ8xQ1pMhhaumRjzHubn5/N0ltHH6fzKubIQ1+wREce8hzqbptXT2dm5j+Kd9MkM4fR/Gugho3Ya3UIIc2z+ALj/BHIIMXFlAAAAAElFTkSuQmCC)'
        } else {
          node.parentNode.parentNode.parentNode.parentNode.style.zIndex = 0
          // 箭头样式
          arrow.style.display = 'none'
          // tip样式
          tip.style.display = 'none'
          // 图标样式
          node.style.width = '24px'
          node.style.height = '35px'
          node.style.backgroundImage =
            'url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAjCAYAAACOysqWAAAAAXNSR0IArs4c6QAAAxZJREFUSA2tV0tIVFEYvv+5987QQqIgEsE2WW1aBC58bNpJozYGttBNIIQU1CpcBtKm2tYuohbRCzJytBknF1HEMARZEWEPI1AQwyiiRXrHe0/ff+s6910D54fD/Z/fd15zzhnSUkTm8y2OZR2RmtaHtps0rYXToS9D/4T2UGQyD6hQWE6CQU5UALzTrtXGNcc5DjAjmlH3AGBDE+KqbprjIPpSj/zRIgS13t5DZNt3ALw1nJxmA+iH1PUhs1ic8ecJv2HncqPkONONgjMG13AtY/gxN0dQy+V6SMqilFL3JzSqE5EtiXrNUukR17oEMpfbYUv5HuDbGgWMywfJd51oH5VKq+4UAfysKnAmZCzGZJ3cHWNZi3Bm2KFKMApLz2R2CWzHvGpw7iRj2uvrhwW0flW9juAQ9Qsw7YkEFDmAvVdgG7k/f0WYARjG5l2UDXjVGlmhEX1VixlAc38HHwIutcYCr8FTtZh1NGA/FsI079ZdajUs8H1BU1PvwDSrFto95GapXH7rnkW6rp8ByYYqEsbCBTTGeC4BFYtvcMReUEUghThP09OvNwlYMZqaxrFlnykgqRgdHec8HIymLnJgoNVeW3uF22l73fv/mnsPmOYBrOuiV+VOkWfQ5OQSRjHi2Q1/pRzxg3N9gIAdxsxMASSXWG9E0PvLRrk8Ga6JEHAC1mMMJHPh5ESb6CWuSHfXhHMCa+AP4qZrsy1rDkduk98f1tHzn7phtGPXfAzH2I4dAQfwiFrAg+oE66lCdDIJnOsSCThoFIu3MMRrrMcJYteNUulmXMzzpRJwEi7u0/jMewW+7zxip3x2rJq4Bv5s2de337bt51iPLezHvP/ShejgE8CfF6f/k6BarbY7jjPaXK3mW8vlZgZZ6ulZWenqKgghrnR2dr6IA/Z8qQSVSmUYvb6BZPc52TYx4dYtDA569RsYzbHu7u7bniP8TX2aI3kYbfOt+rk/8sIx0IEh5CQSpC4yencRxatortjZrMbNJ6t/c3yuoJo6RZyKaeKD7yjaQTTvicP/aJ6g3cP0fMM3UX4DwWj72pyJdz0AAAAASUVORK5CYII=)'
        }
      })
    },
    // 点击查看更多
    showMore() {
      this.showIndex = this.pointList.length
    },
    // 窗口增加点击事件
    addDocumentEvent() {
      document.addEventListener('click', this.documentEvent)
    },
    // 点击除组件外的地方 隐藏下拉框
    documentEvent(e) {
      if (
        e.target.id !== this.wrapId &&
        document.getElementById(this.wrapId) &&
        !document.getElementById(this.wrapId).contains(e.target)
      ) {
        this.showFindResult = true
      }
    },
    // 搜索框清空
    clear() {
      this.pointList = []
      this.map.removeCustomOverlayById({ id: this.custom }) // 清除所有标记
      this.showFindResult = false
      this.startSearch = false
      this.searchLoading = false
    },
    // 监听全屏状态
    screenStatus() {
      if (!this.checkFull()) {
        // 全屏下按键esc后要执行的动作
        this.fullScreen = false
      } else {
        this.fullScreen = true
      }
      this.handleFullScreen(8)
    },
    // 全屏图标变化
    handleFullScreen(num) {
      let obj = this.controlList.find(v => v.index === num)
      let icon = ''
      if (this.fullScreen) {
        icon = 'icon-quanping'
      } else {
        icon = 'icon-quanping'
      }
      this.$set(obj, 'icon', icon)
    },
    // 检验是否全屏
    checkFull() {
      let isFull = window.fullScreen || document.webkitIsFullScreen
      if (isFull === undefined) {
        isFull = false
      }
      return isFull
    },
    /**
     *  测距系列方法
     * */
    // 测量距离
    computeRange() {
      this.map.measureDistance({
        units: 'kilometers',
        callback: res => {
          let result = res.data
          if (!result.isEnd) {
            if (result.isStart) {
              this.addStart(result.point)
            } else {
              this.addMiddle(result.point, result.distance.toFixed(2))
            }
          } else {
            if (result.index >= 1) {
              this.map.removeCustomOverlaysByType({ customOverlaysType: this.starAndEndType.pop() }) // 最后一个点不需要添加距离
              this.layerIds.push(result.layerId)
              this.addEnd(result.point)
              this.addTotal(result.point, result.distance.toFixed(2))
            } else {
              this.clearRange()
            }
          }
        }
      })
    },
    // 移除测距生成的线以及覆盖物
    clearRange(index) {
      if (index !== 7) this.showMeasureRange = false // 防止点击测距按钮清除测距的提示
      if (this.lineId) this.map.removeGeometryById({ id: this.lineId }) // 移除测距画的线
      this.starAndEndType.forEach(type => {
        this.map.removeCustomOverlaysByType({ customOverlaysType: type }) // 移除起点终点的坐标图案覆盖物
      })
      this.layerIds.forEach(id => {
        this.map.removeLayer({
          layerId: id
        })
      })
      this.starAndEndType = [] // 置空存储覆起点终点覆盖物的容器
      this.layerIds = [] // 置空存储测距线段的容器
    },
    // 测距添加起点
    addStart(point) {
      let el = document.createElement('div')
      el.className = 'map-device-overlay'
      el.innerHTML = `<div class="startPoint">${this.$t('START_POINT')}</div>`
      MapService.definedMapAddMarker(this.map, point, null, el, [-26, -35]).then(res => {
        this.starAndEndType.push(res)
      })
    },
    // 测距添加终点
    addEnd(point) {
      let el = document.createElement('div')
      el.className = 'map-device-overlay'
      el.innerHTML = `<div class="endPoint">${this.$t('END_POINT')}</div>`
      MapService.definedMapAddMarker(this.map, point, null, el, [-26, -35]).then(res => {
        this.starAndEndType.push(res)
      })
    },
    // 测距添加中间点
    addMiddle(point, range) {
      let el = document.createElement('div')
      el.className = 'map-device-overlay'
      el.innerHTML = `<div class="middlePoint">${range} ${this.$t('KILOMETRE')}</div>`
      MapService.definedMapAddMarker(this.map, point, null, el, [-38, -36]).then(res => {
        this.starAndEndType.push(res)
      })
    },
    // 测距添加总距离
    addTotal(point, range) {
      let el = document.createElement('div')
      el.className = 'map-device-overlay'
      el.innerHTML = `<div class="range">
                            <span>${this.$t(
                              'TOTAL_RANGE'
                            )}：<span style="color: red">${range}</span>  ${this.$t(
        'KILOMETRE'
      )}</span>
                            <i class="iconfont ic-reset icon-ic-delete1" id="map-device-overlay-close-range"></i>
                          </div>`
      MapService.definedMapAddMarker(this.map, point, null, el, [-26, 5]).then(res => {
        this.starAndEndType.push(res)
        document
          .getElementById('map-device-overlay-close-range')
          .addEventListener('click', this.clearRange)
      })
    }
  }
}
</script>

<style lang="scss">
.mapcontrol {
  position: absolute;
  right: 20px;
  top: 10px;
  z-index: 4;
  background: #ffffff;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);
  border-radius: 4px;
  /*background: rgba(7, 38, 92, 0.90);*/
  border: 1px solid #ffffff;
  /*box-shadow: 0 0 2px 4px rgba(13, 19, 60, 0.57), inset 0 0 8px 4px rgba(23, 110, 217, 0.20);*/
  display: flex;
  justify-content: space-between;
  align-items: center;
  color: #333;
  .railTitle {
    color: #397fee;
    i {
    }
    span {
      font-size: 13px;
    }
  }
  > span {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999999;
    min-width: 49px;
    height: 34px;
    box-sizing: border-box;
    padding: 0px 10px;
    > span {
      margin-left: 5px;
      margin-right: 5px;
    }
    .iconfont {
      font-size: 20px;
    }
    .icon-celiang {
      position: relative;
      &:hover {
        .measureRange {
          display: inline-block;
        }
      }
      .measureRange {
        width: 145px;
        height: 54px;
        background: white;
        position: absolute;
        top: 38px;
        right: -60px;
        padding: 5px 15px;
        box-sizing: border-box;
        box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2);
        border-radius: 2px;
        div {
          position: absolute;
          top: -6px;
          left: 68px;
          width: 10px;
          height: 10px;
          transform: rotate(45deg);
          background: white;
          border-top: 1px solid #e8e8e8;
          border-left: 1px solid #e8e8e8;
        }
        span {
          display: inline-block;
          height: 22px;
          line-height: 22px;
          font-family: PingFangSC-Regular;
          font-size: 12px;
          color: #888888;
          letter-spacing: 0;
          text-align: right;
          line-height: 24px;
        }
        .title {
          font-family: PingFangSC-Medium;
          color: #333333;
        }
      }
    }
    .icon-ic-down {
      font-size: 10px !important;
      transition: transform 0.3s linear;
      display: inline-block;
      width: 10px;
      height: 10px;
      color: #3d424d;
      //margin-left: 3px;
      &:before {
        display: inline-block;
        width: 10px;
        height: 10px;
        position: relative;
        top: -3.5px;
        left: -1.5px;
      }
    }
    .up {
      transform: rotate(180deg) scale(0.7);
    }
    .down {
      transform: rotate(0deg) scale(0.7);
    }
    &:hover {
      /*background: #062354;*/
      /*box-shadow: inset 0 1px 3px 0 rgba(0, 0, 0, 0.50);*/
      color: #397fee;
    }
  }
  .active {
    color: #397fee;
    /*background: #062354;*/
    /*box-shadow: inset 0 1px 3px 0 rgba(0, 0, 0, 0.50);*/
  }
  .search-address-input {
    position: absolute;
    right: 156px;
    width: 200px;
  }

  .el-input__inner {
    height: 36px;
    line-height: 36px;
  }

  .search-list-wrap {
    .el-input-group__append {
      cursor: pointer;
      padding: 1px 10px;
      background: #4c90fd;
      color: white;
      border-top-width: 0px;
      border-bottom-width: 0px;
    }
    .el-input-group--append .el-input__inner {
      color: #333;
      font-weight: bold;
      font-size: 14px;
    }
    .wrap {
      width: 150%;
      background: white;
      position: absolute;
      /*margin-top: 5px;*/
      top: 29px;
      right: -156px;
      cursor: pointer;
      overflow: hidden;
      border-radius: 4px;
      box-shadow: 0 0 3px #cccccc;
      .search {
        width: 100%;
        padding: 15px;
        box-sizing: border-box;
      }
      .find-result {
        width: 100%;
        height: 40px;
        line-height: 40px;
        text-indent: 20px;
        color: #2573ee;
        font-size: 12px;
      }
      .more {
        height: 40px;
        line-height: 40px;
        width: 100%;
        color: #2573ee;
        font-size: 12px;
        text-align: center;
        border-top: 1px solid #e8e8e8;
      }
    }
  }
  $railWidth: 120px;
  .rail {
    position: absolute;
    top: 45px;
    width: $railWidth;
    background: white;
    border-radius: 4px;
    box-shadow: 0 0 3px #cccccc;
    color: #999999;
    padding: 6px 0;
    .arrow {
      position: absolute;
      width: 10px;
      height: 10px;
      //border: 1px solid red;
      transform: rotate(45deg);
      border-top: 1px solid #e8e8e8;
      border-left: 1px solid #e8e8e8;
      top: -6px;
      right: $railWidth * 0.5;
      //box-shadow: 0 0 3px #cccccc;
      background: white;
    }
    .content {
      box-sizing: border-box;
      cursor: pointer;
      //border-bottom: 1px solid #eeeeee;
      border-left: none;
      width: 100%;
      height: 36px;
      line-height: 36px;
      padding-left: 15px;
      &:hover {
        background: #ecf5ff;
        i {
          color: #397fee;
        }
        span {
          color: #397fee;
        }
      }
      i,
      span {
        display: inline-block;
        height: 36px;
        line-height: 36px;
        text-align: center;
      }
      i {
        color: #999999;
        width: 25px;
        font-size: 18px;
      }
      span {
        position: relative;
        top: -2px;
        font-family: PingFangSC-Medium;
        font-size: 13px;
        color: #444444;
      }
    }
    .active {
      background: #ecf5ff;
      i {
        color: #397fee;
      }
      span {
        color: #397fee;
      }
    }
  }
}
</style>
