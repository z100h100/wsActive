<template>
  <div :class="classObj" class="app-wrapper">
    <sidebar class="sidebar-container" />
    <div class="main-container">
      <navbar />
      <app-main />
    </div>
    <operation-manual v-if="showOperationManual"></operation-manual>
    <div class="toTop" v-show="scrollTop > showScroll" @click="toTop" title="返回顶部">
      <!--    <div class="toTop" @click="toTop">-->
      <div class="arrow">
        <i class="icon iconfont icon-tubiaoguifancopy"></i>
      </div>
    </div>
  </div>
</template>

<script>
import { Navbar, Sidebar, AppMain, OperationManual } from './components'
import ResizeMixin from './mixin/ResizeHandler'
import { mapGetters, mapActions } from 'vuex'

export default {
  name: 'Layout',
  components: {
    Navbar,
    Sidebar,
    AppMain,
    OperationManual
  },
  mixins: [ResizeMixin],
  computed: {
    ...mapGetters(['sidebar', 'device']),
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
        mobile: this.device === 'mobile'
      }
    }
  },
  data() {
    return {
      timer: null,
      timeNum: 100,
      scrollTop: 0,
      showScroll: 100,
      showOperationManual: true
    }
  },
  watch: {
    '$route.path'(newValue, oldValue) {
      this.showOperationManual = newValue.indexOf('/demo/map') <= -1
    }
  },
  methods: {
    ...mapActions(['CloseSideBar']),

    handleClickOutside() {
      this.CloseSideBar({ withoutAnimation: false })
    },
    toTop() {
      window.scrollTo({
        left: 0,
        top: 0,
        behavior: 'smooth'
      })
    }
  },
  mounted() {
    // 隐藏页面加载动画
    this.showOperationManual = this.$route.path.indexOf('/demo/map') <= -1
    document.getElementById('page-preloading').style.display = 'none'
    window.addEventListener('scroll', () => {
      if (this.timer) clearTimeout(this.timer)
      this.timer = setTimeout(() => {
        if (document.documentElement && typeof document.documentElement.scrollTop === 'number') {
          this.scrollTop = document.documentElement.scrollTop
        }
      }, this.timeNum)
    })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.app-wrapper {
  position: relative;
  //   height: 100%;
  min-height: 100%;
  width: 100%;
  background-color: #eceef3;
}
.drawer-bg {
  background: #000;
  opacity: 0.3;
  width: 100%;
  top: 0;
  height: 100%;
  position: absolute;
  z-index: 999;
}
.toTop {
  position: fixed;
  right: 0px;
  bottom: 30px;
  background: red;
  z-index: 1;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: #9097a4;
  box-sizing: border-box;
  cursor: pointer;
  opacity: 0.75;
  div {
    height: 36px;
    line-height: 36px;
    text-align: center;
  }
  &:hover {
    background: #11b2ff;
  }
  .arrow {
    color: #ffffff;
  }
}
</style>

<!--<style lang="scss">-->
<!--  .toTop{-->
<!--    .arrow{-->
<!--      font-size: 22px !important;-->
<!--    }-->
<!--  }-->
<!--</style>-->
