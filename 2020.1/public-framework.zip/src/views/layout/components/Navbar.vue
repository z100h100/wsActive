<template>
  <div class="navbar" mode="horizontal">
    <div class="breadcrumb">
      <!--<hamburger
        :toggle-click="toggleSideBar"
        :is-active="sidebar.opened"
        class="hamburger-container"
      />-->
      <breadcrumb />
      <template v-if="pageTip">
        <el-tooltip v-if="pageTip && pageTip.length > 30" placement="bottom" effect="light">
          <div
            slot="content"
            :style="{ maxWidth: '360px', wordWrap: 'break-word', wordBreak: ' break-all' }"
          >
            {{ pageTip }}
          </div>
          <div class="page-tip">{{ $utils.textFlow(pageTip, 30) }}</div>
        </el-tooltip>
        <div v-else>
          <div class="page-tip">{{ pageTip }}</div>
        </div>
      </template>
    </div>
    <div class="operation">
      <div class="langSelectStyle item">
        <lang-select :lang="lang" class="international right-menu-item"></lang-select>
      </div>
      <el-dropdown
        @command="handleCommand"
        placement="bottom-end"
        class="avatar-container item"
        trigger="click"
      >
        <div class="avatar-wrapper">
          <img :src="avatar" class="avatar" />
          <div class="userName">
            <span>{{ userName || 'userName' }}</span>
          </div>
          <i class="icon el-icon-caret-bottom" />
        </div>
        <el-dropdown-menu slot="dropdown" class="user-dropdown simple" v-if="isSimple">
          <el-dropdown-item command="logout">
            <span>{{ $t('common.userinfo') }}</span>
          </el-dropdown-item>
          <el-dropdown-item command="logout" divided class="logout">
            <span>{{ $t('common.logout') }}</span>
          </el-dropdown-item>
        </el-dropdown-menu>
        <el-dropdown-menu v-if="!isSimple" class="user-dropdown no-simple">
          <div class="user-info">
            <div class="avatar">
              <img :src="avatar" class="avatar" />
            </div>
            <div class="user">
              <span class="line1">Admin</span>
              <span class="line2">工号：88888888</span>
            </div>
          </div>
          <!--<el-dropdown-item divided>-->
          <!--<span>-->
          <!--<i class="iconfont icon-gerenxinxi"></i>-->
          <!--<span>个人信息</span>-->
          <!--</span>-->
          <!--</el-dropdown-item>-->
          <!--<el-dropdown-item divided>-->
          <!--<span>-->
          <!--<i class="iconfont icon-bianji"></i>-->
          <!--<span>修改密码</span>-->
          <!--</span>-->
          <!--</el-dropdown-item>-->
          <!--<el-dropdown-item divided>-->
          <!--<span>-->
          <!--<i class="iconfont icon-huanfu"></i>-->
          <!--<span>换肤</span>-->
          <!--</span>-->
          <!--</el-dropdown-item>-->
          <el-dropdown-item divided class="logout">
            <span>
              <i class="iconfont icon-tuichu-01"></i>
              <span>{{ $t('common.logout') }}</span>
            </span>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

      <!--<themeSelect :themeArry="themeArry" class="item"> </themeSelect>-->
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import LangSelect from '@/components/LangSelect'
import themeSelect from '@/components/ThemeSelect'
import local from '@/lang'
import Breadcrumb from '@/components/Breadcrumb/breadcrumb'
import Hamburger from '@/components/Hamburger'
import avatar from '@/assets/images/pic-head.png'
const viewName = 'i18nView'

export default {
  components: {
    LangSelect,
    Breadcrumb,
    Hamburger,
    themeSelect
  },
  data() {
    return {
      isSimple: false, // 下拉内容是否简约式
      avatar,
      // pageTip: '专有宿主机DDH是一台虚拟化托管的物理服务器，物理服务器上的资源由您独享，与其他租户在物理级别上隔离。您可以在DDH上创建ECS实例。'
      themeArry: [{ label: '默认', value: '' }, { label: '绿色', value: 'greenTheme' }]
    }
  },
  created() {
    if (!this.$i18n.getLocaleMessage('en')[viewName]) {
      this.$i18n.mergeLocaleMessage('zh', local.zh)
      this.$i18n.mergeLocaleMessage('en', local.en)
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'pageTip']),

    userName: function() {
      return ''
    },
    lang: {
      get() {
        return this.$store.state.app.language
      },
      set(lang) {
        this.$i18n.locale = lang
        this.$store.dispatch('setLanguage', lang)
      }
    }
  },
  methods: {
    ...mapActions(['ToggleSideBar', 'logout']),
    toggleSideBar() {
      this.ToggleSideBar()
    },
    handleCommand(command) {
      if (command === 'logout') {
        this.logout().then(() => {
          this.$router.push('/login')
        })
      }
      // this.LogOut().then(() => {
      //   location.reload() // 为了重新实例化vue-router对象
      // })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import '~@/styles/common.scss';
.langSelectStyle {
  position: relative;
  display: inline-table;
  width: 83px;
}

.navbar {
  position: absolute;
  top: 0;
  width: calc(100% + 10px);
  left: -10px;
  padding-right: 20px;
  border-radius: 0 !important;
  display: flex;
  justify-content: space-between;
  background-color: #ffffff;
  .avatar-container {
    cursor: pointer;
    .avatar-wrapper {
      margin-top: 15px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .avatar {
      height: 32px;
      width: 32px;
    }
    .userName {
      margin: 0 10px 0 15px;
      cursor: pointer;
      font-size: 14px;
    }
  }

  .breadcrumb {
    display: flex;
    align-items: center;
    margin-left: 15px;
  }
}
.page-tip {
  margin-left: 15px;
  padding: 0 15px;
  border-radius: 2px;
  background-color: $base-bg-color;
  color: $sub-font-color;
  height: 27px;
  line-height: 27px;
}
.operation {
  display: flex;
  * {
    color: $base-font-color;
  }

  .item {
    position: relative;
    &:after {
      position: absolute;
      right: 0;
      top: 22px;
      content: '';
      display: inline-block;
      height: 15px;
      width: 1px;
      background: #e1e1e1;
    }
    &:last-child {
      &:after {
        display: none;
      }
    }
  }
  .langSelectStyle {
    &:after {
      right: 18px;
    }
  }
  .avatar-container {
    &:after {
      right: -14px;
    }
  }
}
</style>
<style lang="scss">
.user-dropdown {
  margin-top: 0 !important;
  padding: 0;
  min-width: 120px;
  text-align: center;
  li {
    span {
      vertical-align: middle;
    }
  }
  .logout {
    color: #fa2a2a;
    &:hover {
      background-color: #fff;
      color: #fa2a2a;
    }
  }
  /deep/ {
    .el-dropdown-menu__item--divided {
      margin-top: 0;
      &:before {
        height: 0;
      }
    }
  }
}
.no-simple {
  .user-info {
    width: 250px;
    height: 100px;
    background: #1d2028;
    display: flex;
    justify-content: center;
    align-items: center;
    .avatar {
      height: 48px;
      width: 48px;
      border-radius: 50%;
      overflow: hidden;
      img {
        height: 100%;
        width: 100%;
      }
    }
    .user {
      /*display: flex;*/
      /*justify-items: center;*/
      margin-left: 10px;
      text-align: left;
      > span {
        display: block;
      }
      .line1 {
        height: 20px;
        line-height: 20px;
        font-family: PingFangSC-Semibold;
        font-size: 14px;
        color: #ffffff;
        letter-spacing: 0;
      }
      .line2 {
        height: 17px;
        line-height: 17px;
        ont-family: PingFangSC-Regular;
        font-size: 12px;
        color: #aab0bc;
        letter-spacing: 0;
      }
    }
  }
  .el-dropdown-menu__item {
    height: 50px;
    line-height: 50px;
    text-align: left;
    font-family: PingFangSC-Medium;
    font-size: 14px;
    color: #3d424d;
    letter-spacing: 0;
    /*border-bottom: 1px solid #E6E9EF;*/
    > span {
      i {
        font-size: 22px;
        margin-right: 15px;
      }
      display: flex;
      height: 100%;
      align-items: center;
    }
  }
  .logout {
    color: #fa2a2a;
    &:hover {
      background-color: #fff;
      color: #fa2a2a;
    }
  }
  .popper__arrow {
    border-bottom-color: #1d2028 !important;
    &:after {
      border-bottom-color: #1d2028 !important;
    }
  }
}
</style>
