<template>
  <div>
    <div id="dragbtn" class="operation-manual" @click="click" @mousedown="move">
      <i class="iconfont icon-shuoming" @mousedown="move"></i>
      <span @mousedown="move">帮助指导</span>
    </div>
    <el-drawer
      title="帮助指导"
      :visible.sync="drawer"
      :direction="direction"
      size="25%"
      custom-class="operation-manual-drawer"
      :before-close="handleClose"
    >
      <div class="operation-manual-content">
        <el-select v-model="operation" placeholder="请选择" class="select">
          <el-option
            v-for="(item, index) in operationManuals"
            :key="index"
            :label="item.name"
            :value="item.name"
          >
          </el-option>
        </el-select>
        <div class="name">
          <span>{{ currentOperation.name }}</span>
        </div>
        <div class="desc">
          <span>{{ currentOperation.desc }}</span>
        </div>
        <div>
          <div class="step" v-for="(step, index) in currentOperation.steps" :key="index">
            <p class="step-name">
              <span v-if="step.isRequire" style="color: red">*</span>
              <span v-else style="width: 8px; display: inline-block"></span>
              {{ `${index + 1}.${step.name}` }}
            </p>
            <span class="step-desc">{{ step.desc }}</span>
          </div>
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      drawer: false,
      direction: 'rtl',
      operation: '',
      currentOperation: {},
      operationManuals: [
        {
          name: '项目源码维护',
          desc: '开发人员需要通过Gitlab维护源码，后续发布项目时会需要用到Gitlab源码地址。',
          steps: [
            {
              name: 'Gitlab账号申请',
              isRequire: true,
              desc:
                '请获取Gitlab权限，具体请咨询配置管理部马莎莎，分机号：8375，邮箱：mashash@kedacom.com'
            },
            {
              name: '登陆Gitlab',
              isRequire: true,
              desc: '登陆地址：https://sgitlab.kedacom.com/'
            },
            {
              name: '上传源码',
              isRequire: false,
              desc: '主要将代码上传到线上，方便之后的管理更新维护'
            },
            {
              name: '获取源码地址',
              isRequire: true,
              desc: '登陆地址：https://sgitlab.kedacom.com/'
            }
          ]
        },
        {
          name: '新建集群',
          desc: '新建集群步骤',
          steps: [
            {
              name: '基础信息维护',
              isRequire: true,
              desc: '基础信息维护须知'
            },
            {
              name: '添加主机',
              isRequire: true,
              desc: '添加主机须知'
            },
            {
              name: '集群部署',
              isRequire: false,
              desc: '集群部署须知'
            },
            {
              name: '组件安装',
              isRequire: true,
              desc: '组件安装须知'
            }
          ]
        }
      ]
    }
  },
  mounted() {
    this.operation = this.operationManuals[0].name
  },
  watch: {
    operation(newValue, oldValue) {
      this.currentOperation = this.operationManuals.filter(item => item.name === newValue)[0]
    }
  },
  methods: {
    handleClose() {
      this.drawer = false
    },
    click() {
      let isClick = document.getElementById('dragbtn').getAttribute('data-flag')
      if (isClick !== 'true') {
        return false
      }
      this.drawer = true
    },
    move(e) {
      document.getElementById('dragbtn').setAttribute('data-flag', false)
      let odiv = e.target // 获取目标元素
      let firstTime = new Date().getTime()
      let lastTime = ''
      // 算出鼠标相对元素的位置
      // let disX = e.clientX - odiv.offsetLeft;
      let disY = e.clientY - odiv.offsetTop
      document.onmousemove = e => {
        // 鼠标按下并移动的事件
        // 用鼠标的位置减去鼠标相对元素的位置，得到元素的位置
        // let left = e.clientX - disX;
        let top = e.clientY - disY
        // 移动当前元素
        // odiv.style.left = left + 'px';
        odiv.style.top = top + 'px'
      }
      document.onmouseup = e => {
        document.onmousemove = null
        document.onmouseup = null
        lastTime = new Date().getTime()
        if (lastTime - firstTime < 200) {
          document.getElementById('dragbtn').setAttribute('data-flag', true)
        }
      }
    }
  }
}
</script>

<style lang="scss">
.operation-manual {
  width: 36px;
  height: 120px;
  padding: 5px 10px;
  background: #ffffff;
  border: 1px solid #e4e7ed;
  box-shadow: 0 2px 11px 0 rgba(0, 0, 0, 0.15);
  position: fixed;
  right: 0;
  bottom: 75px;
  cursor: move;
  .iconfont {
    color: #11b2ff;
    font-size: 19px;
    margin-left: -2px;
  }
  span {
    font-family: PingFangSC-Medium;
    font-size: 14px;
    color: #11b2ff;
    letter-spacing: 0;
    display: block;
    height: 18px;
    line-height: 18px;
    text-align: center;
    word-wrap: break-word;
  }
}

.operation-manual-drawer {
  /deep/ .el-drawer__header {
    margin-bottom: 0;
    padding: 0 20px;
    height: 60px;
    background: #494f5c;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    span {
      font-family: PingFangSC-Medium;
      font-size: 18px;
      color: #ffffff;
      letter-spacing: 0;
    }
    .el-icon-close {
      font-family: 'iconfont' !important;
      font-size: 16px;
      font-style: normal;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      color: #ffffff;
      &:before {
        content: '\f008';
      }
    }
  }

  /deep/ .el-drawer__body {
    padding: 30px 20px;
    background: #f2f4f9;
  }
}

.operation-manual-content {
  .select {
    width: calc(100% - 40px);
    margin: 0 20px;
  }
  .name {
    font-family: PingFangSC-Regular;
    font-size: 18px;
    color: #25282f;
    letter-spacing: 0;
    margin: 30px 20px 15px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .desc {
    background: #e9ecf4;
    border-radius: 4px;
    padding: 15px;
    span {
      font-family: PingFangSC-Regular;
      font-size: 13px;
      color: #545a67;
      letter-spacing: 0;
      line-height: 24px;
    }
  }
  .step {
    margin-left: 20px;
    margin-top: 15px;
    .step-name {
      font-family: PingFangSC-Medium;
      font-size: 14px;
      color: #130000;
      letter-spacing: 0;
      line-height: 36px;
      margin: 0;
    }
    .step-desc {
      font-family: PingFangSC-Regular;
      font-size: 13px;
      color: #9097a4;
      letter-spacing: 0;
      line-height: 24px;
    }
  }
}
</style>
