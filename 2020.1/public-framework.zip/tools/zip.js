const archiver = require('archiver')
const fs = require('fs')
const path = require('path')

const files = [
  'public',
  'src',
  '.editorconfig',
  '.eslintignore',
  '.eslintrc.js',
  '.gitignore',
  '.prettierignore',
  '.prettierrc',
  'babel.config.js',
  'build.sh',
  'Dockerfile',
  'start.sh',
  'vue.config.js',
  'package.json'
]

// 目标文件
const workDir = path.resolve(__dirname, '..')
const workFiles = fs.readdirSync(workDir, 'utf8')

// zip 工具
const zipPath = 'lib/ui.zip'
const output = fs.createWriteStream(zipPath)
const zipArc = archiver('zip', {})
zipArc.pipe(output)

// 添加文件
workFiles.forEach(file => {
  if (files.includes(file)) {
    const stat = fs.statSync(path.join(workDir, file))
    if (stat.isDirectory()) {
      zipArc.directory(file, file)
    } else {
      zipArc.append(fs.createReadStream(`${workDir}/${file}`), { name: file })
    }
  }
})

// 开始压缩
zipArc.finalize()

// 压缩错误
zipArc.on('error', function(err) {
  throw err
})
// 压缩完成
output.on('close', function() {
  console.log('the resource is compressed!')
})
